

function setup() {
  // runs at the start  
  createCanvas(600, 600);
  background('lightSkyBlue');

    bg = loadImage('OceanImages/OceanImage.jpg');
}

function draw() {
    // logic goes here
    background(bg);


}