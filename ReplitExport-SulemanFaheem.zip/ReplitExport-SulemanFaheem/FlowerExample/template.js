

function setup() {
  // runs at the start  
  createCanvas(600, 600);
  background('lightSkyBlue');
}

function draw() {
    // logic goes here

    
}