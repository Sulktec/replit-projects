

function setup() {
  // runs at the start  
  createCanvas(600, 600);
  background('lightSkyBlue');
  angleMode(DEGREES);
}

function draw() {
    // logic goes here

    var fX = 300;
    var fY = 300;

    var dX = 40;


    fill('pink');
    triangle(200,200,400, 200, 300, 300);


    



    // tail

    


}