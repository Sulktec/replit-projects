
//part 1
//try drawing squares with different colours
//some ideas include video characters, or everyday objects
//cups, flowers, ect, google pixel art for an example




function setup() {
    angleMode(DEGREES);
    rectMode(CENTER);
    createCanvas(600, 600);
    background("lightSkyBlue");
}

function draw() {


}