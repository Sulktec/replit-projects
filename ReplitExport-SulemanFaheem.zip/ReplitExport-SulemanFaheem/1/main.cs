using System;

class Program {
  public static void Main (string[] args) {

    bool close = false;
    int totalMoney = 0;
    int totalItem = 0;
    string userChoice = "";


      

    while (close == false) {

        Console.WriteLine("\n\n\n\n\nWelcome, what do you want to buy");

        Console.WriteLine("\nCost: " + "$" + totalMoney +  "\nItems: " + totalItem);
        
        Console.WriteLine("\n1. Hotdog $2");
        Console.WriteLine("2. Pizza $5");
        Console.WriteLine("3. Fries $1");
        Console.WriteLine("4. Quit");

        userChoice = Console.ReadLine();

        if (userChoice == "1") {

            Console.WriteLine("\nYou got a Hotdog for $2");
            Console.WriteLine("Press any key to continue...");

            totalMoney = totalMoney + 2;
            totalItem++;

            Console.ReadLine();
            
            
            
        }

        if (userChoice == "2") {

            Console.WriteLine("\nYou got a Pizza for $5");
            Console.WriteLine("Press any key to continue...");

            totalMoney = totalMoney + 5;
            totalItem++;

            Console.ReadLine();



        }

        if (userChoice == "3") {

            Console.WriteLine("\nYou got Fries for $1");
            Console.WriteLine("Press any key to continue...");

            totalMoney = totalMoney + 1;
            totalItem++;

            Console.ReadLine();



        }

        if (userChoice == "4") {

            Console.WriteLine("\n\nYou spent $" + totalMoney + " on " + totalItem + " stuff");
        
            close = true;
            
        }
        
        
    }
      
  }
}