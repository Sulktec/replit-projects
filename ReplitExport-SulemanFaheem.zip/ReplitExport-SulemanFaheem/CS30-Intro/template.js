function setup() {
  createCanvas(600, 600);
  background('lightSkyBlue');
}

function draw() {

    ellipse(500,500,100,300);
}