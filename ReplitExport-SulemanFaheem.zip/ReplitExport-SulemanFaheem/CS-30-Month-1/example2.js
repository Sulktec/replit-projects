function setup() {
    angleMode(DEGREES);
    rectMode(CENTER);
    createCanvas(600, 600);
    background("lightSkyBlue");
}

function draw() {
    fill("aquaMarine");
    ellipse(300,300,60,230);
}