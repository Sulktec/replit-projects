class Ex2VoidMethodParameters {


    public static void addTwo(int num1, int num2) {
        System.out.println(num1 + num2);
    }

    
    public static void run(){
    //code starts here
        
        addTwo(7,8);

        
    //code ends here
    }//run

}//class