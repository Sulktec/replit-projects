class BugHunt { // beginning of BugHunt class

      

    // public static void run(){
    // //code starts here
    // addTwo(7,8);
        
    // //code ends here
    // }//run

    // public static void addTwo( num1, num2){

    //     System.out.println(num1+num2);
    // }







}
// end of BugHunt class