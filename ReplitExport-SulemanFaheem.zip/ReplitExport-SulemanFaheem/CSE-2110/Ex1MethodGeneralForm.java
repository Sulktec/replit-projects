class Ex1MethodGeneralForm{
    
    
    public static void myMethod() {


        System.out.println("this statement is printed from myMethod!");
        
    }
    
    
    public static void run(){
    //code starts here
        
       myMethod();

        
    //code ends here
    }//run

}//class