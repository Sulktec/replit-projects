class u{

    
    public static void run(){
    //code starts here
        
        System.out.println("Hello :)");

        
    //code ends here
    }//run

}//class