class Main {
  public static void main(String[] args) {
      
Journal.run();

      
      
  }//main
}//Main