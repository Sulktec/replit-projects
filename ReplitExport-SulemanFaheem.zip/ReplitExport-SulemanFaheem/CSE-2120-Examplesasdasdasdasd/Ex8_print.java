import java.util.Scanner; // Import the Scanner class

class Ex8_print {

    public static void run() {
        Scanner myObj = new Scanner(System.in); // used for Input/Output, included by default
        // code starts here

        String temp = "";

        String temp2 = "h";

        String temp3 = "i";

        temp = temp + temp2;
        System.out.print(temp);
        temp = temp + temp3;

        System.out.print(temp);

        temp = temp + "s";

        System.out.print(temp);




        // code ends here
    }// run

}// class
