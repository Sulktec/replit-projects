import java.util.Scanner; // Import the Scanner class

class Template {

    public static void run() {
        Scanner myObj = new Scanner(System.in); // used for Input/Output, included by default
        // code starts here

        System.out.println("Hello world!");

        // code ends here
    }// run

}// class