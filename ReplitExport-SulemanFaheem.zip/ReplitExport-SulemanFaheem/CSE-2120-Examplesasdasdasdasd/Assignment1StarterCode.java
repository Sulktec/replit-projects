import java.util.Scanner; // Import the Scanner class

class Assignment1StarterCode {

    public static void run() {
        Scanner myObj = new Scanner(System.in); // used for Input/Output, included by default
        // code starts here

        String[] row1 = { "#", "#", "N", "#", "#" };
        String[] row2 = { "#", " ", " ", " ", "#" };
        String[] row3 = { "#", " ", "P", "T", "#" };
        String[] row4 = { "#", " ", " ", " ", "#" };
        String[] row5 = { "#", "#", "#", "#", "#" };

        String[][] column = { row1, row2, row3, row4, row5 };


        
        // code ends here
    }// run





/*
#Mr. Qiu's suggested sequence:

#1start by figuring out how to print one row using a while loop






#2 print multiple rows using another while loop
#NOTE: once you know to print multi rows, you can iterate through a 2d list








#3 to describe the environment around the player, iteratate through the array and compare the current
#value to expected values

*/

}// class