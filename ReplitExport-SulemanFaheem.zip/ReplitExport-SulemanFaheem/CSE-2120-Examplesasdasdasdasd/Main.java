class Main {
  public static void main(String[] args) { 
    //Ex1_creatingAndAccess.run();
    //Ex2_MultidimensionalArray.run();  
    IE1ovservableUniverse.run();
    //IE2printingRoomStarter.run();
      
  }
}