import java.util.Scanner; // Import the Scanner class


class Main {
  public static void main(String[] args) {
       
    RoomGame.run();
      
  }
}



