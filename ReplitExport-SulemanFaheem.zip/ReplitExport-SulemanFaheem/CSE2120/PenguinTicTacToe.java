import java.util.Scanner; // Import the Scanner class


class PenguinTicTacToe{


    public static void run() {
        Scanner myObj = new Scanner(System.in); // used for Input/Output, included by default
        // code starts here

        String player = "☃"; 
        String hazard = "☢";
        String snow = "❄";
        String isValid = "true";
        

        int playerX = 2;
        int playerY = 2;


        int newPlayerX = 0;
        int newPlayerY = 0;

       
        
        

        String[] row1 = { "#", "#", "#", "#", "#"};
        String[] row2 = { "#", " ", " ", " ", "#"};
        String[] row3 = { "#", " ", "☃", "❄","#"};
        String[] row4 = { "#", "☢", " ", " ", "#"};
        String[] row5 = { "#", "#", "#", "#", "#"};

        String[][] map = { row1, row2, row3, row4, row5};

        

        gameLoopMethod(map, playerX, playerY, player);
        



        // code ends here
    }// run

    public static void gameLoopMethod(String[][] column, int playerX, int playerY, String player) {
        Scanner myObj = new Scanner(System.in);
        boolean gameRun = true;
        String playerInput = "";
        
        
        while (gameRun == true) {
        System.out.println("You're a snowperson. Find the snow, avoid the radiation\n\n");

         printmap(column);

        System.out.println("wasd commands move the player.");
        System.out.print("enter your move: ");
        playerInput = myObj.nextLine();        
        System.out.println();

        
        
        int[] newPosition = move(column, playerX, playerY, playerInput);

        

        int newPlayerX = newPosition[0];
        int newPlayerY = newPosition[1];

        column[newPlayerY][newPlayerX] = player;

        

        playerY = newPlayerY;
        playerX = newPlayerX;
        
        


        }

        
        
    }

    



    public static void printmap(String[][] column) {

        int indexColumn = 0;
        int indexRow = 0;

        while (indexColumn < column.length) {

            String append = "";

            while (indexRow < column[indexColumn].length) {
                append = append + column[indexColumn][indexRow];
                indexRow++;

            } // end inner while
            System.out.println(append);
            indexRow = 0;
            indexColumn++;
        } // end outer while

    }


    //as a challenge, modify this method to allow the character to move diagonally 
    public static int[] move(String[][] column, int xCoordinate, int yCoordinate, String direction){

        String left = "a";
        String right = "d";
        String up = "w";
        String down = "s";

        int[] returnedCoordinates = { 0, 0}; //00 is a place holder

        if(left.equalsIgnoreCase(direction) && column[yCoordinate][xCoordinate - 1].equals(" ")){
            column[yCoordinate][xCoordinate] = " ";
            xCoordinate--;
        }

        else if(right.equalsIgnoreCase(direction) && column[yCoordinate][xCoordinate + 1].equals(" ")){
            column[yCoordinate][xCoordinate] = " ";
            xCoordinate++;
        }

        else if(up.equalsIgnoreCase(direction) && column[yCoordinate - 1][xCoordinate].equals(" ")){
            column[yCoordinate][xCoordinate] = " ";
            yCoordinate--;
        }

        else if(down.equalsIgnoreCase(direction) && column[yCoordinate + 1][xCoordinate].equals(" ")){
            column[yCoordinate][xCoordinate] = " ";
            yCoordinate++;
        } else {

            System.out.println("Illegal move");
        }


        returnedCoordinates[0] = xCoordinate; 
        returnedCoordinates[1] = yCoordinate;
        return returnedCoordinates; // returns modified coordinate pair 
    }




}