class Problem2{


    public static void run(){
    //code starts here

        String[ ] regularCarBrands = {"Ford", "dodge", "totoya", "honda"};
        String[ ] toyotaModels = {"corolla", "Rav 4", "Prius", "4Runner"};
        String[ ] luxuryCarBrands = {"Mercedes", "BMW", "Lexus", "Acura"};

        String[ ][ ] allBrands = {regularCarBrands,toyotaModels,luxuryCarBrands};

        System.out.println(allBrands.length);

        int index1 = 0;
        int index2 = 0;

            while(index1 < allBrands.length) {

                while(index2 < allBrands[index1].length){

                    System.out.println(allBrands[index1][index2]);
                    index2++;
                }
                index1 ++;
                index2 = 0;
            }

    //code ends here
    }//run









}//class