import java.util.Scanner; // Import the Scanner class

class Assignment3 {

    public static void run() {

        String[] row1 = { "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#"};
        String[] row2 = { "#", " ", " ", " ", "#", "#", " ", " ", " ", "#", "#", " ", " ", " ", "#"};
        String[] row3 = { "#", " ", "1", " ", "E", "W", " ", "2", " ", "E", "W", " ", "3", " ", "#"};
        String[] row4 = { "#", " ", " ", " ", "#", "#", " ", " ", " ", "#", "#", " ", " ", " ", "#"};
        String[] row5 = { "#", "#", "S", "#", "#", "#", "#", "S", "#", "#", "#", "#", "S", "#", "#"};
        String[] row6 = { "#", "#", "N", "#", "#", "#", "#", "N", "#", "#", "#", "#", "N", "#", "#"};
        String[] row7 = { "#", " ", " ", " ", "#", "#", " ", " ", " ", "#", "#", " ", " ", " ", "#"};
        String[] row8 = { "#", " ", "4", " ", "E", "W", " ", "5", " ", "E", "W", " ", "6", " ", "#"};
        String[] row9 = { "#", " ", " ", " ", "#", "#", " ", " ", " ", "#", "#", " ", " ", " ", "#"};
        String[] row10 ={ "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#"};





        String[][] map = { row1, row2, row3, row4, row5,row6, row7, row8, row9, row10};  
        

        int layerLevel = 2;
        
        printmap(map);
        numberChoose(map, layerLevel);
        
        
    
     
        
        

    }// run


    public static void numberChoose(String[][] column, int layerLevel) {
        Scanner myObj = new Scanner(System.in);
        String userChoice = "";

        int userChoiceInt = 0;

        boolean correctInput = false;
        while (correctInput == false) {
            System.out.println("\n\nChoose a number from 1 and 6");

            userChoiceInt = 0;
            userChoiceInt = myObj.nextInt();

            if (userChoiceInt <= 6 && userChoiceInt > 0) {

                correctInput = true;

            } else {

                System.out.println("Incorrect input try again.");
            }

        }

        userChoice = String.valueOf(userChoiceInt);

        numberFind(column, layerLevel, userChoice, userChoiceInt);
        
        myObj.close();

        
    }

    
    public static void numberFind(String[][] column, int layerLevel, String userChoice, int currentRoom) {
 
        int yAxis = 0;
        int xAxis = 0;

        int numberX = 0;
        int numberY = 0;


            while (yAxis < column.length) {

                while (xAxis < column[yAxis].length) {

                    if (column[yAxis][xAxis].equals(userChoice)) {

                        numberX = xAxis;

                        numberY = yAxis;
                    
                    }

                    xAxis++;
                } 

                xAxis = 0;

                yAxis++;

        }

        
        printObservableUniverse(column, numberY, numberX, layerLevel, currentRoom);

    
        
        
    }


    

    public static void printmap(String[][] column){

        int indexColumn = 0;
        int indexRow = 0;

        while (indexColumn < column.length) {

    
            while(indexRow < column[indexColumn].length){
                             
                System.out.print(column[indexColumn][indexRow]);
                indexRow++;
            }//end inner while
            System.out.println("");
            indexRow = 0;
            indexColumn++;
        }//end outer while

    }

    

    public static void printObservableUniverse(String[][] column, int centrey, int centrex, int layerDepth, int currentRoom){

        Scanner myObj = new Scanner(System.in); // used for Input/Output, included by default


        boolean north = false;
        boolean south = false;
        boolean east = false;
        boolean west = false;
        
        int offsetx = -layerDepth;
        int offsety = layerDepth;

        int indexColumn = centrey + offsetx;
        int indexEnd = centrey + offsety;


        int indexRow = centrex + offsetx;
        int indexRowEnd = centrex + offsety;

        while (indexColumn <= indexEnd) {

            String append = "";


            while(indexRow <= indexRowEnd){
                append = append + column[indexColumn][indexRow];


                if (column[indexColumn][indexRow].equals("N")) {

                     north = true;

                }
                // East
                if (column[indexColumn][indexRow].equals("E")) {

                     east = true;

                }
                // South
                if (column[indexColumn][indexRow].equals("S")) {

                     south = true;

                }
                // West
                if (column[indexColumn][indexRow].equals("W")) {

                     west = true;

                }

                
                indexRow++;

                // System.out.println(" a this point append contains " + append);
                // System.out.println(" a this point we are in column[" + indexColumn + "]"  + "[" + indexRow + "]");
                // System.out.println(" press enter to continue");
                // String unusedVariable = myObj.nextLine();

            }//end inner while
            System.out.println(append);
            indexRow = centrex + offsetx;
            indexColumn++;
        }//end outer while


        movement(column, north, east, south, west, currentRoom, layerDepth);
    

    }

    public static void movement(String[][] column, boolean north, boolean east, boolean south, boolean west, int currentRoom, int layerLevel) {
        Scanner myObj = new Scanner(System.in); // used for Input/Output, included by default
        System.out.println("\n\n\n");
        String roomString = "";
        
        boolean run = true;
        
        int verticalMovement = 3;
        int horizontalMovement = 1;
        
        
        // doors
        if (north == true) {

            System.out.println("there is a door to your north");         
        }

        if (east == true) {

            System.out.println("there is a door to your east");           
        }

        if (south == true) {

            System.out.println("there is a door to your south");         
        }

        if (west == true) {

            System.out.println("there is a door to your west");         
        }
        
        System.out.println("\n\nWhere do you want to move.\nType in the letter.");
    
        String userChoice = myObj.nextLine();



        
        
        if (userChoice.equals("N") && north == true) {
            currentRoom = currentRoom - verticalMovement;
            roomString = String.valueOf(currentRoom);
            numberFind(column, layerLevel, roomString, currentRoom);
            run = false;

        } else if (userChoice.equals("E") && east == true) {
            currentRoom = currentRoom + horizontalMovement;
            roomString = String.valueOf(currentRoom);
            numberFind(column, layerLevel, roomString, currentRoom);
            run = false;

        } else if (userChoice.equals("S") && south == true) {
            currentRoom = currentRoom + verticalMovement;
            roomString = String.valueOf(currentRoom);
            numberFind(column, layerLevel, roomString, currentRoom);
            run = false;

        } else if (userChoice.equals("W") && west == true) {
            currentRoom = currentRoom - horizontalMovement;
            roomString = String.valueOf(currentRoom);
            numberFind(column, layerLevel, roomString, currentRoom);
            run = false;

        } else {
            System.out.println("Wrong input, try again.");
            movement(column, north, east, south, west, currentRoom, layerLevel);
            }

        myObj.close();
        
    }



    

    public static void printMapObservable(String[][] column, int centrey, int centrex){

        

        int indexColumn = centrey - 2; 
        int indexEnd = centrey + 3; 


        int indexRow = centrex - 2; 
        int indexRowEnd = centrex + 3; 

     

        while (indexColumn < indexEnd) {
            
            String append = "";


            while(indexRow < indexRowEnd){
                

                
                
                append = append + column[indexColumn][indexRow];
                indexRow++;
            }//end inner while
            System.out.println(append);
            indexRow = centrex - 2;
            indexColumn++;
        }//end outer while

    }

}