import java.util.Scanner; // Import the Scanner class

class IE2printingRoomStarter {

    public static void run() {
        Scanner myObj = new Scanner(System.in); // used for Input/Output, included by default

        String[] row1 = { "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#"};
        String[] row2 = { "#", " ", " ", " ", "#", "#", " ", " ", " ", "#", "#", " ", " ", " ", "#"};
        String[] row3 = { "#", " ", "1", "F", "#", "#", " ", "2", " ", "#", "#", " ", "3", " ", "#"};
        String[] row4 = { "#", " ", " ", " ", "#", "#", " ", " ", "U", "#", "#", " ", "N", " ", "#"};
        String[] row5 = { "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#"};
        String[] row6 = { "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#"};
        String[] row7 = { "#", " ", " ", " ", "#", "#", " ", " ", " ", "#", "#", "P", "P", " ", "#"};
        String[] row8 = { "#", "A", "4", " ", "#", "#", "S", "5", " ", "#", "#", " ", "6", " ", "#"};
        String[] row9 = { "#", "B", " ", " ", "#", "#", " ", " ", " ", "#", "#", " ", "L", " ", "#"};
        String[] row10 ={ "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#"};
        String[] row11 ={ "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#"};
        String[] row12 ={ "#", " ", "K", " ", "#", "#", " ", " ", " ", "#", "#", "W", "P", " ", "#"};
        String[] row13 ={ "#", " ", "7", " ", "#", "#", "L", "8", " ", "#", "#", "q", "9", " ", "#"};
        String[] row14 ={ "#", " ", " ", " ", "#", "#", " ", " ", " ", "#", "#", "F", "T", "Y", "#"};
        String[] row15 ={ "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#", "#"};




        String[][] map = { row1, row2, row3, row4, row5,row6, row7, row8, row9, row10, row11, row12, row13, row14, row15};  
        
       
        printmap(map);
        numberChoose(map);

        

     
        
        

    }// run

    public static void numberChoose(String[][] column) {
    Scanner myObj = new Scanner(System.in);
    String userChoice = "";
    
    System.out.println("Choose a number from 1 and 9");
        
    userChoice = myObj.nextLine();

    int yAxis = 0;
    int xAxis = 0;

    int numberX = 0;
    int numberY = 0;


        while (yAxis < column.length) {

            while (xAxis < column[yAxis].length) {

                if (column[yAxis][xAxis].equals(userChoice)) {

                    numberX = xAxis;

                    numberY = yAxis;
                    
                }

                xAxis++;
            } 

            xAxis = 0;

            yAxis++;

        }

        
        printMapObservable(column, numberY, numberX);
    
        myObj.close();
        
    }


    

    public static void printmap(String[][] column){

        int indexColumn = 0;
        int indexRow = 0;

        while (indexColumn < column.length) {

    
            while(indexRow < column[indexColumn].length){
                             
                System.out.print(column[indexColumn][indexRow]);
                indexRow++;
            }//end inner while
            System.out.println("");
            indexRow = 0;
            indexColumn++;
        }//end outer while

    }

    
    

    public static void printMapObservable(String[][] column, int centrey, int centrex){

        

        int indexColumn = centrey - 2; 
        int indexEnd = centrey + 3; 


        int indexRow = centrex - 2; 
        int indexRowEnd = centrex + 3; 

     

        while (indexColumn < indexEnd) {
            
            String append = "";


            while(indexRow < indexRowEnd){
                append = append + column[indexColumn][indexRow];
                indexRow++;
            }//end inner while
            System.out.println(append);
            indexRow = centrex - 2;
            indexColumn++;
        }//end outer while

    }

}