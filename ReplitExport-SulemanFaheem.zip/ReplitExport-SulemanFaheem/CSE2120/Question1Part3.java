// Access and print the first element 

class Question1Part3{


    public static void run(){
    //code starts here

        String[] csSchools = {"UofC", "UofA", "UBC", "Waterloo", "UofT"};

        csSchools[2] = "McGill";

    //code ends here
    }//run

}//class