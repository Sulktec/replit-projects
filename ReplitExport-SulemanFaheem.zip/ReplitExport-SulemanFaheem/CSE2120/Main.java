class Main {
  public static void main(String[] args) {
      
                TicTacToeSpace.run();

      
      
  }//main
}//Main