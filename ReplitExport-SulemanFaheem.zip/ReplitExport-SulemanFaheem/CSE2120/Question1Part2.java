// Access and print the first element 

class Question1Part2{


    public static void run(){
    //code starts here

        String[] csSchools = {"UofC", "UofA", "UBC", "Waterloo", "UofT"};

        String temp = csSchools[1];

        System.out.println(temp);

    //code ends here
    }//run

}//class