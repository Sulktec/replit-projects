// Access and print the first element 

class Question1Part1{


    public static void run(){
    //code starts here

        String[] csSchools = {"UofC", "UofA", "UBC", "Waterloo", "UofT"};

        String temp = csSchools[0];

        System.out.println(temp);

    //code ends here
    }//run

}//class