
import java.util.Scanner; // Import the Scanner class

class workspace {

    public static void run() {
        Scanner myObj = new Scanner(System.in); // used for Input/Output, included by default
        // code starts here


        String A = "O";

        String B = "O";

        String C = "O";



        if(true){
            System.out.println("this if statement is true ");
        }


        if(A.equals(B)){
            System.out.println("this is another way of making the condition true");

        }


        if(B.equals(A) && B.equals(C)){
            System.out.println("Three is a match ");
        }




        //exercises 


        String D = "R";

        String E = "T";

        String F = "H";

        /* write an if statement similar to the above examples that will print the 

            message in the if statement when D = "R",  E = "T" and F = "H"

            You will need to code the correct condition in the if statement, and initialize 
            D,E,F to the appropriate variables 
        */


    if (D.equals("R") && E.equals("T") && F.equals("H")) {

        System.out.println("Something");
        
    }




        // code ends here
    }// run

}// class