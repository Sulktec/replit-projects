class Temp{

    
    public static void run(){
    //code starts here
        
        System.out.println("Hello world!");

        
    //code ends here
    }//run

}//class