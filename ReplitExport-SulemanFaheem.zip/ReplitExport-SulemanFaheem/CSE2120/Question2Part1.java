

class Question2Part1{


    public static void run(){
    //code starts here




    //code ends here
    }//run

}//class