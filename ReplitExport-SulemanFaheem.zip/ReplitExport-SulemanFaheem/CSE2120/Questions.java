class Questions {

    public static void run(){
    //code starts here

        // Question 1
        System.out.println("\n\n\n");
        
        String[] csSchools = {"UofC", "UofA", "UBC", "Waterloo", "UofT"};

        String temp = csSchools[0];

        System.out.println(temp);

        
        
        
      

        temp = csSchools[1];

        System.out.println(temp);




        

        csSchools[2] = "McGill";



        


        // questions 2
        System.out.println("\n\n\n");

        String[] regularCarBrands = {"Ford", "Dodge", "Toyota", "Honda"};
        String[] toyotaModels = {"Corolla", "Rav4", "Prius", "Tacoma"};
        String[] luxuryCarBrands = {"Mercedes", "BMW", "Lexus", "Acura"};

        String[][] combinedArrays = {regularCarBrands, toyotaModels, luxuryCarBrands};
        // lexus
        System.out.println(combinedArrays[2][2]);

        // honda
        System.out.println(combinedArrays[0][3]);

        // mercedes

        System.out.println(combinedArrays[2][0]);

        // rav 4 to Camry
        combinedArrays[1][1] = "Camry";

        // “BMW” to “Volkswagen” 

        combinedArrays[2][1] = "Volkswagen";

        // “Dodge” to “Chevy”

        combinedArrays[0][1] = "Chevy";


        // Question 3

        System.out.println("\n\n\n");

        String[] school = {"UofC", "UofA", "Waterloo", "UofT"};
        String[] knownFor = {"Kinesiology", "Reinforcement learning", "COOP", "High cost"};  
        int[] semesterCost = {3500, 3500, 5000, 7000};


        System.out.println("The School " + school[0]);
        System.out.println("is known for " + knownFor[0]);
        System.out.println("it costs " + semesterCost[0] + " per semester to study there.");
        System.out.println("\n");
            
        System.out.println("The School " + school[1]);
        System.out.println("is known for " + knownFor[1]);
        System.out.println("it costs " + semesterCost[1] + " per semester to study there.");
        System.out.println("\n");


        System.out.println("The School " + school[2]);
        System.out.println("is known for " + knownFor[2]);
        System.out.println("it costs " + semesterCost[2] + " per semester to study there.");
        System.out.println("\n");

        System.out.println("The School " + school[3]);
        System.out.println("is known for " + knownFor[3]);
        System.out.println("it costs " + semesterCost[3] + " per semester to study there.");
        System.out.println("\n");
            
        

        
        

    //code ends here
    }// run

}// class