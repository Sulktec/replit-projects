class ArrayPractice{

    
    public static void run(){
    //code starts here
        
        int a[] = {23, 62, 99};

        
        System.out.println(a.length);
        System.out.println(a[0]);
        System.out.println(a[1]);
        System.out.println(a[2]);
        System.out.println("\n\n");
        int q[] = new int[100];
        int j = 0;
        while (j < q.length) {

            q[j] = j*j;

            System.out.println("square of " + j + " is: " + q[j]);
        
            j++;
        }

        
    //code ends here
    }//run

}//class