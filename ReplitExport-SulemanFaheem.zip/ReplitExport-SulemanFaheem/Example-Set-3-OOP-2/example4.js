
let ourforce;
let ourShape;
let keyreleased = true;

let accelBy = 0.1;
let decelAmount = 1; // 1 means decelerate by the same value it accelerates (frction)


function setup() {
    angleMode(DEGREES);
    rectMode(CENTER);
    createCanvas(600, 600);
    background("lightSkyBlue");

    ourforce = createVector(0,0);// vectors should be declared in setup 
    ourShape = new OurSquare(0,300,50,50,'green');
}

function keyPressed(){
        keyreleased = false;
    if(keyCode === 39){//right
        ourforce.add(createVector(accelBy,0))
    }

    if(keyCode === 37){//left
        ourforce.add(createVector(-accelBy,0))
    }

    if(keyCode === 38){//up
        ourforce.add(createVector(0,-accelBy))
    }

    if(keyCode === 40){//down
        ourforce.add(createVector(0,accelBy))
    }

    // if(keyCode === 40){//down
    //     ourforce.add(createVector(0,accelBy))
    // }

    // if(keyCode === 38){//up
    //     ourforce.add(createVector(0,-accelBy))
    // }
 }

function keyReleased() {

    ourforce = createVector(0,0)
    
    keyreleased = true;
  
    
}

function draw() {
    //clear
    clear();
    background("lightSkyBlue");
    // math
    ourShape.applyForce(ourforce);
    if(keyreleased === true) {
        ourShape.stopSquare(accelBy,decelAmount)
    }
    ourShape.updatePosition();
    
    // draw
    ourShape.draw();
}