
let ourforce;
let ourShape;

function setup() {
    angleMode(DEGREES);
    rectMode(CENTER);
    createCanvas(600, 600);
    background("lightSkyBlue");

    ourforce = createVector(0,0);// vectors should be declared in setup 
    ourShape = new OurSquare(0,300,50,50,'green');
}

function keyPressed(){
    if(keyCode === 71){//g
        ourforce.add(createVector(0.1,0))
    }
}

function draw() {
    //clear
    clear();
    background("lightSkyBlue");
    // math
    ourShape.applyForce(ourforce);
    ourShape.updatePosition();
    // draw
    ourShape.draw();
}