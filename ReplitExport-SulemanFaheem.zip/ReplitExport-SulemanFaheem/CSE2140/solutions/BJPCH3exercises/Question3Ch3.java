public class Question3Ch3
{
public static void main(String args[])
{
	//code starts here

    String g = "Computer Science is for nerds";

    System.out.println(g.toLowerCase());

    

	//code ends here
}
}

