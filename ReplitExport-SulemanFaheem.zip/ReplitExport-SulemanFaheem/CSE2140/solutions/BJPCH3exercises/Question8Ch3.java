public class Question8Ch3
{
public static void main(String args[])
{
	//code starts here

    System.out.println("All \"good\" men should come to the aid of their country.");
    

	//code ends here
}
}

