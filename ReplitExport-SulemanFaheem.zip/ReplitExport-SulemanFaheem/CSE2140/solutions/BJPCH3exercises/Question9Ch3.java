public class Question9Ch3
{
public static void main(String args[])
{
	//code starts here

    System.out.println("Hello\nHello again");
    

	//code ends here
}
}

