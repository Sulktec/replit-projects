public class Question1Ch3
{
public static void main(String args[])
{
	//code starts here

    String s = "The number of rabbits is";

    int argh = 129;

    String report = s + " " + argh + ".";

    System.out.println(report);


	//code ends here
}
}

