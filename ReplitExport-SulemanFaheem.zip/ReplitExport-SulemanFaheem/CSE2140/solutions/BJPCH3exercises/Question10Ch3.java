public class Question10Ch3
{
public static void main(String args[])
{
	//code starts here

    System.out.println("A backslash looks like this \\, …right?");
    

	//code ends here
}
}

