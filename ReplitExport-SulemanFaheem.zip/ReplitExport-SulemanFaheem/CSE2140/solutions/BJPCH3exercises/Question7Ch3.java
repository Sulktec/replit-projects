public class Question7Ch3
{
public static void main(String args[])
{
	//code starts here

    String m = "Look here!"; 

    System.out.println("\"" + m + "\"" + " has " + m.length() + " characters.");
    

	//code ends here
}
}

