public class Lesson2Q6
{
public static void main(String args[])
{
	//code starts here

    int i = 407;

	//code ends here
}
}
