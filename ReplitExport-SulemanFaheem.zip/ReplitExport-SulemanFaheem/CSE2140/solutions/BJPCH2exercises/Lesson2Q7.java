public class Lesson2Q7 {
    public static void main(String args[]) {
        // code starts here

        String my_name = Suleman;

        // code ends here
    }
}
