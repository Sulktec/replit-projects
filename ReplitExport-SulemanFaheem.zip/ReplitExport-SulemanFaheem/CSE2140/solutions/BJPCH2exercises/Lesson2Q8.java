public class Lesson2Q8 {
    public static void main(String args[]) {
        // code starts here

        int number;

        // code ends here
    }
}
