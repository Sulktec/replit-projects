public class Lesson2Q5 {
public static void main(String args[])
{
	//code starts here

    double p = 1.921 * 10-16;

	//code ends here
}
}
