public class Question6Ch4
{
public static void main(String args[])
{
	//code starts here

    int v = 100; v-= 30; v = v - 30;
    
    

    
    
	//code ends here
}
}
