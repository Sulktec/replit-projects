public class Question4Ch4
{
public static void main(String args[])
{
	//code starts here

    int zulu = 1; System.out.println(zulu--);

    
	//code ends here
}
}
