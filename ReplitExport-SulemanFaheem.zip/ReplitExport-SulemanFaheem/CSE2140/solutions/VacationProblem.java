import java.util.Scanner;  // Import the Scanner class
class VacationProblem {
  public static void main(String[] args) {
    Scanner myObj = new Scanner(System.in);

    System.out.println("Where did you go on vacation? ");

    String location = myObj.nextLine();

     System.out.println( location + " is on my bucket list");


   
    


  }
}

