import java.util.Scanner;  // Import the Scanner class
class JavaIsBestProblem {
  public static void main(String[] args) {
    

    System.out.println("Java is the best programming language!");
    


  }
}

