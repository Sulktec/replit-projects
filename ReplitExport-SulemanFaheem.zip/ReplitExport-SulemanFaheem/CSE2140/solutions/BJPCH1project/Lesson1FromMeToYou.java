public class Lesson1FromMeToYou
{
public static void main(String args[])
{
	//code starts here

System.out.println("From: Bill Smith \nDestination: Alberta\n");

	//code ends here
}
}
