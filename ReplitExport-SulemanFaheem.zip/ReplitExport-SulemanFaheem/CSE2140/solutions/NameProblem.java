import java.util.Scanner;  // Import the Scanner class
class NameProblem {
  public static void main(String[] args) {
    

    System.out.println("Suleman");
    


  }
}

