import java.util.Scanner;  // Import the Scanner class
class DistanceSpeedProblem {
  public static void main(String[] args) {
    Scanner myObj = new Scanner(System.in);

    System.out.println("enter a speed for how fast a car is traveling");

    int speed = myObj.nextInt();

    
    

    System.out.println("the car travels " + (speed * 5) + "km in 5 hours" );
    System.out.println("the car travels " + (speed * 8) + "km in 8 hours" );
    System.out.println("the car travels " + (speed * 12) + "km in 12 hours" );

    


   
    


  }
}

