import java.util.Scanner;  // Import the Scanner class
class AnnualSalesProblem {
  public static void main(String[] args) {
    Scanner myObj = new Scanner(System.in);

    System.out.println("What is the projected annual sales?");

    int annualSales = myObj.nextInt();
    

    System.out.println("our annual profit will be " +  annualSales * 0.2);

    


   
    


  }
}

