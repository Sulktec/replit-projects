class FromMeToYou {
    public static void main(String[] args) {

        System.out.println(
                "From: Bill Smith \nAddress: Dell Computer, Bldg 13 \nDate: April 12, 2005 \nTo: Jack Jones \nMessage: Help! I'm trapped inside a computer!");

    }
}