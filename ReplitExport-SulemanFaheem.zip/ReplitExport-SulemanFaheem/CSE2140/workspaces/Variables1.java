class Variables1 {
  public static void main(String[] args) {
    
    int age = 59;

    System.out.println(age);
      
  }
}