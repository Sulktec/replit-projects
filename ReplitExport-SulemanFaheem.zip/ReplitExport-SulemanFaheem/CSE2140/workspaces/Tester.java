public class Tester {
  public static void main(String[] args) {
    
    System.out.print("Hello world");
    System.out.println("Hello again.");
      
  }
}


