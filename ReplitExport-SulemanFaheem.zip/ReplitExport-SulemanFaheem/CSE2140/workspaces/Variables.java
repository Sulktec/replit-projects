class Variables {
  public static void main(String[] args) {
    
    String s = ("Hello cruel world");

    System.out.println(s);
      
  }
}