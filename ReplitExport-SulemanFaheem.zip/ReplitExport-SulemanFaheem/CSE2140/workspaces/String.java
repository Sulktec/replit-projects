class Variables2 {
  public static void main(String[] args) {
    
    double d = -137.8036;
    
    System.out.println(d);

      d = 1.45667E23;
      
  }
}