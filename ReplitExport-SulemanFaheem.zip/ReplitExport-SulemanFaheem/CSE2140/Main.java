class Main {

    public static void main(String args[])
{
	//code starts here

    int loop = 1;

    while(loop > 0) {

    System.out.println("this loop runs " + loop);

    loop = loop - 1;
        
    }

	//code ends here
}
}