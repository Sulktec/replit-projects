/*
example of how to use toLowerCase and toUpperCase
*/ 

public class Lesson3Ex4
{
    public static void main(String args[])
    {

        String anchorMan = "No touching of the HAIR or FACE";

        
        //ex1 converting to uppercase in print method
        System.out.println(anchorMan.toUpperCase());  // all caps because that is the most important rule 

       // ex2 converting in a temp variable, using to lowercase

        //String temp = anchorMan.toLowerCase();
        System.out.println("No touching of the HAIR or FACE".toUpperCase());
        
        //ex3 converting the string directly 

       // System.out.println("No touching of the HAIR or FACE".toUpperCase());


        //exercise: try to convert the string directly by replacing anchorMan in ex2

        
    }
}