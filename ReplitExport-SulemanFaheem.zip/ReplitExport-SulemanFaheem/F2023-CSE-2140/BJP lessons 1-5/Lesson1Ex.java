public class Lesson1Ex
{
    public static void main(String args[])
    {
        /*
            these can be used
            to make a multi line
            comment
        */

        
    	//code starts here
        //System.out.println();
        System.out.println("Hello world");
        //System.out.println();
        //System.out.print();
    	//code ends here
    }
}
