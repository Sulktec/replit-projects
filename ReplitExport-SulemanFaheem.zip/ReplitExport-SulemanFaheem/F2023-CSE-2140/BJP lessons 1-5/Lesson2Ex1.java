public class Lesson2Ex1
{
    public static void main(String args[])
    {
    	//code starts here

        // Java is strongly typed, this means each variable must be declared with a data type

        //add in int(stores interger numbers) and double variables (Stores floating point numbers)

        //variables should self document what they are storing, using a single word or multiplewords
        
        String morningThoughts = "Hello beautiful world";
        System.out.println(morningThoughts);
        
    
    
    	//code ends here
    }
}
