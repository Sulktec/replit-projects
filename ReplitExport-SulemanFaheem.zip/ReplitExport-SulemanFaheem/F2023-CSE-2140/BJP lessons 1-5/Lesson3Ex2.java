public class Lesson3Ex2
{
    public static void main(String args[])
    {
    	//code starts here

        String name = "Chicago Ted";
        int stringLength = name.length();

        System.out.println(stringLength); 


        /*exercise, create a new variable that holds a string
        then print the length of the string
        */

    
    	//code ends here
    }
}
