class Main {
  public static void main(String[] args) {
      TicTacToeNumber.run();
  }
}