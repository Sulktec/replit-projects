/*
 * Copyright 2020 Carson Cheng
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

//export * from "../../lib-fun-terminal/mod.ts";
//export * from "https://gitcdn.xyz/repo/cheng-code/fun-tsd-lib/master/lib-fun-terminal/mod.ts";
import * as expressive from "https://raw.githubusercontent.com/cheng-code/fun-tsd-lib/master/lib-fun-terminal/mod.ts";
