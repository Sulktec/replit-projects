"use strict";
// Programmer's Name:
// Program Name:
//////////////////////////////////////////////////////////////////////////
/*
 * Copyright 2012, 2016, 2020 Cheng
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     https://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ import { print, getInput } from "./cs10-txt-lib-0.6.ts";
import * as Fun from "./cs10-txt-lib-0.6.ts";
// Don't edit the import lines above, or you won't be able to write your program!
// Also, do not use the following variable and function names in your own code below:
//    print, getInput, javaSleep, currentDate, Fun
// Write your program below this line:
// ***********************************
let gameOver = false;
let screen = "splash screen";
//let screen = ""
let input = "";
let playerName = "";
let playerHealth = 100;
let youngMistyHealth = 100;
let maxPlayerHealth = 100;
let strength = 100;
let normalAttack = 0;
let strongAttack = 0;
let heal = 0;
let playerAttackRandom = 0;
let count = 0;
let coins = 0;
let mistyStrength = 75;
let mistyHealth = 0;
let mistyAttack = 0;
let coinsGotten = 0;
let nextScreen = "Main hub";
let fightChance = 0;
let alreadyFought = false;
let treeEssence = false;
let treeImmobilizer = false;
let dungeonKey = false;
let dungeonGate = false;
let mistGaurdianBeaten = false;
let mistGuardianHealth = 600;
let mistGuardianAttackRandom = 0;
let storeCostHealth = 65;
let storeCostStrength = 55;
let mistDragonHealth = 0;
let mistDragonAttackRandom = 0;
let mistDragonAttackChance = 0;
while(gameOver == false){
    if (screen == "Misty Fight") {
        print(" UNLUCKY, you encountered a Misty");
        mistyHealth = mistyStrength;
        playerHealth = maxPlayerHealth;
        mistyAttack = mistyStrength * 0.1;
        Fun.threadSleep(1000);
        screen = "Misty Battle";
    }
    if (screen == "Misty Battle" && mistyHealth >= 1 && playerHealth > 1) {
        playerHealth = playerHealth - mistyAttack;
        normalAttack = strength * 0.1;
        strongAttack = strength * 0.25;
        heal = strength * 0.1;
        print("\n\n                                                              .?J7JGPJ!.        .~..^.");
        print("                                              ?7. .~. 77^.:.  :!5#BGBBBPJ7.     :PGGGY");
        print("                                             ~GBG5G#GYBBGPBP?!G5G#G#BBBB&B5?~    7#BBG~:");
        print("                                         .!!!##B#B#BB#BB##GGBGGGGGGGGGGB#BB#G!.  .~YBBB5~.");
        print("                                        .Y#GBBGB#B#BGB#B#BBB#BGBGGBBBB##BGB#B#P5~   ^PBBBP^");
        print("                                    . .^JBGGGB#####B#BBBBG#GB##BBB#&#B#BGGGGGGGGBYYY^7BGGB!.");
        print("                                   JPYPGBB#BB##BBGBBGBB#B#GPPG##B##BBBBBBBBBBGGGGGBGG5BBBBG!");
        print("                               ~P5YGBGGGB##BGBBGBBBBBGGBBBBBB##BBGBBBBBBBBBBGB##B#BGBBG#GBGJ");
        print("                            .5PPBGGGGBBBB##BBBBBBBBB#BB#BBB#BBBGBBBBBBBBBBB#B##BBBBGGPPGBB7");
        print("                     .^~.  ^YBBGGGBBBBBBB##BBGBBBBGB#BBBBBBGBBBBBBBBBBBBBGBBBBBGBBBBGGGPGGP..");
        print("                .^~?GPGBGYPBGGGBBBBBBGB###BBBBBBBB###BGBBBBGBBBGBBBBBBBBBBBGBBBBBBBBBGBBBGGGG5^");
        print("               ~BB##BBB#&#BGPBBBBGBBBGB##BGBBBGBBB##GGBBBBGB##BBBBBGBGGGGBGGBBBBBBBBBBBBBGGGPBB^");
        print("              ~GPYGBGGBB#BPGGBBBBB##BGGBBBBBBBB#&#BBGBBBBBB#&BBBBBBBBBBBBGBBBBBBBBBB###BGBBGPPBJ:");
        print("              :^.  !PJPGPGBBBBGB###BBBGGGGB#B##B##BBBGB##B##BBBBBBBBBBBBBG##BBBBBBBBBBGBBBBBGGPGG5:");
        print("                   J#GGGGGBBBBBB##GBBBBBBGB##BBBBBBBBBB##BBBBBBBBBBBBBBBBBBBBBBBBBBBGBBBBBBBBGGPGB^");
        print("               .:.?#GGGBBBBB#B###BBGBBBBBBB#BBBBBBBBB###BBBBBBBBBBB####BBBBBBBBBBBBBBBBBBBBBBBGGPGJ.");
        print("      .:. ..^:.YBGGGGBBBBBGB##BBBBBBBBBBBBBBBBBBBB#####BBBBBBBBBB####BBBBBBBBBBBBBBBBBBBBBBBBBBGGPB5");
        print("   .~JPBP5PPBGBG#GBBBBBBBBBB##BBBBBBBBBBBBBBBBBBBB#&BBBBBBBBBBB##&#BBBBBBBBBBBBBBBBBBBBBBBBBBBBBGPGB!");
        print(" !5GB&BBB#GBGBBBBBGGGBBBBBBBBB#&#BBBBBBBBBBBBBBB####BBBBBBBBBB#&#BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBGGBY");
        print(" ^?BGJ?557^JPB##B#BBBBBBBBB#B##BBBBBBBBBBBBBBB#B##BBB##BBBBBB###BBBBBBBBBBBBBBBB##&##BBBBBBBBBBBBGGG.");
        print("   ^:    .^5BGB#BBBBBBBBBBB&#BBBBBBBBB##BBBBBB&#BBB###BBBBBB##BBBBBBBBBBBBBBBB|||||||BBBBBBBBBBBBBGP.");
        print("        :GBGB##BBBBBBBBBBBB##BBBBBBBB#&BBBBBBB&#BB#&BBBBBBBB###BBBBBBBBBBBBB||||||||||BBBBBBBBB#&@&GP");
        print("         YBPG##BBBBBBBBBB###BBBBBBBBBB&#BBBBBB######BBBBBBBB&#BBBBBBBBBBBBBB|||||||||BBBBBBBB&@@@BB7");
        print("       :J5BGBB##BBBBBBBBBB#&BBBBBBBBBB##BBBBBBBBB&##BBBBBB###BBBBBBBBBBBBBBB||||||||BBBBBBBB&#G&#BY");
        print("       .7BBGBB&BBBBBBBBBBB##BBBBBBBBBBBB##BBBBB#######BBBB####BBBBBBBBBBBBBB||||||BBBBBBBBBB&&##BY.");
        print("         ^P&B##BBBBBBBB###&#BBBBBBBBB###&#BBB##&##BB########&#####BBBBBBBBBBBBBBBBBBBBBBBBBBB#BP!");
        print("          ^7P##&#BBBBBB#&#BBBBBBB####&##&#####B#BBBBBBB###BBBBB#B###BBBBBBBBBBBBBBBBBBBBBBBBG57.");
        print("            .~7JPBBBB#######B##B#&####BB####B##BB#BB#####BB###B##BBBB####B##B##B##B##B#BG5J!:");
        print("                :^~~?J!!77PP?JJ??YJ55YPGPY55YJ5YJYJ??JJPG5?JJ!7JGGP5JYJ?YY?~!YY?JPYYY7^.");
        print("\nMisty has dealt", mistyAttack, "damage to you");
        print("\n\n||Your health is", playerHealth + "||");
        print("\n\n|| Enemies Health is", mistyHealth + "||");
        print("\n\n\n(1) Normal attack 75% chance it hits and it deals", normalAttack);
        print("\n(2) Strong attack: 45% chance of hitting and deals", strongAttack);
        print("\n(3) Heal: Heals", heal, "of health ");
        input = getInput();
        if (input == "1") {
            playerAttackRandom = Math.random();
            if (playerAttackRandom <= 0.75) {
                print("\n\n\n\nYou dealt", normalAttack, "damage to the the Misty");
                mistyHealth = mistyHealth - normalAttack;
                Fun.threadSleep(1000);
            } else {
                print("\n\n\n\nYou missed the attack");
                Fun.threadSleep(1000);
            }
        }
        if (input == "2") {
            playerAttackRandom = Math.random();
            if (playerAttackRandom <= 0.45) {
                print("\n\n\n\nyou dealt", strongAttack, "damage to the Misty");
                mistyHealth = mistyHealth - strongAttack;
            } else {
                print("\n\n\n\nYou missed the attack");
            }
            Fun.threadSleep(1000);
        }
        if (input == "3") {
            print("\n\n\n\nyou healed", heal, "health");
            playerHealth = playerHealth + heal;
            Fun.threadSleep(1000);
        }
    }
    if (screen == "Misty Battle" && playerHealth < 1) {
        print("\n\n__   __           ______ _          _");
        print("\\ \\ / /           |  _  (_)        | |");
        print(" \\ V /___  _   _  | | | |_  ___  __| |");
        print("  \\ // _ \\| | | | | | | | |/ _ \\/ _` |");
        print("  | | (_) | |_| | | |/ /| |  __/ (_| |");
        print("  \\_/\\___/ \\__,_| |___/ |_|\\___|\\__,_|");
        gameOver = true;
    }
    if (screen == "Misty Battle" && mistyHealth < 1) {
        mistyStrength = mistyStrength + 10;
        coinsGotten = mistyStrength * 0.6;
        coins = coins + coinsGotten;
        print("\nYOU WON, you get", coinsGotten, "coins");
        print("\nYou have", coins, "coins");
        screen = nextScreen;
    }
    if (screen == "splash screen") {
        print("        _     _             ___                   _   ");
        print("  /\\/\\ (_)___| |_ _   _    / __\\__  _ __ ___  ___| |_ ");
        print(" /    \\| / __| __| | | |  / _\\/ _ \\| '__/ _ \\/ __| __|");
        print("/ /\\/\\ \\ \\__ \\ |_| |_| | / / | (_) | | |  __/\\__ \\ |_ ");
        print("\\/    \\/_|___/\\__|\\__, | \\/   \\___/|_|  \\___||___/\\__|");
        print("                  |___/                               ");
        print("");
        print("(1) type 1 to start (2) type 2 to quit");
        input = getInput();
        if (input == "1") {
            screen = "player name";
        }
        if (input == "2") {
            print("quiting...");
            gameOver = true;
        }
    }
    if (screen == "player name") {
        print("Please enter your name");
        playerName = getInput();
        print("Hi", playerName);
        print("(1) Go to first fight");
        count = 0;
        input = getInput();
        if (input == "1") {
            screen = "first fight";
        }
    }
    if (screen == "first fight" && youngMistyHealth > 0 && playerHealth > 0) {
        playerHealth = playerHealth - 5;
        normalAttack = strength * 0.1;
        strongAttack = strength * 0.25;
        heal = strength * 0.1;
        print("\n\n\nYou You are getting attacked by a Young Misty \nChoose your attack");
        if (count < 1) {
            print("\nYoung Misty deals 5 health of damage and has 100 health");
            print("NOTE: Your health can go below zero and you have a one chance to kill the enemy but if you don't you will die.");
        } else {}
        print("\n\n                                       @     @:@  @:@       @");
        print("                                       @@ @:::::::::@@@@@  @:@");
        print("                                           @::::@@@::::@:::::@ @@::");
        print("                                  @@   @@@     @@@@@@@@@@@@@::::::@");
        print("                                  @::@@:@@      @@@@@@@@     @  @@:::@   @");
        print("                           @:@ @::::@@@@@@@@@@@@@@@@@@@@ @    @   @:::@@:@");
        print("                               @@   @@@@@@@@@@@@@@@@@@@@@@@@::@   @@@::@");
        print("                             @    @    @@  @@@@@@@@@@@@@@@@@@:@@     @:@@@:");
        print("                           ::::@@::          @@@@@@@@@@@@@@@@@@@@:   @:::::@");
        print("                         :@@@@@@@@@@@:@@@@@ @@@@@@@@@@@@@@@@@@@@@:@   :::::@");
        print("                         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@:@ @@::::@");
        print("                      @@@@:@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@:@");
        print("                         @:@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@     @@@@@");
        print("                        @@:@@ @@@  @@@@@@@@@@@@@@@@@@@@      @@@@@@@@@@   @:@");
        print("                         @::@           @@@@@@@@@@@@@@@@@@     @@@@@@::@    @");
        print("                           @:@            @@@@@@@@@@@@@@@@@@@    @@@@::::@   @");
        print("                           ::@  :@             @@@@@@@@@@@@@@@      @::::@");
        print("                           @@@ $$$$      @$:@   @@@@@@@@@@@@@@@@@   @::@@@@");
        print("                             @ @$$$@    @$$$$:     @@@@@@@@@@@@@   @::@@");
        print("                                $$ @    $$$$$$$         @@@@@@@@");
        print("                                         :$$$$@    @@@    @@        @:@");
        print("                                                   @:            @    @");
        print("\n\nMisty has dealt 5 damage to you");
        print("\n\n||Your health is", playerHealth + "||");
        print("\n\n|| Enemies Health is", youngMistyHealth + "||");
        print("\n\n\n(1) Normal attack 75% chance it hits and it deals", normalAttack);
        print("\n(2) Strong attack: 45% chance of hitting and deals", strongAttack);
        print("\n(3) Heal: Heals", heal, "of health ");
        print("\n(4)items: No items found");
        count = count + 1;
        input = getInput();
        if (input == "1") {
            playerAttackRandom = Math.random();
            if (playerAttackRandom <= 0.75) {
                print("\n\n\n\nYou dealt", normalAttack, "damage to the Young Misty");
                youngMistyHealth = youngMistyHealth - normalAttack;
            } else {
                print("\n\n\n\nYou missed the attack");
            }
            Fun.threadSleep(1000);
        }
        if (input == "2") {
            playerAttackRandom = Math.random();
            if (playerAttackRandom <= 0.45) {
                print("\n\n\n\nyou dealt", strongAttack, "damage to the young Misty");
                youngMistyHealth = youngMistyHealth - strongAttack;
            } else {
                print("\n\n\n\nYou missed the attack");
            }
            Fun.threadSleep(1000);
        }
        if (input == "3") {
            print("\n\n\n\nyou healed", heal, "health");
            playerHealth = playerHealth + heal;
            Fun.threadSleep(1000);
        }
    }
    if (screen == "first fight" && playerHealth <= 0) {
        print("You died");
        gameOver = true;
    }
    if (screen == "first fight" && youngMistyHealth <= 0) {
        print("\nYOU WON, you get 100 coins");
        coins = coins + 100;
        screen = "Main hub";
    }
    if (screen == "Main hub") {
        print("\nWhere do you want to go");
        print("\n(1)Go to Mist Tower \n(2)Go to Upgrade Store \n(3)Go to Misty Forest");
        input = getInput();
        if (input == "1") {
            screen = "Mist Tower";
        }
        if (input == "2") {
            screen = "shop";
        }
        if (input == "3") {
            screen = "Misty Forest Entrance";
        }
    }
    //Mist Tower
    if (screen == "Mist Tower" && mistGaurdianBeaten == false) {
        print("             _,._");
        print("           ,'   ,`-.");
        print("|.        /     |\\  `.");
        print("\\ \\      (  ,-,-` ). `-._ __");
        print(" \\ \\      \\|\\,'     `\\  /'  `\\");
        print("  \\ \\      ` |, ,  /  \\ \\     \\");
        print("   \\ \\         `,_/`, /\\,`-.__/`.");
        print("    \\ \\            | ` /    /    `-._");
        print("     \\\\\\           `-/'    /         `-.");
        print("      \\\\`/ _______,-/_   /'             \\");
        print("     ---'`|       |`  ),' `---.  ,       |");
        print("      \\..-`--..___|_,/          /       /");
        print("                 |    |`,-,...,/      ,'     ");
        print("                 \\    | |_|   /     ,' __  r-'',");
        print("                  |___|/  |, /  __ /-''  `'`)  |  ");
        print("               _,-'   ||__\\\\ /,-' /     _,.--|  (");
        print("            .-'       )   `(_   / _,.-'  ,-' _,/");
        print("\nAs you approach the entrance of the tower, the Mist Guardian falls from the sky.");
        Fun.threadSleep(1000);
        print("");
        print("The Mist Guardian deals 40 damage every attack but has terrible accuracy and has 500 health.");
        print("\n(Has a 60% chance of hitting you)");
        Fun.threadSleep(3000);
        mistGuardianHealth = 500;
        playerHealth = maxPlayerHealth;
        count = 0;
        screen = "Mist Guardian Tower Boss";
    }
    if (screen == "Mist Guardian Tower Boss" && playerHealth > 0 && mistGuardianHealth > 0) {
        mistGuardianAttackRandom = Math.random();
        normalAttack = strength * 0.1;
        strongAttack = strength * 0.25;
        heal = strength * 0.1;
        print("\n      _,.");
        print("      ,` -.)");
        print("     ( _/-\\\\-._");
        print("    /,|`--._,-^|            ,");
        print("    \\_| |`-._/||          ,'|");
        print("      |  `-, / |         /  /");
        print("      |     || |        /  /");
        print("       `r-._||/   __   /  /");
        print("   __,-<_     )`-/  `./  /");
        print("  '  \\   `---'   \\   /  /");
        print("      |           |./  /");
        print("      /           //  /");
        print("  \\_/' \\         |/  /");
        print("   |    |   _,^-'/  /");
        print("   |    , ``  (\\/  /_");
        print("    \\,.->._    \\X-=/^");
        print("    (  /   `-._//^`");
        print("     `Y-.____(__}");
        print("      |     {__)");
        print("            ()");
        if (mistGuardianAttackRandom > 0.40 && count > 0) {
            print("\n(Mist Guardian has dealt", 45, "damage to you)");
            playerHealth = playerHealth - 40;
        } else if (mistGuardianAttackRandom <= 0.40) {
            print("\n(Mist Guardian Missed)");
        }
        print("\n\n||Your health is", playerHealth + "||");
        print("\n\n|| Mist Guardian Health is", mistGuardianHealth + "||");
        print("\n\n(1) Normal attack 75% chance it hits and it deals", normalAttack);
        print("\n(2) Strong attack: 45% chance of hitting and deals", strongAttack);
        print("\n(3) Heal: Heals", heal, "of health ");
        count = count + 1;
        input = getInput();
        if (input == "1") {
            playerAttackRandom = Math.random();
            if (playerAttackRandom <= 0.75) {
                print("\n\n\n\nYou dealt", normalAttack, "damage to the the Mist Guardian ");
                mistGuardianHealth = mistGuardianHealth - normalAttack;
                Fun.threadSleep(1000);
            } else {
                print("\n\n\n\nYou missed the attack");
                Fun.threadSleep(1000);
            }
        }
        if (input == "2") {
            playerAttackRandom = Math.random();
            if (playerAttackRandom <= 0.45) {
                print("\n\n\n\nyou dealt", strongAttack, "damage to the Mist Guardian ");
                mistGuardianHealth = mistGuardianHealth - strongAttack;
            } else {
                print("\n\n\n\nYou missed the attack");
            }
            Fun.threadSleep(1000);
        }
        if (input == "3") {
            print("\n\n\n\nyou healed", heal, "health");
            playerHealth = playerHealth + heal;
            Fun.threadSleep(1000);
        }
    }
    if (screen == "Mist Guardian Tower Boss" && playerHealth < 1) {
        print("\n\n__   __           ______ _          _");
        print("\\ \\ / /           |  _  (_)        | |");
        print(" \\ V /___  _   _  | | | |_  ___  __| |");
        print("  \\ // _ \\| | | | | | | | |/ _ \\/ _` |");
        print("  | | (_) | |_| | | |/ /| |  __/ (_| |");
        print("  \\_/\\___/ \\__,_| |___/ |_|\\___|\\__,_|");
        gameOver = true;
    }
    if (screen == "Mist Guardian Tower Boss" && mistGuardianHealth < 1) {
        print("\nYOU WON");
        print("\nTime to fight the Mist Dragon");
        Fun.threadSleep(2000);
        mistGaurdianBeaten = true;
        screen = "Mist Tower";
    }
    if (screen == "Mist Tower" && mistGaurdianBeaten == true) {
        print("\nYou enter the tower and see a large collection of stairs that probably lead to the roof of the tower");
        print("\n(1)Climb the stairs to the roof \n(2)Go back");
        input = getInput();
        if (input == "1") {
            screen = "Mist Dragon";
        }
        if (input == "2") {
            screen == "Main hub";
        }
    }
    if (screen == "Mist Dragon") {
        print("\n                                       \\/");
        print("                                       ^`'.");
        print("                                       ^   `'.");
        print("             (                         ^      `'.");
        print("           )  )        \\/              ^         `'.");
        print("         (   ) @       /^              ^            `'.");
        print("       )  )) @@  )    /  ^             ^               `'.");
        print("      ( ( ) )@@      /    ^            ^                  `'.");
        print("    ))  ( @@ @ )    /      ^           ^                     `'.");
        print("   ( ( @@@@@(@     /       |\\_/|,      ^                        `'.");
        print("  )  )@@@(@@@     /      _/~/~/~|C     ^                           `'.");
        print("((@@@(@@@@@(     /     _(@)~(@)~/\\C    ^                              `'.");
        print("  ))@@@(@@)@@   /     /~/~/~/~/`\\~`C   ^             __.__               `'.");
        print("   )@@@@(@@)@@@(     (o~/~o)^,) \\~ \\C  ^          .' -_'-'\"...             `.");
        print("    ( (@@@)@@@(@@@@@@_~^~^~,-/\\~ \\~ \\C/^        /`-~^,-~-`_~-^`;_           `.");
        print("      @ )@@@(@@@@@@@   \\^^^/  (`^\\.~^ C^.,  /~^~^~^/_^-_`~-`~-~^\\- /`'-./`'-. ;");
        print("       (@ (@@@@(@@      `''  (( ~  .` .,~^~^-`-^~`/'^`-~ _`~-`_^-~\\         ^^");
        print("           @jgs@             (((` ~ .-~-\\ ~`-_~`-/_-`~ `- ~-_- `~`;");
        print("          /                 /~((((` . ~-~\\` `  ~ |:`-_-~_~`  ~ _`-`;");
        print("         /                 /~-((((((`.\\-~-\\ ~`-`~^\\- ^_-~ ~` -_~-_`~`;");
        print("        /                 /-~-/(((((((`\\~-~\\~`^-`~`\\ -~`~\\-^ -_~-_`~-`;");
        print("       /                 /~-~/  `((((((|-~-|((`.-~.`Y`_,~`\\ `,- ~-_`~-`;");
        print("      /              ___/-~-/     `\"\"\"\"|~-~|\"''    /~-^ .'    `:~`-_`~-~`;");
        print("     /         _____/  /~-~/           |-~-|      /-~-~.`      `:~^`-_`^-:");
        print("    /    _____/        ((((            ((((      (((((`           `:~^-_~-`;");
        print("    \\___/                                                          `:_^-~`;");
        print("                                                                    `:~-^`:");
        print("                                                                  ,`~-~`,`");
        print("                                                                 ,\"`~.,'");
        print("                                                               ,\"-`,\"`");
        print("                                                             ,\"_`,\"");
        print("                                                            ,\",\"`");
        print("                                                         ;~-~_~~;");
        print("                                                          '. ~.'");
        print("\nYou reach the roof of the tower and are greeted by a roar from the Mist Dragon. The mist Dragon has 1000 health.");
        Fun.threadSleep(2000);
        print("\n(Mist dragon deals 35 damage with his regular attack and has a 0% chance in missing it, \nhas a strong attack that deals 110 damage but has a 75% chance missing it, can heal 55 health)");
        Fun.threadSleep(2000);
        count = 0;
        playerHealth = maxPlayerHealth;
        mistDragonHealth = 1000;
        screen = "Mist Dragon Boss";
    }
    if (screen == "Mist Dragon Boss") {
        mistDragonAttackRandom = Math.random();
        mistDragonAttackChance = Math.random();
        normalAttack = strength * 0.1;
        strongAttack = strength * 0.25;
        heal = strength * 0.1;
        print("     |\\                                                              /|");
        print("      | \\                                                            / |");
        print("      |  \\                                                          /  |  ");
        print("      |   \\                                                        /   |    ");
        print("     |    \\                                                      /    |     ");
        print("_____)     \\                                                    /     (____ ");
        print("\\           \\                                                  /          / ");
        print(" \\           \\                                                /          /  ");
        print("  \\           `--_____                                _____--'          /   ");
        print("   \\                  \\                              /                 /    ");
        print("____)                  \\                            /                 (____ ");
        print("\\                       \\        /|      |\\        /                      / ");
        print(" \\                       \\      | /      \\ |      /                      /  ");
        print("  \\                       \\     ||        ||     /                      /   ");
        print("   \\                       \\    | \\______/ |    /                      /    ");
        print("    \\                       \\  / \\        / \\  /                      /     ");
        print("    /                        \\| (*\\  \\/  /*) |/                       \\     ");
        print("   /                          \\   \\| \\/ |/   /                         \\    ");
        print("  /                            |   |    |   |                           \\   ");
        print(" /                             |\\ _\\____/_ /|                            \\  ");
        print("/______                       | | \\)____(/ | |                      ______\\ ");
        print("       )                      |  \\ |/vv\\| /  |                     (        ");
        print("      /                      /    | |  | |    \\                     \\       ");
        print("     /                      /     ||\\^^/||     \\                     \\      ");
        print("    /                      /     / \\====/ \\     \\                     \\     ");
        print("   /_______           ____/      \\________/      \\____           ______\\    ");
        print("           )         /   |       |  ____  |       |   \\         (           ");
        print("           |       /     |       \\________/       |     \\       |           ");
        print("           |     /       |       |  ____  |       |       \\     |           ");
        print("           |   /         |       \\________/       |         \\   |           ");
        print("           | /            \\      \\ ______ /      /______..    \\ |           ");
        print("           /              |      \\\\______//      |        \\     \\           ");
        print("                          |       \\ ____ /       |LLLLL/_  \\                ");
        print("                          |      / \\____/ \\      |      \\   |               ");
        print("                          |     / / \\__/ \\ \\     |     __\\  /__             ");
        print("                          |    | |        | |    |     \\      /             ");
        print("                          |    | |        | |    |      \\    /              ");
        print("                          |    |  \\      /  |    |       \\  /               ");
        print("                          |     \\__\\    /__/     |        \\/                ");
        print("                         /    ___\\  )  (  /___    \\                         ");
        print("                        |/\\/\\|    )      (    |/\\/\\|                        ");
        print("                        ( (  )                (  ) )");
        if (count > 0) {
            if (mistDragonAttackRandom < 0.25) {
                if (mistDragonAttackChance < 0.25) {
                    playerHealth - 110;
                    print("\nMist dragon has dealt 110 damage");
                }
            } else if (mistDragonAttackRandom < 0.25) {
                print("\nMist Dragon Missed");
            }
            if (mistDragonAttackRandom > 0.25 && mistDragonAttackRandom < 0.45 && mistDragonHealth < 600) {
                mistDragonHealth = mistDragonHealth + 55;
                print("\nMist Dragon has healed 55 health");
            } else if (mistDragonAttackRandom > 0.25) {
                playerHealth = playerHealth - 35;
                print("Mist Dragon has dealt 35 damage");
            }
        }
        print("\n\n||Your health is", playerHealth + "||");
        print("\n\n|| Mist Dragon Health is", mistDragonHealth + "||");
        print("\n\n(1) Normal attack 75% chance it hits and it deals", normalAttack);
        print("\n(2) Strong attack: 45% chance of hitting and deals", strongAttack);
        print("\n(3) Heal: Heals", heal, "of health ");
        count = count + 1;
        input = getInput();
        if (input == "1") {
            playerAttackRandom = Math.random();
            if (playerAttackRandom <= 0.75) {
                print("\n\n\n\nYou dealt", normalAttack, "damage to the the Mist Dragon");
                mistDragonHealth = mistDragonHealth - normalAttack;
                Fun.threadSleep(1000);
            } else {
                print("\n\n\n\nYou missed the attack");
                Fun.threadSleep(1000);
            }
        }
        if (input == "2") {
            playerAttackRandom = Math.random();
            if (playerAttackRandom <= 0.45) {
                print("\n\n\n\nyou dealt", strongAttack, "damage to the Mist Dragon");
                mistDragonHealth = mistDragonHealth - strongAttack;
            } else {
                print("\n\n\n\nYou missed the attack");
            }
            Fun.threadSleep(1000);
        }
        if (input == "3") {
            print("\n\n\n\nyou healed", heal, "health");
            playerHealth = playerHealth + heal;
            Fun.threadSleep(1000);
        }
    }
    if (screen == "Mist Dragon Boss" && playerHealth < 1) {
        print("\n\n__   __           ______ _          _");
        print("\\ \\ / /           |  _  (_)        | |");
        print(" \\ V /___  _   _  | | | |_  ___  __| |");
        print("  \\ // _ \\| | | | | | | | |/ _ \\/ _` |");
        print("  | | (_) | |_| | | |/ /| |  __/ (_| |");
        print("  \\_/\\___/ \\__,_| |___/ |_|\\___|\\__,_|");
        gameOver = true;
    }
    if (screen == "Mist Dragon Boss" && mistDragonHealth < 1) {
        screen = "Ending";
    }
    if (screen == "Ending") {
        let stopAmount = 500;
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                             __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                                             \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                                              \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                                              _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                                            _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                                            -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                           __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                                         \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                                          \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                                          _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                                        _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                                        -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                       __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                                     \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                                      \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                                      _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                                    _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                                    -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                    __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                                   \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                                    \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                                    _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                                  _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                                  -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                  __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                                 \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                                  \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                                  _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                                _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                                -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                               \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                                \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                                _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                              _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                              -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                              __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                             \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                              \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                              _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                             _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                             -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                            __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                           \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                            \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                            _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                          _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                          -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                          __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                         \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                          \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                          _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                        _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                        -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                        __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                       \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                        \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                        _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                      _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                      -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                      __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                     \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                      \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                      _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                    _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                    -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                  __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                                 \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                                  \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                                  _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                                _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                                -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print(" \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                             __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                             \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                              \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                              _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                            _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                            -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                          __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                         \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                          \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                          _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                        _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                        -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                      __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                     \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                      \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                      _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                    _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                    -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                  __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                                 \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                                  \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                                  _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                                _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                                -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                              __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                             \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                              \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                              _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                            _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                            -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                          __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                         \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                          \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                          _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                        _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                        -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                     __   __   ___    _   _          __      __ ___    _  _  ");
        print("                                    \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                     \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                     _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                                   _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                                   -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                __   __   ___    _   _          __      __ ___    _  _  ");
        print("                               \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                                \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                                _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                              _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                             -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        Fun.threadSleep(stopAmount);
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                          __   __   ___    _   _          __      __ ___    _  _  ");
        print("                         \\ \\ / /  / _ \\  | | | |    o O O\\ \\    / /|_ _|  | \\| |");
        print("                          \\ V /  | (_) | | |_| |   o      \\ \\/\\/ /  | |   | .` |");
        print("                          _|_|_   \\___/   \\___/   TS__[O]  \\_/\\_/  |___|  |_|\\_|");
        print("                        _| --- |_|-----|_|-----| {======|_|-----|_|-----|_|-----|");
        print("                          -`-0-0-'-`-0-0-'-`-0-0-'./o--000'-`-0-0-'-`-0-0-'-`-0-0-'");
        gameOver = true;
    }
    //shop
    if (screen == "shop") {
        print("\n                ______________");
        print("    __,.,---'''''              '''''---..._");
        print(" ,-'             .....:::''::.:            '`-.");
        print("'           ...:::.....       '");
        print("            ''':::'''''       .               ,");
        print("|'-.._           ''''':::..::':          __,,-");
        print(" '-.._''`---.....______________.....---''__,,-");
        print("      ''`---.....______________.....---''");
        print("\n\n\nHey", playerName, "What do you want do?");
        print("\n\nStrength:", strength, "\nMax Health:", maxPlayerHealth, "\nYou have", coins, "coins", "\n\n(1) Upgrade strength COSTS: ", storeCostStrength, "\n(2) Upgrade health COSTS: ", storeCostHealth, "\n(3)Reset Misty strength COSTS:", mistyStrength, "\n(4) Go back");
        input = getInput();
        if (input == "1") {
            screen = "Upgrade Strength";
        }
        if (input == "2") {
            screen = "Upgrade Health";
        }
        if (input == "3") {
            screen = "Reset Misty Strength";
        }
        if (input == "4") {
            screen = "Main hub";
        }
    }
    if (screen == "Reset Misty Strength" && coins >= mistyStrength) {
        print("\nAre you sure you want to reset Misty strength level?\n This will result in lower leveled enemies that give low amounts of coins.");
        print("\n(1)Yes\n(2)No go back");
        input = getInput();
        if (input == "1") {
            print("Misty Strength level have been resetted");
            mistyStrength = 75;
            coins = coins - mistyStrength;
            Fun.threadSleep(1000);
            screen = "shop";
        }
    } else if (screen == "Reset Misty Strength" && coins < mistyStrength) {
        print("You don't have enough coins");
        Fun.threadSleep(1000);
        screen = "shop";
    }
    if (screen == "Upgrade Strength" && coins >= storeCostStrength) {
        coins = coins - storeCostStrength;
        strength = strength + 25;
        storeCostStrength = storeCostStrength + 35;
        print("\n\nYour strength is now", strength);
        print("You have", coins, "coins");
        Fun.threadSleep(1000);
        screen = "shop";
    } else if (screen == "Upgrade Strength" && coins < storeCostStrength) {
        print("\n\nYou don't have enough coins");
        Fun.threadSleep(1000);
        screen = "shop";
    }
    if (screen == "Upgrade Health" && coins >= storeCostHealth) {
        coins = coins - storeCostHealth;
        maxPlayerHealth = maxPlayerHealth + 25;
        storeCostHealth = storeCostHealth + 25;
        print("\n\nYour max health is now", storeCostHealth);
        print("You have", coins, "coins");
        Fun.threadSleep(1000);
        screen = "shop";
    } else if (screen == "Upgrade Health" && coins < storeCostHealth) {
        print("\n\nYou don't have enough coins");
        Fun.threadSleep(1000);
        screen = "shop";
    }
    //Misty Forest
    if (screen == "Misty Forest Entrance") {
        print("  ______ ______ ______ ______ ______ ______ ______ ______      ");
        print(" |______|______|______|______|______|______|______|______|     ");
        print(" | |  \\/  (_)   | |         |  ____|                | | | |    ");
        print(" | | \\  / |_ ___| |_ _   _  | |__ ___  _ __ ___  ___| |_| |    ");
        print(" | | |\\/| | / __| __| | | | |  __/ _ \\| '__/ _ \\/ __| __| |    ");
        print(" | | |  | | \\__ \\ |_| |_| | | | | (_) | | |  __/\\__ \\ |_| |    ");
        print(" | |_|  |_|_|___/\\__|\\__, | |_|  \\___/|_|  \\___||___/\\__| |    ");
        print(" | |                  __/ |                             | |    ");
        print(" |_|    ____  _______|___/      __     _____  ______ _  |_|    ");
        print(" | |   |  _ \\|  ____\\ \\        / /\\   |  __ \\|  ____| | | |    ");
        print(" | |   | |_) | |__   \\ \\  /\\  / /  \\  | |__) | |__  | | | |    ");
        print(" | |   |  _ <|  __|   \\ \\/  \\/ / /\\ \\ |  _  /|  __| | | | |    ");
        print(" | |   | |_) | |____   \\  /\\  / ____ \\| | \\ \\| |____|_| | |    ");
        print(" | |   |____/|______|   \\/  \\/_/    \\_\\_|  \\_\\______(_) | |    ");
        print(" | |                                                    | |  ");
        print(" |_|____ ______ ______ ______ ______ ______ ______ _____|_|");
        print(" |______|______|______|______|______|______|______|______| ");
        print("\n(1)Go in \n(2)Go back");
        input = getInput();
        if (input == "1") {
            screen = "Misty Forest Crossroads CHECK";
        }
        if (input == "2") {
            screen = "Main hub";
        }
    }
    if (screen == "Misty Forest Crossroads CHECK") {
        fightChance = Math.random();
        if (fightChance <= 0.25) {
            nextScreen = "Misty Forest Crossroads";
            screen = "Misty Fight";
        }
        if (fightChance > 0.25) {
            screen = "Misty Forest Crossroads";
        }
    }
    if (screen == "Misty Forest Crossroads") {
        print("\nYou think there two paths to take, one on your left and one on your right. You do not know what each path contain");
        print("\n(1)Go left \n(2)Go right \n(3)Go back to entrance");
        input = getInput();
        if (input == "1") {
            screen = "Left path CHECK";
        }
        if (input == "2") {
            screen = "Right path CHECK";
        }
        if (input == "3") {
            screen = "Misty Forest Entrance";
        }
    }
    // Left Path
    if (screen == "Left path CHECK") {
        fightChance = Math.random();
        if (fightChance <= 0.25) {
            nextScreen = "Left path";
            screen = "Misty Fight";
        }
        if (fightChance > 0.25) {
            screen = "Left path";
        }
    }
    if (screen == "Left path") {
        print("\n\nPY?5G?JP5G?~!75PB&!YGY?!P5!~755PJ77J??Y??JJ7??J7!7!~7?!?Y?JJ?77~~~J?~7~!JBB~!Y?G7G@P!JJP7Y&G!~~~!?JP");
        print("7?YP#G?7YBP7Y7~G@#PY77P5?!!YGPJ?J55Y5YJ?Y?JPBY?5PJ577Y?!?55?PG7J??!J?J~~~?&P~J5B?&&5?7~PB&B?~!!~7?YJ");
        print("Y55Y5GBPJYBPJ?7#&P7!!PY!JPGG5555PGB5??JYJ7YYB#YJP5PPYYYJYYG??PPYP5!?J5!7Y?Y&GJ7PB@#!~~?&&Y!Y7JJ!7?7!");
        print("YYY555BB#B#&P7P@G^YYGGPPY7JP5Y7J5B#J!YY7?JYJ?P#PYJ?5PGGPGB#PGYB#PYPP~5GJYYPP&P~~B@5^7G&&P??PYY7!7?~~");
        print("JYPYY?GG55JY##&&PYPB&#PYYYYYJJYYYYB##J~~!GY7?75#5!!!!!7!PBYJ?JYPB#B#GGG&&#J!J##?G@PY&@BJ55JGPY?7!J7!");
        print("!5P?JPBGY!!7Y&@&&#G5JJ7?777!!7777?JYG#B5?5BJ~~~JB5!~~~~YB57!!77!?5BY7JBGYG##57G&&&&@&YJPP5PGJJY?!J7!");
        print("~YBJY#B?~!!!!#@&GJJ?7???7?7!7J??7?7!7?5B###&G5JJP&B55YG#GY!~7J7!!~7PP?GY^~!5&&#&&&&&J~!#PGP!~~!JYY?~");
        print("JY5YPB!~~~~~P&@B?!Y77JJ??Y?7!!J?J7!!!~~!7?J55GB###&&&###B5J?7!~~~~~~?G#G!~~~!Y#@&&@B~~J#P?~~~~~~7YY?");
        print("Y7~G#P~~~~~Y&&&??YY~~7Y!7Y?~~?Y?~~~~~~~~~~~~~~!!7?Y5G#####G7~~~~~~~~~~7PBY!~~~!B@&@B7PG?~~~~~~~~~J55");
        print("!~~J&P~~~~PB#@#!~J5?~!Y7~!JJJ5?~~~~~~~~~~~~~~~~~~~~~~7JG##&G7~~~~~~~~~~~?PBPJ?!!#&&&#Y~~~~~~~~~~~?5J");
        print("~~~!BP~7YGP7#@G~~~?57!Y7~~755?~~~~~~~~~~~~~~~~~~~~~~~~~~YPG##5!~~~~~~~~~~~7P###B#&&@P~~~~~~~~~~~!Y57");
        print("~~~~P#P#5!~?&@J~~~~JYYJ~~7YY7~~~~~~~~~~~~~~~~~~~~~~~~~~~JJ!?B&G7~~~~~~~~~~~~7####&&&#!~~~~~~~~~!J5Y!");
        print("~~~~P&#J~~~P@&!~~~~!Y57~7YY7~~~~~~~~~~~~~~~~~~~~~~~~~~~!YY!~!B&B7~~~~~~~~~~~~?###GB@&Y~~~~~~~~!J55J~");
        print("~~~~G&#!~~7&@G~~~~~~?57~J57~~~~~~~~~~~~~~~~~~~~~~~~~~~!J5?~~~?B&B7~~~~~~~~~~~~G##Y7&&&!~~~~~~!Y555?~");
        print("~~~5#B#5~~B@&7~~~~~!YJ!7Y5!~~~~~~~~~~~~~~~~~~~~!!!!7??Y5?~~~~~!G&#J~~~~~~~~~~~P##P~5@@P!77?JJYYYYY7~");
        print("77Y#B5B#YJ&@G~~~!!!JY?7Y55?!!~!!!!!!7777777?JJYYYY55YYYY?!!777!?###5!!777??JY5####55&&&PYYY55555555?");
        print("#########&&&#YYY555555YYYYYYYYY55PPGGGGGGGPPP55555555555PPGGGBB#####BGGGGB#########&&&&&#BBB########");
        print("####&&&&&&&&&#########BGGGBBB#################################################&&&&&&&&&&&&&&########");
        print("\nThere is a straight path to follow but you are surrounded by trees of the Misty Forest.\nYou wonder if there's anything off the path. Maybe something that could help you.");
        print("\n(1)Do you go into the trees \n(2)stay on path \n(3)Go back to the crossroads");
        input = getInput();
        if (input == "1") {
            screen = "into the trees";
        }
        if (input == "2") {
            screen = "Giant Lake";
        }
        if (input == "3") {
            screen = "Misty Forest Crossroads CHECK";
        }
    }
    if (screen == "into the trees") {
        print("\n      _____");
        print("     `.___,'");
        print("      (___)");
        print("      <   >");
        print("       ) (");
        print("      /`-.\\");
        print("     /     \\");
        print("    / _    _\\");
        print("   :,' `-.' `:");
        print("   |         |");
        print("   :         ;");
        print("    \       /");
        print("     `.___.' ");
        print("\nYou explore into the trees and found an item called the tree immobilizer on top a dead tree. You take the item.");
        print("\nNow what do you want to do?");
        treeImmobilizer = true;
        print("\n(1)Go back to Left Entrance \n(2)explore more");
        input = getInput();
        if (input == "1") {
            screen = "Left path CHECK";
        }
        if (input == "2") {
            screen = "death";
        }
    }
    //or
    //Giant Lake
    if (screen == "Giant Lake" && treeEssence == false || screen == "Giant Lake" && dungeonKey == true) {
        print("\nYou find this giant lake with clear water in it.");
        print("\n\n              ,.  _~-.,               .					");
        print("           ~.`_ \\/,_. \\_						");
        print("          / ,,_>@`,__`~.)             |           .			");
        print("          | |  @@@@.  :,! .           .          .			");
        print("          |/   ^^@     .!  \\          |         /			");
        print("          `. .^^^     ,.    .         |        .             .		");
        print("           .^^^   .          \\                /          .		");
        print("          .^^^       .  .     \\       |      /       . .		");
        print(".,.,.     ^^^             ` .   .,+~.`^`.~+,.     , .			");
        print("&&&&&&,  ,^^^^.  . ._ ..__ _  ..             .. ._ __ ____ __ _ .. .  .  ");
        print("%%%%%%%%%^^^^^^%%&&;_,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,   ");
        print("&&&&&%%%%%%%%%%%%%%%%%%&&;,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~= ");
        print("%%%%%&&&&&&&&&&&%%%%&&&_,.;^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__, ");
        print("%%%%%%%%%&&&&&&&&&-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-==--^.~=-.,__,.-=~. ");
        print("##mjy#####*:.								");
        print("_,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,.-=~.`^`.~=-.,__,.-=~. ");
        print("										");
        print("~`.^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^ ");
        print("\n(1)Drink the water  \n(2)swim to continue \n(3)explore the water \n(4)Go back");
        input = getInput();
        if (input == "1") {
            screen = "death";
        }
        if (input == "2") {
            print("\nYou swim across the entire lake but you realize you suck at swimming so you go back to the shore.");
            Fun.threadSleep(1000);
        }
        if (input == "3") {
            screen = "explore lake";
        }
        if (input == "4") {
            screen = "Left path CHECK";
        }
    } else if (screen == "Giant Lake" && treeEssence == true && dungeonKey == false) {
        print("\nYou find this giant lake with clear water in it.");
        print("\n\n              ,.  _~-.,               .					");
        print("           ~.`_ \\/,_. \\_						");
        print("          / ,,_>@`,__`~.)             |           .			");
        print("          | |  @@@@.  :,! .           .          .			");
        print("          |/   ^^@     .!  \\          |         /			");
        print("          `. .^^^     ,.    .         |        .             .		");
        print("           .^^^   .          \\                /          .		");
        print("          .^^^       .  .     \\       |      /       . .		");
        print(".,.,.     ^^^             ` .   .,+~.`^`.~+,.     , .			");
        print("&&&&&&,  ,^^^^.  . ._ ..__ _  ..             .. ._ __ ____ __ _ .. .  .  ");
        print("%%%%%%%%%^^^^^^%%&&;_,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,   ");
        print("&&&&&%%%%%%%%%%%%%%%%%%&&;,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~= ");
        print("%%%%%&&&&&&&&&&&%%%%&&&_,.;^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__, ");
        print("%%%%%%%%%&&&&&&&&&-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-==--^.~=-.,__,.-=~. ");
        print("##mjy#####*:.								");
        print("_,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,.-=~.`^`.~=-.,__,.-=~. ");
        print("										");
        print("~`.^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^`.~=-.,__,.-=~.`^ ");
        print("\n(1)Drink the water  \n(2)swim to continue \n(3)explore the water \n(4)Go back \n(5)Drop Tree essence into the lake");
        input = getInput();
        if (input == "1") {
            screen = "death";
        }
        if (input == "2") {
            print("\nYou swim across the entire lake but you realize you suck at swimming so you go back to the shore.");
            Fun.threadSleep(2000);
        }
        if (input == "3") {
            screen = "explore lake";
        }
        if (input == "4") {
            screen = "Left path CHECK";
        }
        if (input == "5") {
            screen = "Getting dungeon key";
        }
    }
    if (screen == "Getting dungeon key") {
        print("\n  ad8888888888ba");
        print(" dP'         `\"8b,");
        print(" 8  ,aaa,       \"Y888a     ,aaaa,     ,aaa,  ,aa,");
        print(" 8  8' `8           \"88baadP\"\"\"\"YbaaadP\"\"\"YbdP\"\"Yb");
        print(" 8  8   8              \"\"\"        \"\"\"      \"\"    8b");
        print(" 8  8, ,8         ,aaaaaaaaaaaaaaaaaaaaaaaaddddd88P");
        print(" 8  `\"\"\"'       ,d8\"\"");
        print(" Yb,         ,ad8\"");
        print("  \"Y8888888888P\"");
        print("\nYou drop the tree essence into the, the lake started to shake and it spit out the key that opens some door.");
        print("\nYou should find out where it goes.");
        dungeonKey = true;
        Fun.threadSleep(3000);
        screen = "Giant Lake";
    }
    if (screen == "explore lake") {
        print("While exploring the water you find this sea monster lurking at the bottom of the sea");
        print("\n(1)Interact with the sea monster \n(2)go back to the shore");
        input = getInput();
        if (input == "1") {
            screen = "sea monster";
        }
        if (input == "2") {
            screen = "Giant Lake";
        }
    }
    //sea monster
    if (screen == "sea monster") {
        print("                                             oo");
        print("                                            o\"  $");
        print("                                          \" o   $");
        print("                                         \"      $");
        print("                                        $      $$ ");
        print("                                        o\"     \"$o ");
        print("   $oo                                  $     \"$$$");
        print("   $\"$oo                               \"      \"o$$ ");
        print("  \"$$o$\"o\"o                          o\"      $\"$$$");
        print("     \"\"\"o\"$o\"\"\"\"\"\"\"\" \"\"\" oo ooooooo\"\"\"     o\"\"o$$$");
        print("          \"$$ o                            o\"\"$$$");
        print("    oooo$$$$$$$$oo\"o o                 o \"o \"o \"\"oo");
        print("  \"$$$$$$$$$$\"\"\"\"$$$$o\"o$ o o o  \"o \" $\"$o$$oo\"o  $\"o");
        print("   \"$$$$$$\"         \"\"$$o$o$ $ \"ooo$o$o$$$$$$\"$o$o $\"$o");
        print("   \"$\"\"                 \"\"\"\"$$$$$o$$$$$$$$$     \"$o$$$$o");
        print("   \"                           \" \"\" \"  \"$$$$       \" $$$o");
        print("                                         \"$$$         \"\"\"");
        print("                                           \"\"$");
        print("\nYou go to the sea monster and it seems to be friendly. It also tells you something");
        print("\n\"If you have some special tree essence, you should drop it into this lake and it will spit out a key to a dungeon deep into Misty Forest\"");
        print("\n(1) How do I get tree essence \n(2)Why are you telling me this \n(3)Go back to the shore");
        input = getInput();
        if (input == "1") {
            screen = "How do I get it";
        }
        if (input == "2") {
            screen = "Why are you telling me this";
        }
        if (input == "3") {
            screen = "Giant Lake";
        }
    }
    if (screen == "How do I get it") {
        print("You ask how and where you get this special essence.");
        print("\nThe sea monster replies \n\“You have to kill one of the Misty forest trees and not any ordinary tree, a tree that can move, good luck finding one.\”");
        Fun.threadSleep(5000);
        screen = "sea monster";
    }
    if (screen == "Why are you telling me this") {
        print("You ask the sea monster why it is telling you this.");
        print("\nThey reply: \n\“Well the forest has been cursed by the Mist Dragon, it controls everything in this forest. From the trees, to the Misties, pretty much anything.\nExcept me, not even I know why the Mist dragons effect doesn’t impact me, but at least I can live my own life. I just hope me telling you this \”");
        Fun.threadSleep(7000);
        screen = "sea monster";
    }
    // Right Path
    if (screen == "Right path CHECK") {
        fightChance = Math.random();
        if (fightChance <= 0.25) {
            nextScreen = "Right path";
            screen = "Misty Fight";
        }
        if (fightChance > 0.25) {
            screen = "Right path";
        }
    }
    if (screen == "Right path") {
        print("\n\n&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
        print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
        print("####&&&&&&&&##&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&#");
        print("#B##B######&#P#&&BB##&&&&&&&&##&&&&&#B####&#&####B#####&&&&&&&&&&&&&#&&&&&&&&&&&&&&&&&&&###&&#####BB");
        print("GGBGBB#BGBGP&#&&BGB#&&##B#BBGGGPGBB###BBB##B#B####BB##GG#BGGGGGB#&&&&&&&&&#B#&&##&&#&&&BB#####B#BGBB");
        print("7PGY5G#BGPPYP&&&&&BG55P5Y5555Y55YYPPBBBG5PBB555G#BGG55YGBPY555Y5PG#BGG#BBB&&#B#&&&&&&BGGBGBBPPPP55?~");
        print(":5BJJ#G7!7?J?#&&PYY5Y5P555Y5P55PPP555Y5GBBB#BP55P#B5?YG#G5Y5PYY5Y55PBGBGY5YB&&&&&&&&GY5#BBB55YYYY5!.");
        print("?55?5G^:::::Y&&B7~5!7Y5555YJJ?5P55Y5Y5Y5YJ?JYPGB####GB##BPYJ!~~!77^:~P#B?!77~7#&&&&B:!P#PY7777~:!557");
        print("5~:5#Y:::::J&&&!?P5:.!5^~Y?^:7P7^^!!~~^^:::::::^~!?YPB####G~.:::::::::~YB?:...:P&&@B~5P~:::::::::JPP");
        print("^::7&Y::::5B#@#::?P!:^5~.:?J?P?::::::::::::::::::::.:^7P###P~:::::::::::~5G57~^^B&&&B?:::::::::::?PJ");
        print(":::^B5.~?PY~B@5:::?P~~5~:.!PP7::::::::::::::::::::::::::YGP##Y::::::::::::~Y##BBB&&@5.::::::::::^YP!");
        print("::::5B5BJ^.~&@7.:::J55Y::~Y5!:::::::::::::::::::::::::::YY:!G&G^::::::::::::~B###&&&#:::::::::::JPY^");
        print("::::5##7.:.Y@&^::::^5P~:~P5~::::::::::::::::::::::::::::YP^.^B&G^:::::::::::.!###PB@&?::::::::^JPPJ:");
        print("::::P#B:::^&@5:::::.7P~.?P!::::::::::::::::::::::::::::?P7:::~B#G~::::::::::::P##?~&&&^::::::~YP5P7:");
        print(":::J#B#Y::G@&~:::::^YY^~5P~::::::::::::::::::::::::::~YP7.:::.:G&B7:::::::::::5##Y.J@@Y::::^?5P5P5!:");
        print("~^7#5!P#??&@P.:::::YP!^YPP7:::::^^^^~~^^:::::^^:^:^7Y5PY^^~!7!^~G##Y^~!77?J!^!B###J?&&&PYYYYP5P55557");
        print("PP#BPPPB#&&&B7~~!7J5555P555J???JY555PGP5YJYYYP5Y5Y5PP5555P5P55555###BGGPPPPPPB#####G&&&&#GP55555P555");
        print("B##G#B###&&&#GBBGGGPGGPP5555PBBGPP55G###BB######BBGPPGBBB#BGGGP55B######BPPB########&&&&&&#BGGGBBBBB");
        print("&&&&&&&&&&&&&&##########BGGB#####BGGB#########################BBBB###########B######&&&&&&&&&&&&&&&&");
        print("&&&&&&&&&&&&&&&&&&&&&#B############&&##&&&&&&&&&&&&&&#####################B#####&&&&&&&&&&&&&&&&&&&&");
        print("&&&&&&&&&&&&&&&&&&&&&&&&###&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&#############&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
        print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&####&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
        print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
        print("\nThe path is super bumpy and all over the place. You hear sounds of creatures making interesting sounds. You don\’t feel safe here.");
        print("\n(1)Go back to the crossroads\n(2)keep on going");
        input = getInput();
        if (input == "1") {
            screen = "Misty Forest Crossroads CHECK";
        }
        if (input == "2") {
            screen = "tree puzzle CHECK";
        }
    }
    //tree puzzle
    if (screen == "tree puzzle CHECK") {
        fightChance = Math.random();
        if (fightChance <= 0.25) {
            nextScreen = "tree puzzle";
            screen = "Misty Fight";
        }
        if (fightChance > 0.25) {
            screen = "tree puzzle";
        }
    }
    if (screen == "tree puzzle" && treeEssence == false) {
        print("\n                      .-.-. _ _ _  |");
        print("                      /| | |(/|||||_|");
        print("                      _| | |/-'`'`'/|");
        print("                     / \\/|   o  + __.- /(");
        print("                    |  '|/| -|/(||||(_V_)");
        print("                    `._.| |/_/_)`-'' ///_<");
        print("                        >///\\\\\\\\\\//==<<<=");
        print("                      _ >>>\\\\\\>//<__<<<-'");
        print("                     / `-._>>>.-'   |<<");
        print("                    J     _.))     /<<<<");
        print("                v   |  .-'' |/__   |<<<||_");
        print("             \\\\\\||| `-> _/ / \\  `-<<<<<<*** **");
        print("           \\\\\\**|||| /    /><<\\    \\<<<********");
        print("             >>**////    /<>>>>`.   |****** <<_\\_\\");
        print("              >>***/_  .'>>><>>><\\  |*****<<<|_|_|");
        print("           .-' >***>>|/>//>><\\\\**|/\\|***<<<<<|_|_|");
        print("           \\.-' \\***<<<>>///\\\\\\******<<>><>>*****\\\\\\\\\\\\-.-.-<<<");
        print("            \\-'_.J--.<<<<>><<****>>///(\\|\\)|(//<<<,");
        print("           (   )|(-'  (>>><<****<\\\\)_.><<<<-");
        print("          .-`-'_)\\-.--.\\>>><*****//||>(\\ (\\\\_.\\<<<< .-");
        print("         .' _.-'()\\`.**>>//****<<<>><<`-``-``-`<<.-' _");
        print("     .--'_.'>>>><>>`.\\***(`._.-.<<<<<<(_____``<.'_.-' |<");
        print("    /-'   >><<>>>>>//<>>>/|\\ |  /<<>><|     `-._/      L");
        print("           ->>.<>><>>>>>/|| \\|.'|<<>\\\\|  .-----'|._    |");
        print("   .--._ >><.' \\>>>>>>///||  |  |<<>><|.'       )-----'`.");
        print("   |   _.--'    |///////\\\\\\-----'<>>>>>==\\\\<><>>>>< ===::===>>><****| .'`.`_ (   `-.   .--'");
        print("  /    .'>><>>)_ -->>>>===::::==>>******|/>>>/  `.  .--.`-.|");
        print(" /    />>>>>>>'`'`'`-`<===:::<<< *****(\\ .-.<(   )-(   )");
        print("/.'| />>>>>>>.-.-.-._\\|> =//||\\\\******-'@--'>>`-'<<\\`-'`._");
        print("   |/>>>>>>>-'`'`'`-.\\\\>>==<<<<***.'\\ |_|)_|<<<<<<< \\_ `- `.");
        print("  / >>>>>>.-..''`'`-.\\\\.->>>><<>(  /(\\\\\\/// <<<<<=    \\_ .-'");
        print(" /-' >>>----\\((::::)))// /><>>**|   (\\\\\\\\///<<<<---.");
        print("|.'  >>>| | | |\\__.'.'>>>>>****.'/ (\\\\\\\\////<<<<-`-`");
        print(" `   >>>|-|-| |>>>>>>>>>>**** .--. /_\\\\\\////<<<|_|_|<<<");
        print("     >>>|_|_|/>><>><<>*****vv(    V  `.\\\\<<<>>>|_|_|<<<<");
        print("     ////>>>>>`.>>>>******>>><`--'\\   /<<<<<>>>>><<<<<<<");
        print("     '' ///>>>>><<>>*****>>>><<<<<<`-'<<<<<<>><<<><<<<<<<");
        print("       ''    ->>>>><<>///>>>>><<<<<<\\\\\\\\\\\\><<<<<>>><<<<\\\\");
        print("               ////<<>><<<>>>><<<<>\\\\\\\\\\\\\\\\\\>><\\\\\\\\\\\\\\\\\\");
        print("              '' / ////////>>><<<\\\\\\\\\\\\\\\\\\\\<  \\\\\\ \\\\\\\\\\");
        print("                   /|| .////|||\\\\\\\\\\\\\\\\\\\\");
        print("                      (MMMMMMMMMMMMMMMMMMM)");
        print("                      |`----.MMMMMMMM.---'|");
        print("                      `---.____   ____.---'");
        print("                       |       \"\"\"    |");
        print("                       |                 |");
        print("                       |                 |");
        print("                       |                 |");
        print("                       |                 |");
        print("                       (                 )");
        print("                        `----._____.----'");
        print("\nYou find this weird looking tree in the middle of the path, it looks unnatural, \nyou try walking around it but the tree blocks your way.");
        print("\n\n What do you do?");
        print("\n(1)Try killing it \n(2)brute force through the tree \n(3)use an item \n(4)Go back to the Right path");
        input = getInput();
        if (input == "1") {
            screen = "death";
        }
        if (input == "2") {
            screen = "death";
        }
        if (input == "3" && treeImmobilizer == true) {
            screen = "tree puzzle finished";
        } else if (input == "3" && treeImmobilizer == false) {
            screen = "Cannot use item";
        }
        if (input == "4") {
            screen = "Right path CHECK";
        }
    }
    if (screen == "Cannot use item") {
        print("You can't use any items on the tree, go and explore Misty Forest to find some items");
        Fun.threadSleep(2000);
        screen = "tree puzzle";
    }
    if (screen == "tree puzzle finished") {
        print("\n     /\\");
        print("____/_ \\____");
        print("\\  ___\\ \\  /");
        print(" \\/ /  \\/ /");
        print(" / /\\__/_/\\");
        print("/__\\ \\_____\\");
        print("    \\  /");
        print("     \\/");
        print("\nYou use the potion on the tree, the potion refiled itself by magic. The tree vanishes into dust and leaves behind its tree essence");
        print("\n\n");
        Fun.threadSleep(2000);
        treeEssence = true;
        screen = "tree puzzle";
    }
    //dungeon
    if (screen == "tree puzzle" && treeEssence == true && dungeonKey == false && dungeonGate == false) {
        print("\n\n                                       ..............                                               ");
        print("                          .:~!7?YY55PPPPPPPPBGGGGGPGGPPP555YYJ?7!~^:.                               ");
        print("                     .~?Y5PP5YJ7!~^::^^:...7:^7?J!~:?::^^^^~!!?JY55PPPYJ7^.                         ");
        print("                  ~JPBBP5J:       .:~!!!!!!J?^.J5.^?J!!~~!!~:.      .^YPPBBPY!.                     ");
        print("               :JGGJ~J^ ~?.  .^~!7??7!^:..:^7YJJ5YP7^:...:~7??7!~^.  .?~ ^J^?PBY^                   ");
        print("             .J&G7:  :!~~^^~~~!77~.    :^^:   !#@J   .^^:    .~7?7~~~^^~~!:  :!G&Y.                 ");
        print("             5@5:^5:    ..:^!J!!~^~^. !!.7Y.  :B&7   JJ:^? .^~^~!!J7^::.    ^5^:5@G.                ");
        print("            ~@57:::..::^~~~::!:7!  .^~??:::.:~!^!77^.:::!Y~^:  !7:!::~~~^::..::^7?@J                ");
        print("            7@P5GBGGGBGP5YYYY5P5555YY55GBBGBGPY5P5PGGBGGG55YYY555P5YYYY5PGGBGGBG5P@5                ");
        print("            !@?.:.:^^.:::^:::::^::::^^:..:^:.:.!@Y.:::^:::::^::::::::::^::::^:.:.7@5                ");
        print("            !@7 ...Y5....G7 . !G: ..P? . ^B~ . ^@J    YY   ^G^   YJ   !P.  .5?   !@5                ");
        print("            !@Y~~~~Y5~~!~G?~~~7B!~~~PJ~~~!G7~~~7@5~~!~5Y~~~!G!~!~55~!~?G~~~~PJ~~~J@5                ");
        print("            !@?    7J    5^   :P    Y!    P:   ^@J    ?7   .P.   7?   ^5    J!   !@5                ");
        print("            ~@?    ?J    5^   :P.   Y!    P:   ^@J    ??   .P.   7?   ^5    J!   !@5                ");
        print("            ~@?    ?J    5^   :P.   Y!    P:   :@J    ??   .P.   7?   ^5    J!   !@5                ");
        print("            ~@?    ?J    5^   :P.   Y!    P:   :@Y    ??   .P.   7?   ^5    J!   ~@5                ");
        print("            ~@J    ?J    5^   :P.   Y!    P:   :@Y    ??   .P.   7?   ^5    J!   ~@5                ");
        print("            ^@J    ?J    5^   :P.   Y!    P:   :&Y    ??   .P.   7?   ^5    J!   ~@5                ");
        print("            ^@J    7J    5~   :P..  Y!  . P:   :&Y    ?7   .P.   7? . ^5  . J! . ~@5                ");
        print("            ^@J  .:JY::  5~ .^~P^:  Y!  :^G~^. :&5  .:J?:. .P. .:?Y^. ^5  .^5?:. ~@5                ");
        print("            ^@Y    5G    5^   7&^   Y!   ^&?   .&5    5P   .P.   PP   ^5   .B5   ~@5                ");
        print("            ^@Y  .:Y5:.  5~ .:!G~:. Y! .:^G!:. .&5  .:55:. .P. .:Y5:. ^5  :^5J:. ~@5                ");
        print("            ^@Y  :.?J.:  5~ ..:P... Y! .. P:.. .&5  :.??.: .P. :.7? . ^5  . J!.. ~@P                ");
        print("            ^@Y    ?J    5^   :P.   Y!    P:   .&5    ??   .P.   7?   ^5    J!   ~@P                ");
        print("            :@5    ?J    5^   :P.   Y!    P:   .#5    ??   .P.   7?   ^5    J!   ~@P                ");
        print("            :@5    ?J    5^   :P.   Y!    P:   .#P    ??   .P.   7?   ^5    J!   ~@P                ");
        print("            :@5    ?J    5^   :P.   Y!    P:   .#P    ??   .P.   7?   ^5    J!   ~@P                ");
        print("            :&P    ?J    5^   :P.   Y!    P:   .#P    ??   .P.   7?   ^5    J!   ^@P                ");
        print("           :&P    7J    5^   :P    Y!    P:    #P    ?7   .P.   7?   ^5    J!   ^@P                ");
        print("            :&G::::JY::::P!:::~G^:::57:::^G~::::#G..:.J?.::^G^::.?J.:.!P.::.Y7.:.!@P                ");
        print("            :&G~!!~Y5~!!!G?~!~7G!!!~PJ~!!!G7~!B&@&B#J~5Y!!!7G7!!!Y5!!!?G!!!!PJ!!!?@P                ");
        print("            .&P    ?J    5^   .P    Y~    P: .&@@&@@7 ?7   .P.   7?   ^5    J!   ^@P                ");
        print("            .#B777!JJ!77!P57!7YP?JJ755J77757!7PG&&BBJ!YJ!!!7GJ7!?5Y7J7?PJ7!!Y?!!!J@P                ");
        print("            .#G   :::~^ 77:.~^^P#?.~::!?..^~:^. BG  .:::^:.?!::~:7BG^^^:~J^.^~:^:^@P                ");
        print("            .#G   .7YJ7!5  .J!~JG7~Y!  ?!77YJ!  BG   .7Y?7!J  ~Y~!P5~7Y. ^J~7JJ7.^@P                ");
        print("           .#G  :!J?JPB&J.    :J .   ^GBG577?~:BG  :~J?YG##!   . 7! .  .J#BP?7J~~@P               ");
        print("            .#G.7~::: .:7BBY7^^^^^:^75#J^. .^::!#G.7~:::..~J#G?~^^^:::~JBP!: .^::7@P            ");
        print("            .#G^J .?7!    ?77PJ^^^55!Y^   .J7! ^&G:J .?7~   :Y7JP!^^7PJ??    ?77 ~@P          ");
        print("     .BB ~5555777. :? ^~. :^.:?  :?7J5PPJBB ~Y55Y7?!. !~ ~^  ^^ ?: .!7?5PP5@P               ");
        print("             BB:?~^???..  ^7!5!  ^Y?:J.  .^J?!:~&B.7!~??7..  !!?Y: .7Y^7^  .:J?7:7@P            ");
        print("             BB:J: ~~.  .!B5J7!!~~!?YPP~.  :~:.!&B.J. !!:  .7GYJ7!!~!?J5G7.  :~^ !@P          ");
        print("             BB..~~~~~75G#J^.   ~.   :7BB5?!!~~^GB .~~~~~75B#?^.  .^   :!GBP?!!~~!&G        ");
        print("             B#.  .77?PYY~  ^~^~P!^~^  ~55JJ?^  G#   .77JGJ5^  ^^^7Y^^~. .55YJ?~ :&G      ");
        print("             B#   .!J7! !!  77.Y&5.!?  7!:~7^:  G#   .!Y7! ?^ .J~^B#~:J^ :J:~7~^ :&G    ");
        print("             G&777?77J?77Y5J7?YPPPY?7J5Y!!7!!!!!B#!!!?77J?!75Y7775GGP?77YPJ7??7??J@G  ");
        print("             G#777777!777!77777!!!77777!77777777PG777!!!!!!!!!!!!!~~!!!!!~~~~~~~~!B5");
        print("             ::                                 ^^                                . ");
        print("You find an entrance to a closed metal gate, This gate could lead so somewhere, but it requires a key to open it.");
        print("\n(1)Walk away");
        input = getInput();
        if (input == "1") {
            screen = "Right path CHECK";
        }
    }
    if (screen == "tree puzzle" && treeEssence == true && dungeonKey == true && dungeonGate == false) {
        print("\n\n                                       ..............                                               ");
        print("                          .:~!7?YY55PPPPPPPPBGGGGGPGGPPP555YYJ?7!~^:.                               ");
        print("                     .~?Y5PP5YJ7!~^::^^:...7:^7?J!~:?::^^^^~!!?JY55PPPYJ7^.                         ");
        print("                  ~JPBBP5J:       .:~!!!!!!J?^.J5.^?J!!~~!!~:.      .^YPPBBPY!.                     ");
        print("               :JGGJ~J^ ~?.  .^~!7??7!^:..:^7YJJ5YP7^:...:~7??7!~^.  .?~ ^J^?PBY^                   ");
        print("             .J&G7:  :!~~^^~~~!77~.    :^^:   !#@J   .^^:    .~7?7~~~^^~~!:  :!G&Y.                 ");
        print("             5@5:^5:    ..:^!J!!~^~^. !!.7Y.  :B&7   JJ:^? .^~^~!!J7^::.    ^5^:5@G.                ");
        print("            ~@57:::..::^~~~::!:7!  .^~??:::.:~!^!77^.:::!Y~^:  !7:!::~~~^::..::^7?@J                ");
        print("            7@P5GBGGGBGP5YYYY5P5555YY55GBBGBGPY5P5PGGBGGG55YYY555P5YYYY5PGGBGGBG5P@5                ");
        print("            !@?.:.:^^.:::^:::::^::::^^:..:^:.:.!@Y.:::^:::::^::::::::::^::::^:.:.7@5                ");
        print("            !@7 ...Y5....G7 . !G: ..P? . ^B~ . ^@J    YY   ^G^   YJ   !P.  .5?   !@5                ");
        print("            !@Y~~~~Y5~~!~G?~~~7B!~~~PJ~~~!G7~~~7@5~~!~5Y~~~!G!~!~55~!~?G~~~~PJ~~~J@5                ");
        print("            !@?    7J    5^   :P    Y!    P:   ^@J    ?7   .P.   7?   ^5    J!   !@5                ");
        print("            ~@?    ?J    5^   :P.   Y!    P:   ^@J    ??   .P.   7?   ^5    J!   !@5                ");
        print("            ~@?    ?J    5^   :P.   Y!    P:   :@J    ??   .P.   7?   ^5    J!   !@5                ");
        print("            ~@?    ?J    5^   :P.   Y!    P:   :@Y    ??   .P.   7?   ^5    J!   ~@5                ");
        print("            ~@J    ?J    5^   :P.   Y!    P:   :@Y    ??   .P.   7?   ^5    J!   ~@5                ");
        print("            ^@J    ?J    5^   :P.   Y!    P:   :&Y    ??   .P.   7?   ^5    J!   ~@5                ");
        print("            ^@J    7J    5~   :P..  Y!  . P:   :&Y    ?7   .P.   7? . ^5  . J! . ~@5                ");
        print("            ^@J  .:JY::  5~ .^~P^:  Y!  :^G~^. :&5  .:J?:. .P. .:?Y^. ^5  .^5?:. ~@5                ");
        print("            ^@Y    5G    5^   7&^   Y!   ^&?   .&5    5P   .P.   PP   ^5   .B5   ~@5                ");
        print("            ^@Y  .:Y5:.  5~ .:!G~:. Y! .:^G!:. .&5  .:55:. .P. .:Y5:. ^5  :^5J:. ~@5                ");
        print("            ^@Y  :.?J.:  5~ ..:P... Y! .. P:.. .&5  :.??.: .P. :.7? . ^5  . J!.. ~@P                ");
        print("            ^@Y    ?J    5^   :P.   Y!    P:   .&5    ??   .P.   7?   ^5    J!   ~@P                ");
        print("            :@5    ?J    5^   :P.   Y!    P:   .#5    ??   .P.   7?   ^5    J!   ~@P                ");
        print("            :@5    ?J    5^   :P.   Y!    P:   .#P    ??   .P.   7?   ^5    J!   ~@P                ");
        print("            :@5    ?J    5^   :P.   Y!    P:   .#P    ??   .P.   7?   ^5    J!   ~@P                ");
        print("            :&P    ?J    5^   :P.   Y!    P:   .#P    ??   .P.   7?   ^5    J!   ^@P                ");
        print("           :&P    7J    5^   :P    Y!    P:    #P    ?7   .P.   7?   ^5    J!   ^@P                ");
        print("            :&G::::JY::::P!:::~G^:::57:::^G~::::#G..:.J?.::^G^::.?J.:.!P.::.Y7.:.!@P                ");
        print("            :&G~!!~Y5~!!!G?~!~7G!!!~PJ~!!!G7~!B&@&B#J~5Y!!!7G7!!!Y5!!!?G!!!!PJ!!!?@P                ");
        print("            .&P    ?J    5^   .P    Y~    P: .&@@&@@7 ?7   .P.   7?   ^5    J!   ^@P                ");
        print("            .#B777!JJ!77!P57!7YP?JJ755J77757!7PG&&BBJ!YJ!!!7GJ7!?5Y7J7?PJ7!!Y?!!!J@P                ");
        print("            .#G   :::~^ 77:.~^^P#?.~::!?..^~:^. BG  .:::^:.?!::~:7BG^^^:~J^.^~:^:^@P                ");
        print("            .#G   .7YJ7!5  .J!~JG7~Y!  ?!77YJ!  BG   .7Y?7!J  ~Y~!P5~7Y. ^J~7JJ7.^@P                ");
        print("           .#G  :!J?JPB&J.    :J .   ^GBG577?~:BG  :~J?YG##!   . 7! .  .J#BP?7J~~@P               ");
        print("            .#G.7~::: .:7BBY7^^^^^:^75#J^. .^::!#G.7~:::..~J#G?~^^^:::~JBP!: .^::7@P            ");
        print("            .#G^J .?7!    ?77PJ^^^55!Y^   .J7! ^&G:J .?7~   :Y7JP!^^7PJ??    ?77 ~@P          ");
        print("     .BB ~5555777. :? ^~. :^.:?  :?7J5PPJBB ~Y55Y7?!. !~ ~^  ^^ ?: .!7?5PP5@P               ");
        print("             BB:?~^???..  ^7!5!  ^Y?:J.  .^J?!:~&B.7!~??7..  !!?Y: .7Y^7^  .:J?7:7@P            ");
        print("             BB:J: ~~.  .!B5J7!!~~!?YPP~.  :~:.!&B.J. !!:  .7GYJ7!!~!?J5G7.  :~^ !@P          ");
        print("             BB..~~~~~75G#J^.   ~.   :7BB5?!!~~^GB .~~~~~75B#?^.  .^   :!GBP?!!~~!&G        ");
        print("             B#.  .77?PYY~  ^~^~P!^~^  ~55JJ?^  G#   .77JGJ5^  ^^^7Y^^~. .55YJ?~ :&G      ");
        print("             B#   .!J7! !!  77.Y&5.!?  7!:~7^:  G#   .!Y7! ?^ .J~^B#~:J^ :J:~7~^ :&G    ");
        print("             G&777?77J?77Y5J7?YPPPY?7J5Y!!7!!!!!B#!!!?77J?!75Y7775GGP?77YPJ7??7??J@G  ");
        print("             G#777777!777!77777!!!77777!77777777PG777!!!!!!!!!!!!!~~!!!!!~~~~~~~~!B5");
        print("             ::                                 ^^                                . ");
        print("You find an entrance to a closed metal gate, This gate could lead so somewhere, but it requires a key to open it.");
        print("\n(1)Walk away\n(2)Use key");
        input = getInput();
        if (input == "1") {
            screen = "Right path CHECK";
        }
        if (input == "2") {
            dungeonGate = true;
            screen = "tree puzzle";
        }
    }
    if (screen == "tree puzzle" && treeEssence == true && dungeonKey == true && dungeonGate == true) {
        print("                                      ...:::::::::::::.....                                         ");
        print("                           :^!7JY55PPPPPPPP5PBGGGGGPGGPPPPPP55YYJ?7~^:.                            ");
        print("                       :!JPPP5YJ7!~^:...::.. 7^.!7J!~ 7:.:^:.:^~!7?JY5PP55J!^.                      ");
        print("                  .~YPBB5JJ~      .:^!77!!77JY!.7P.~JJ7!!!!77~^.      :YYYGBG5?^                   ");
        print("                :JGP?^!7 :7^ .:^~!7?7!^:.  .:~?5JP55!:.   .:~7??!~^:. .7~ ~?.!YBP~                 ");
        print("               ?&B?^.  ^!~^~~~~!?7~:    ^~~^.  :B@Y   :~~~.   .^7?7~~~~~~!~.  ^!P@P:               ");
        print("             ?@B: J7     .:^!Y!~~:^~^.~7 ~Y:  :5#Y   7J.:J.:~~:^!~J7~^.     ^Y:.5@B:              ");
        print("             .BB!!~^^^~~!!!~^:!~!?...^~7Y!~^^~!7:!!?!~^^~?Y!~:..!?~!::~!!!~~^^^^!!?@?              ");
        print("             .#&BGPPPPGPP5555555555555555GGGGGP555Y5PGGGGP5555555555555555PPPPG&#B#@J              ");
        print("             .B@@&G?!^.                                                   .^?YP5&@@@J              ");
        print("             .B@@@B:!7JJ7~:                                           .^7Y5Y?!^~G@@@J              ");
        print("             .B@@@B!Y:!:!?YYJ~                                        PB7!~7~5JGB@@@J              ");
        print("               B@@@G7BYBJ5J^7#P                                        BBYYGBJG!P5@@@Y              ");
        print("               B@@@P^5^5?PBYB&5                                        GBP?55~5^PY@@@Y              ");
        print("               B@@@P~5~Y7JG~P#5                                        GG5!P5!P^PY@@@Y              ");
        print("               G@@@5!Y~Y?JG~P#Y                                        PB5!P5!P^PJ@@@Y              ");
        print("               G@@@57J!JJJP~P#Y                                        PB5~PY!P^P?@@@Y              ");
        print("               G@@@5?J7JJJP!P#J                                        5BP~PY!5^57@@@Y              ");
        print("               G@@@5????YJ5!P&?                                        5#5~PY?5!GY&@@Y              ");
        print("               G@@@GB5JYGP5?P&?                                        Y&#YGBG57#P&@@Y              ");
        print("               P@@@5BJJJ#G5P#@7                                        J&#JPPPY!G5#@@Y              ");
        print("               P@@@P#?YJ#PYPB@7                                        J@#YPGG57G5#@@Y              ");
        print("              P@@@YP7Y7GPJ5B@!                                        ?&P!5YJJ!J7B@@Y              ");
        print("               P@@@?5^5~557?P@~                                        ?@P!YYY?7J?B@@5              ");
        print("              P@@@?P^5~5P!JP@~                                        7@P7J5Y7???G@@5              ");
        print("              5@@@?P^5~5P!YP@^                                        7@P7J5Y7?7JG@@5              ");
        print("               5@@@?P^P~5P~YG@^                                        !@P??5Y!J7JP@@5              ");
        print("               5@@@7P:P~5P^YG&^                                        ~@GJ7PY!J!J5@@5              ");
        print("               5@@@7P^P!PG7PB&:                                        ~@BPYBGYPJ5P@@5              ");
        print("               Y@@@5BJBJGB!PB&:                                        ^@BY~P5~P7PP@@5              ");
        print("               Y@@&75^5~PG!P##.                                        ^@&YGBBJP!5Y@@5              ");
        print("               Y@@&JPYBG&PG5@#.                                        ^&@#GP@PBPJG@@5              ");
        print("               Y@@&YJB5#@5B@@#.                                        :&@@PY#G5#GB&@P              ");
        print("               J@@&B@#?55?&B@B.                                        :&#P&J?!Y@@&&@P              ");
        print("               J@@@&#&5?Y#GP@B                                         .#@5G&YP&5J#@@P              ");
        print("               J@@@575&YY&YB@G                                         .#@PPP75B75G@@P              ");
        print("               J@@&GB?B?7BYB@G                                         .B@YPB75GY#B@@P              ");
        print("               ?@@@#BJ#5J&P5@P                                         .B@P&PJ&BJB#@@P              ");
        print("               ?@@&PGY@P?Y&#@P                                          B@&P!?Y&5YP@@P             ");
        print("               ?@@&YJ#P?5?GB@5                                          G@PPG&YP&P#&@P           ");
        print("               ?@@&B@#Y#&GBG&J                                          ~YG&B@PY@@&&@P         ");
        print("               ?@@&###YB@#G?:                                             .!5###PYB@@P       ");
        print("              7@@&YY#&G?:                                                   .7P#B#@@P     ");
        print("               7@@@&G?:                                                         :7P&@G   ");
        print("               7@B?^                                                               ^JJ   ");
        print("The dungeon gate is open, you can enter to see what's inside.");
        print("\n(1)Walk away (2)Go in");
        input = getInput();
        if (input == "1") {
            screen = "Right path CHECK";
        }
        if (input == "2") {
            screen = "Dungeon";
        }
    }
    if (screen == "Dungeon" && mistGaurdianBeaten == false) {
        print("\n         .--.");
        print("        /.--.\\");
        print("        |====|");
        print("        |`::`|");
        print("    .-;`\\..../`;-.");
        print("   /  |...::...|  \\");
        print("  |   /'''::'''\\   |");
        print("  ;--'\\   ::   /\\--;");
        print("  <__>,>._::_.<,<__>");
        print("  |  |/   ^^   \\|  |");
        print("  \\::/|        |\\::/");
        print("  |||\\|        |/|||");
        print("  ''' |___/\\___| '''");
        print("       \\_ || _/");
        print("       <_ >< _>");
        print("       |  ||  |");
        print("       |  ||  |");
        print("      _\\.:||:./_");
        print("     /____/\____\\");
        print("\nYou slowly step into the dungeon, the gate behind you closes and right in front of you is the Mist Guardian. \nThe Mist guardian hunts and kills unwanted travellers that come into the forest. ");
        Fun.threadSleep(3000);
        print("NOTE: The Mist Guardian deals 35 damage every attack but has terrible accuracy and has 600 health.");
        print("\n(Has a 50% chance of hitting you)");
        count = 0;
        playerHealth = maxPlayerHealth;
        Fun.threadSleep(3000);
        screen = "Mist Guardian Boss";
    }
    if (screen == "Dungeon" && mistGaurdianBeaten == true) {
        print("\n\n                                   _______________________      |");
        print("                                  |  ________   ________  |     |");
        print("                                  | |        | |    ___ | |     |");
        print("                                  | |        | |  ,',.('| |     |");
        print("                                  | |        | | :  .'  | |     |");
        print("                                  | |        | | :) _  (| |     |");
        print("                                  | |        | |  `:_)_,| |     |");
        print("                                  | |________| |________| |     |");
        print("                                  |  ________   ________  |     |");
        print("                                  | |        | |        | |     |");
        print("                                  | |        | |        | |     |");
        print("                                  | |        | |        | |     |");
        print("                                  | |        | |        | |     |");
        print("                                  | |        | |        | |     |");
        print("                                  | |________| |________| |     |");
        print("                                  |_______________________|     |");
        print("                                                                |");
        print("                                                                |");
        print("                   _____________________________________________|");
        print("                                                              `.");
        print("                                                                  `.");
        print("                                                                    `.");
        print("                                                                      `.");
        print("                     ..::::::::::::' .:::::::::::::::                   `.");
        print("                 ..:::::::::::::::' .:::::::::::::::'                    `");
        print("             ..:::::::::::::::::' .:::::::::::::::::");
        print("         ..::::::::::::::::::::' .:::::::::::::::::'");
        print("     ..::::::::::::::::::::::' .:::::::::::::::::::");
        print(" ..:::::::::::::::::::::::::' .:::::::::::::::::::'");
        print("..........................  ......................");
        print(":::::::::::::::::::::::::' .:::::::::::::::::::::'");
        print(":::::::::::::::::::::::' .:::::::::::::::::::::::");
        print("::::::::::::::::::::::' .:::::::::::::::::::::::'");
        print("::::::::::::::::::::' .:::::::::::::::::::::::::");
        print(":::::::::::::::::::' .:::::::::::::::::::::::::'                              ");
        print("\nhere nothing worth seeing here.");
        print("\n(1)Go back");
        input = getInput();
        if (input == "1") {
            screen = "tree puzzle CHECK";
        }
    }
    if (screen == "Mist Guardian Boss" && playerHealth > 0 && mistGuardianHealth > 0) {
        mistGuardianAttackRandom = Math.random();
        normalAttack = strength * 0.1;
        strongAttack = strength * 0.25;
        heal = strength * 0.1;
        print("\n      _,.");
        print("      ,` -.)");
        print("     ( _/-\\\\-._");
        print("    /,|`--._,-^|            ,");
        print("    \\_| |`-._/||          ,'|");
        print("      |  `-, / |         /  /");
        print("      |     || |        /  /");
        print("       `r-._||/   __   /  /");
        print("   __,-<_     )`-/  `./  /");
        print("  '  \\   `---'   \\   /  /");
        print("      |           |./  /");
        print("      /           //  /");
        print("  \\_/' \\         |/  /");
        print("   |    |   _,^-'/  /");
        print("   |    , ``  (\\/  /_");
        print("    \\,.->._    \\X-=/^");
        print("    (  /   `-._//^`");
        print("     `Y-.____(__}");
        print("      |     {__)");
        print("            ()");
        if (mistGuardianAttackRandom > 0.50 && count > 0) {
            print("\n(Mist Guardian has dealt", 35, "damage to you)");
            playerHealth = playerHealth - 35;
        } else if (mistGuardianAttackRandom <= 0.50) {
            print("\n(Mist Guardian Missed)");
        }
        print("\n\n||Your health is", playerHealth + "||");
        print("\n\n|| Mist Guardian Health is", mistGuardianHealth + "||");
        print("\n\n(1) Normal attack 75% chance it hits and it deals", normalAttack);
        print("\n(2) Strong attack: 45% chance of hitting and deals", strongAttack);
        print("\n(3) Heal: Heals", heal, "of health ");
        count = count + 1;
        input = getInput();
        if (input == "1") {
            playerAttackRandom = Math.random();
            if (playerAttackRandom <= 0.75) {
                print("\n\n\n\nYou dealt", normalAttack, "damage to the the Mist Guardian ");
                mistGuardianHealth = mistGuardianHealth - normalAttack;
                Fun.threadSleep(1000);
            } else {
                print("\n\n\n\nYou missed the attack");
                Fun.threadSleep(1000);
            }
        }
        if (input == "2") {
            playerAttackRandom = Math.random();
            if (playerAttackRandom <= 0.45) {
                print("\n\n\n\nyou dealt", strongAttack, "damage to the Mist Guardian ");
                mistGuardianHealth = mistGuardianHealth - strongAttack;
            } else {
                print("\n\n\n\nYou missed the attack");
            }
            Fun.threadSleep(1000);
        }
        if (input == "3") {
            print("\n\n\n\nyou healed", heal, "health");
            playerHealth = playerHealth + heal;
            Fun.threadSleep(1000);
        }
    }
    if (screen == "Mist Guardian Boss" && playerHealth < 1) {
        print("\n\n__   __           ______ _          _");
        print("\\ \\ / /           |  _  (_)        | |");
        print(" \\ V /___  _   _  | | | |_  ___  __| |");
        print("  \\ // _ \\| | | | | | | | |/ _ \\/ _` |");
        print("  | | (_) | |_| | | |/ /| |  __/ (_| |");
        print("  \\_/\\___/ \\__,_| |___/ |_|\\___|\\__,_|");
        gameOver = true;
    }
    if (screen == "Mist Guardian Boss" && mistGuardianHealth < 1) {
        coins = coins + 600;
        print("\nYOU WON, you get", 600, "coins");
        print("\nYou have", coins, "coins");
        mistGaurdianBeaten = true;
        screen = "Dungeon";
    }
    if (screen == "") {
        print("ERROR");
        treeImmobilizer = true;
        treeEssence = false;
        treeImmobilizer = false;
        dungeonGate = false;
        dungeonKey = false;
        mistGaurdianBeaten = false;
    }
    if (screen == "death") {
        print("\n\n__   __           ______ _          _");
        print("\\ \\ / /           |  _  (_)        | |");
        print(" \\ V /___  _   _  | | | |_  ___  __| |");
        print("  \\ // _ \\| | | | | | | | |/ _ \\/ _` |");
        print("  | | (_) | |_| | | |/ /| |  __/ (_| |");
        print("  \\_/\\___/ \\__,_| |___/ |_|\\___|\\__,_|");
        gameOver = true;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vaG9tZS9ydW5uZXIvbWlzdHktZm9yZXN0L2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xuLy8gUHJvZ3JhbW1lcidzIE5hbWU6XG4vLyBQcm9ncmFtIE5hbWU6XG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuLypcbiAqIENvcHlyaWdodCAyMDEyLCAyMDE2LCAyMDIwIENoZW5nXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKiAgICAgaHR0cHM6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuaW1wb3J0IHtcbiAgICBwcmludCxcbiAgICBnZXRJbnB1dCxcbiAgICBqYXZhU2xlZXAsXG4gICAgY3VycmVudERhdGVcbn0gZnJvbSBcIi4vY3MxMC10eHQtbGliLTAuNi50c1wiO1xuaW1wb3J0ICogYXMgRnVuIGZyb20gXCIuL2NzMTAtdHh0LWxpYi0wLjYudHNcIjtcbi8vIERvbid0IGVkaXQgdGhlIGltcG9ydCBsaW5lcyBhYm92ZSwgb3IgeW91IHdvbid0IGJlIGFibGUgdG8gd3JpdGUgeW91ciBwcm9ncmFtIVxuXG4vLyBBbHNvLCBkbyBub3QgdXNlIHRoZSBmb2xsb3dpbmcgdmFyaWFibGUgYW5kIGZ1bmN0aW9uIG5hbWVzIGluIHlvdXIgb3duIGNvZGUgYmVsb3c6XG4vLyAgICBwcmludCwgZ2V0SW5wdXQsIGphdmFTbGVlcCwgY3VycmVudERhdGUsIEZ1blxuXG4vLyBXcml0ZSB5b3VyIHByb2dyYW0gYmVsb3cgdGhpcyBsaW5lOlxuLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcblxubGV0IGdhbWVPdmVyID0gZmFsc2U7XG5sZXQgc2NyZWVuID0gXCJzcGxhc2ggc2NyZWVuXCI7XG4vL2xldCBzY3JlZW4gPSBcIlwiXG5sZXQgaW5wdXQ6IHN0cmluZyA9IFwiXCI7XG5sZXQgcGxheWVyTmFtZTogc3RyaW5nID0gXCJcIjtcbmxldCBwbGF5ZXJIZWFsdGggPSAxMDA7XG5sZXQgeW91bmdNaXN0eUhlYWx0aCA9IDEwMDtcbmxldCBtYXhQbGF5ZXJIZWFsdGggPSAxMDA7XG5sZXQgc3RyZW5ndGggPSAxMDA7XG5sZXQgbm9ybWFsQXR0YWNrOiBudW1iZXIgPSAwO1xubGV0IHN0cm9uZ0F0dGFjazogbnVtYmVyID0gMDtcbmxldCBoZWFsOiBudW1iZXIgPSAwO1xubGV0IHBsYXllckF0dGFja1JhbmRvbTogbnVtYmVyID0gMDtcbmxldCBjb3VudDogbnVtYmVyID0gMDtcbmxldCBjb2luczogbnVtYmVyID0gMDtcbmxldCBtaXN0eVN0cmVuZ3RoID0gNzU7XG5sZXQgbWlzdHlIZWFsdGggPSAwO1xubGV0IG1pc3R5QXR0YWNrOiBudW1iZXIgPSAwO1xubGV0IGNvaW5zR290dGVuOiBudW1iZXIgPSAwO1xubGV0IG5leHRTY3JlZW46IHN0cmluZyA9IFwiTWFpbiBodWJcIjtcbmxldCBmaWdodENoYW5jZTogbnVtYmVyID0gMDtcbmxldCBhbHJlYWR5Rm91Z2h0ID0gZmFsc2U7XG5sZXQgdHJlZUVzc2VuY2UgPSBmYWxzZTtcbmxldCB0cmVlSW1tb2JpbGl6ZXIgPSBmYWxzZTtcbmxldCBkdW5nZW9uS2V5ID0gZmFsc2U7XG5sZXQgZHVuZ2VvbkdhdGUgPSBmYWxzZTtcbmxldCBtaXN0R2F1cmRpYW5CZWF0ZW4gPSBmYWxzZTtcbmxldCBtaXN0R3VhcmRpYW5IZWFsdGggPSA2MDA7XG5sZXQgbWlzdEd1YXJkaWFuQXR0YWNrUmFuZG9tOiBudW1iZXIgPSAwO1xubGV0IHN0b3JlQ29zdEhlYWx0aDogbnVtYmVyID0gNjU7XG5sZXQgc3RvcmVDb3N0U3RyZW5ndGg6IG51bWJlciA9IDU1O1xubGV0IG1pc3REcmFnb25IZWFsdGg6IG51bWJlciA9IDA7XG5sZXQgbWlzdERyYWdvbkF0dGFja1JhbmRvbTogbnVtYmVyID0gMFxubGV0IG1pc3REcmFnb25BdHRhY2tDaGFuY2U6IG51bWJlciA9IDBcblxuXG53aGlsZSAoZ2FtZU92ZXIgPT0gZmFsc2UpIHtcblxuICAgIGlmIChzY3JlZW4gPT0gXCJNaXN0eSBGaWdodFwiKSB7XG4gICAgICAgIHByaW50KFwiIFVOTFVDS1ksIHlvdSBlbmNvdW50ZXJlZCBhIE1pc3R5XCIpO1xuICAgICAgICBtaXN0eUhlYWx0aCA9IG1pc3R5U3RyZW5ndGhcbiAgICAgICAgcGxheWVySGVhbHRoID0gbWF4UGxheWVySGVhbHRoXG4gICAgICAgIG1pc3R5QXR0YWNrID0gbWlzdHlTdHJlbmd0aCAqIDAuMVxuXG4gICAgICAgIEZ1bi50aHJlYWRTbGVlcCgxMDAwKTtcblxuICAgICAgICBzY3JlZW4gPSBcIk1pc3R5IEJhdHRsZVwiXG5cbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWlzdHkgQmF0dGxlXCIgJiYgbWlzdHlIZWFsdGggPj0gMSAmJiBwbGF5ZXJIZWFsdGggPiAxKSB7XG5cbiAgICAgICAgcGxheWVySGVhbHRoID0gcGxheWVySGVhbHRoIC0gbWlzdHlBdHRhY2tcblxuICAgICAgICBub3JtYWxBdHRhY2sgPSBzdHJlbmd0aCAqIDAuMVxuICAgICAgICBzdHJvbmdBdHRhY2sgPSBzdHJlbmd0aCAqIDAuMjVcbiAgICAgICAgaGVhbCA9IHN0cmVuZ3RoICogMC4xXG5cblxuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4/SjdKR1BKIS4gICAgICAgIC5+Li5eLlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/Ny4gLn4uIDc3Xi46LiAgOiE1I0JHQkJCUEo3LiAgICAgOlBHR0dZXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfkdCRzVHI0dZQkJHUEJQPyFHNUcjRyNCQkJCJkI1P34gICAgNyNCQkd+OlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLiEhISMjQiNCI0JCI0JCIyNHR0JHR0dHR0dHR0dHQiNCQiNHIS4gIC5+WUJCQjV+LlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuWSNHQkJHQiNCI0JHQiNCI0JCQiNCR0JHR0JCQkIjI0JHQiNCI1A1fiAgIF5QQkJCUF5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuIC5eSkJHR0dCIyMjIyNCI0JCQkJHI0dCIyNCQkIjJiNCI0JHR0dHR0dHR0JZWVleN0JHR0IhLlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSlBZUEdCQiNCQiMjQkJHQkJHQkIjQiNHUFBHIyNCIyNCQkJCQkJCQkJCR0dHR0dCR0c1QkJCQkchXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH5QNVlHQkdHR0IjI0JHQkJHQkJCQkJHR0JCQkJCQiMjQkJHQkJCQkJCQkJCQkdCIyNCI0JHQkJHI0dCR0pcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgLjVQUEJHR0dHQkJCQiMjQkJCQkJCQkJCI0JCI0JCQiNCQkJHQkJCQkJCQkJCQkIjQiMjQkJCQkdHUFBHQkI3XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgLl5+LiAgXllCQkdHR0JCQkJCQkIjI0JCR0JCQkJHQiNCQkJCQkJHQkJCQkJCQkJCQkJCQkdCQkJCQkdCQkJCR0dHUEdHUC4uXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgIC5efj9HUEdCR1lQQkdHR0JCQkJCQkdCIyMjQkJCQkJCQkIjIyNCR0JCQkJHQkJCR0JCQkJCQkJCQkJCR0JCQkJCQkJCQkdCQkJHR0dHNV5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICB+QkIjI0JCQiMmI0JHUEJCQkJHQkJCR0IjI0JHQkJCR0JCQiMjR0dCQkJCR0IjI0JCQkJCR0JHR0dHQkdHQkJCQkJCQkJCQkJCQkdHR1BCQl5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgIH5HUFlHQkdHQkIjQlBHR0JCQkJCIyNCR0dCQkJCQkJCQiMmI0JCR0JCQkJCQiMmQkJCQkJCQkJCQkJCR0JCQkJCQkJCQkIjIyNCR0JCR1BQQko6XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICA6Xi4gICFQSlBHUEdCQkJCR0IjIyNCQkJHR0dHQiNCIyNCIyNCQkJHQiMjQiMjQkJCQkJCQkJCQkJCQkcjI0JCQkJCQkJCQkJHQkJCQkJHR1BHRzU6XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgIEojR0dHR0dCQkJCQkIjI0dCQkJCQkJHQiMjQkJCQkJCQkJCQiMjQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCR0JCQkJCQkJCR0dQR0JeXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgLjouPyNHR0dCQkJCQiNCIyMjQkJHQkJCQkJCQiNCQkJCQkJCQkIjIyNCQkJCQkJCQkJCQiMjIyNCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkdHUEdKLlwiKVxuICAgICAgICBwcmludChcIiAgICAgIC46LiAuLl46LllCR0dHR0JCQkJCR0IjI0JCQkJCQkJCQkJCQkJCQkJCQkJCIyMjIyNCQkJCQkJCQkJCIyMjI0JCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCR0dQQjVcIilcbiAgICAgICAgcHJpbnQoXCIgICAufkpQQlA1UFBCR0JHI0dCQkJCQkJCQkJCIyNCQkJCQkJCQkJCQkJCQkJCQkJCQiMmQkJCQkJCQkJCQkIjIyYjQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJHUEdCIVwiKVxuICAgICAgICBwcmludChcIiAhNUdCJkJCQiNHQkdCQkJCQkdHR0JCQkJCQkJCQiMmI0JCQkJCQkJCQkJCQkJCQiMjIyNCQkJCQkJCQkJCIyYjQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJHR0JZXCIpXG4gICAgICAgIHByaW50KFwiIF4/QkdKPzU1N15KUEIjI0IjQkJCQkJCQkJCI0IjI0JCQkJCQkJCQkJCQkJCQiNCIyNCQkIjI0JCQkJCQiMjI0JCQkJCQkJCQkJCQkJCQkIjIyYjI0JCQkJCQkJCQkJCQkdHRy5cIilcbiAgICAgICAgcHJpbnQoXCIgICBeOiAgICAuXjVCR0IjQkJCQkJCQkJCQkImI0JCQkJCQkJCQiMjQkJCQkJCJiNCQkIjIyNCQkJCQkIjI0JCQkJCQkJCQkJCQkJCQkJ8fHx8fHx8QkJCQkJCQkJCQkJCQkdQLlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgOkdCR0IjI0JCQkJCQkJCQkJCQiMjQkJCQkJCQkIjJkJCQkJCQkImI0JCIyZCQkJCQkJCQiMjI0JCQkJCQkJCQkJCQkJ8fHx8fHx8fHx8QkJCQkJCQkJCIyZAJkdQXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgWUJQRyMjQkJCQkJCQkJCQiMjI0JCQkJCQkJCQkImI0JCQkJCQiMjIyMjI0JCQkJCQkJCJiNCQkJCQkJCQkJCQkJCQnx8fHx8fHx8fEJCQkJCQkJCJkBAQEJCN1wiKVxuICAgICAgICBwcmludChcIiAgICAgICA6SjVCR0JCIyNCQkJCQkJCQkJCIyZCQkJCQkJCQkJCIyNCQkJCQkJCQkImIyNCQkJCQkIjIyNCQkJCQkJCQkJCQkJCQkJ8fHx8fHx8fEJCQkJCQkJCJiNHJiNCWVwiKVxuICAgICAgICBwcmludChcIiAgICAgICAuN0JCR0JCJkJCQkJCQkJCQkJCIyNCQkJCQkJCQkJCQkIjI0JCQkJCIyMjIyMjI0JCQkIjIyMjQkJCQkJCQkJCQkJCQkJ8fHx8fHxCQkJCQkJCQkJCJiYjI0JZLlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgIF5QJkIjI0JCQkJCQkJCIyMjJiNCQkJCQkJCQkIjIyMmI0JCQiMjJiMjQkIjIyMjIyMjIyYjIyMjI0JCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQiNCUCFcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgXjdQIyMmI0JCQkJCQiMmI0JCQkJCQkIjIyMjJiMjJiMjIyMjQiNCQkJCQkJCIyMjQkJCQkIjQiMjI0JCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkc1Ny5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAufjdKUEJCQkIjIyMjIyMjQiMjQiMmIyMjI0JCIyMjI0IjI0JCI0JCIyMjIyNCQiMjI0IjI0JCQkIjIyMjQiMjQiMjQiMjQiMjQiNCRzVKITpcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgOl5+fj9KISE3N1BQP0pKPz9ZSjU1WVBHUFk1NVlKNVlKWUo/P0pKUEc1P0pKITdKR0dQNUpZSj9ZWT9+IVlZP0pQWVlZN14uXCIpXG5cbiAgICAgICAgcHJpbnQoXCJcXG5NaXN0eSBoYXMgZGVhbHRcIiwgbWlzdHlBdHRhY2ssIFwiZGFtYWdlIHRvIHlvdVwiKVxuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG58fFlvdXIgaGVhbHRoIGlzXCIsIHBsYXllckhlYWx0aCArIFwifHxcIilcblxuXG4gICAgICAgIHByaW50KFwiXFxuXFxufHwgRW5lbWllcyBIZWFsdGggaXNcIiwgbWlzdHlIZWFsdGggKyBcInx8XCIpO1xuXG4gICAgICAgIHByaW50KFwiXFxuXFxuXFxuKDEpIE5vcm1hbCBhdHRhY2sgNzUlIGNoYW5jZSBpdCBoaXRzIGFuZCBpdCBkZWFsc1wiLCBub3JtYWxBdHRhY2spXG4gICAgICAgIHByaW50KFwiXFxuKDIpIFN0cm9uZyBhdHRhY2s6IDQ1JSBjaGFuY2Ugb2YgaGl0dGluZyBhbmQgZGVhbHNcIiwgc3Ryb25nQXR0YWNrKVxuICAgICAgICBwcmludChcIlxcbigzKSBIZWFsOiBIZWFsc1wiLCBoZWFsLCBcIm9mIGhlYWx0aCBcIilcblxuICAgICAgICBpbnB1dCA9IGdldElucHV0KCk7XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMVwiKSB7XG4gICAgICAgICAgICBwbGF5ZXJBdHRhY2tSYW5kb20gPSBNYXRoLnJhbmRvbSgpO1xuICAgICAgICAgICAgaWYgKHBsYXllckF0dGFja1JhbmRvbSA8PSAwLjc1KSB7XG4gICAgICAgICAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG5Zb3UgZGVhbHRcIiwgbm9ybWFsQXR0YWNrLCBcImRhbWFnZSB0byB0aGUgdGhlIE1pc3R5XCIpXG4gICAgICAgICAgICAgICAgbWlzdHlIZWFsdGggPSBtaXN0eUhlYWx0aCAtIG5vcm1hbEF0dGFjaztcbiAgICAgICAgICAgICAgICBGdW4udGhyZWFkU2xlZXAoMTAwMClcblxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwcmludChcIlxcblxcblxcblxcbllvdSBtaXNzZWQgdGhlIGF0dGFja1wiKVxuICAgICAgICAgICAgICAgIEZ1bi50aHJlYWRTbGVlcCgxMDAwKVxuXG5cbiAgICAgICAgICAgIH1cblxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMlwiKSB7XG4gICAgICAgICAgICBwbGF5ZXJBdHRhY2tSYW5kb20gPSBNYXRoLnJhbmRvbSgpO1xuICAgICAgICAgICAgaWYgKHBsYXllckF0dGFja1JhbmRvbSA8PSAwLjQ1KSB7XG4gICAgICAgICAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG55b3UgZGVhbHRcIiwgc3Ryb25nQXR0YWNrLCBcImRhbWFnZSB0byB0aGUgTWlzdHlcIilcbiAgICAgICAgICAgICAgICBtaXN0eUhlYWx0aCA9IG1pc3R5SGVhbHRoIC0gc3Ryb25nQXR0YWNrO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwcmludChcIlxcblxcblxcblxcbllvdSBtaXNzZWQgdGhlIGF0dGFja1wiKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIzXCIpIHtcbiAgICAgICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxueW91IGhlYWxlZFwiLCBoZWFsLCBcImhlYWx0aFwiKVxuICAgICAgICAgICAgcGxheWVySGVhbHRoID0gcGxheWVySGVhbHRoICsgaGVhbDtcbiAgICAgICAgICAgIEZ1bi50aHJlYWRTbGVlcCgxMDAwKVxuICAgICAgICB9XG5cbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWlzdHkgQmF0dGxlXCIgJiYgcGxheWVySGVhbHRoIDwgMSkge1xuICAgICAgICBwcmludChcIlxcblxcbl9fICAgX18gICAgICAgICAgIF9fX19fXyBfICAgICAgICAgIF9cIilcbiAgICAgICAgcHJpbnQoXCJcXFxcIFxcXFwgLyAvICAgICAgICAgICB8ICBfICAoXykgICAgICAgIHwgfFwiKVxuICAgICAgICBwcmludChcIiBcXFxcIFYgL19fXyAgXyAgIF8gIHwgfCB8IHxfICBfX18gIF9ffCB8XCIpXG4gICAgICAgIHByaW50KFwiICBcXFxcIC8vIF8gXFxcXHwgfCB8IHwgfCB8IHwgfCB8LyBfIFxcXFwvIF9gIHxcIilcbiAgICAgICAgcHJpbnQoXCIgIHwgfCAoXykgfCB8X3wgfCB8IHwvIC98IHwgIF9fLyAoX3wgfFwiKVxuICAgICAgICBwcmludChcIiAgXFxcXF8vXFxcXF9fXy8gXFxcXF9fLF98IHxfX18vIHxffFxcXFxfX198XFxcXF9fLF98XCIpXG4gICAgICAgIGdhbWVPdmVyID0gdHJ1ZVxuICAgIH1cblxuICAgIGlmIChzY3JlZW4gPT0gXCJNaXN0eSBCYXR0bGVcIiAmJiBtaXN0eUhlYWx0aCA8IDEpIHtcbiAgICAgICAgbWlzdHlTdHJlbmd0aCA9IG1pc3R5U3RyZW5ndGggKyAxMDtcbiAgICAgICAgY29pbnNHb3R0ZW4gPSBtaXN0eVN0cmVuZ3RoICogMC42O1xuICAgICAgICBjb2lucyA9IGNvaW5zICsgY29pbnNHb3R0ZW47XG4gICAgICAgIHByaW50KFwiXFxuWU9VIFdPTiwgeW91IGdldFwiLCBjb2luc0dvdHRlbiwgXCJjb2luc1wiKTtcbiAgICAgICAgcHJpbnQoXCJcXG5Zb3UgaGF2ZVwiLCBjb2lucywgXCJjb2luc1wiKTtcblxuICAgICAgICBzY3JlZW4gPSBuZXh0U2NyZWVuO1xuXG4gICAgfVxuXG5cblxuXG5cblxuXG5cbiAgICBpZiAoc2NyZWVuID09IFwic3BsYXNoIHNjcmVlblwiKSB7XG5cbiAgICAgICAgcHJpbnQoXCIgICAgICAgIF8gICAgIF8gICAgICAgICAgICAgX19fICAgICAgICAgICAgICAgICAgIF8gICBcIilcbiAgICAgICAgcHJpbnQoXCIgIC9cXFxcL1xcXFwgKF8pX19ffCB8XyBfICAgXyAgICAvIF9fXFxcXF9fICBfIF9fIF9fXyAgX19ffCB8XyBcIilcbiAgICAgICAgcHJpbnQoXCIgLyAgICBcXFxcfCAvIF9ffCBfX3wgfCB8IHwgIC8gX1xcXFwvIF8gXFxcXHwgJ19fLyBfIFxcXFwvIF9ffCBfX3xcIilcbiAgICAgICAgcHJpbnQoXCIvIC9cXFxcL1xcXFwgXFxcXCBcXFxcX18gXFxcXCB8X3wgfF98IHwgLyAvIHwgKF8pIHwgfCB8ICBfXy9cXFxcX18gXFxcXCB8XyBcIilcbiAgICAgICAgcHJpbnQoXCJcXFxcLyAgICBcXFxcL198X19fL1xcXFxfX3xcXFxcX18sIHwgXFxcXC8gICBcXFxcX19fL3xffCAgXFxcXF9fX3x8X19fL1xcXFxfX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICB8X19fLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIilcblxuICAgICAgICBwcmludChcIlwiKVxuICAgICAgICBwcmludChcIigxKSB0eXBlIDEgdG8gc3RhcnQgKDIpIHR5cGUgMiB0byBxdWl0XCIpXG5cbiAgICAgICAgaW5wdXQgPSBnZXRJbnB1dCgpO1xuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjFcIikge1xuICAgICAgICAgICAgc2NyZWVuID0gXCJwbGF5ZXIgbmFtZVwiO1xuXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIyXCIpIHtcblxuICAgICAgICAgICAgcHJpbnQoXCJxdWl0aW5nLi4uXCIpXG4gICAgICAgICAgICBnYW1lT3ZlciA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwicGxheWVyIG5hbWVcIikge1xuXG4gICAgICAgIHByaW50KFwiUGxlYXNlIGVudGVyIHlvdXIgbmFtZVwiKTtcbiAgICAgICAgcGxheWVyTmFtZSA9IGdldElucHV0KCk7XG5cbiAgICAgICAgcHJpbnQoXCJIaVwiLCBwbGF5ZXJOYW1lKVxuXG4gICAgICAgIHByaW50KFwiKDEpIEdvIHRvIGZpcnN0IGZpZ2h0XCIpO1xuICAgICAgICBjb3VudCA9IDBcbiAgICAgICAgaW5wdXQgPSBnZXRJbnB1dCgpO1xuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjFcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcImZpcnN0IGZpZ2h0XCI7XG4gICAgICAgIH1cblxuICAgIH1cblxuICAgIGlmIChzY3JlZW4gPT0gXCJmaXJzdCBmaWdodFwiICYmIHlvdW5nTWlzdHlIZWFsdGggPiAwICYmIHBsYXllckhlYWx0aCA+IDApIHtcblxuICAgICAgICBwbGF5ZXJIZWFsdGggPSBwbGF5ZXJIZWFsdGggLSA1XG4gICAgICAgIG5vcm1hbEF0dGFjayA9IHN0cmVuZ3RoICogMC4xXG4gICAgICAgIHN0cm9uZ0F0dGFjayA9IHN0cmVuZ3RoICogMC4yNVxuICAgICAgICBoZWFsID0gc3RyZW5ndGggKiAwLjFcblxuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5Zb3UgWW91IGFyZSBnZXR0aW5nIGF0dGFja2VkIGJ5IGEgWW91bmcgTWlzdHkgXFxuQ2hvb3NlIHlvdXIgYXR0YWNrXCIpO1xuXG5cbiAgICAgICAgaWYgKGNvdW50IDwgMSkge1xuICAgICAgICAgICAgcHJpbnQoXCJcXG5Zb3VuZyBNaXN0eSBkZWFscyA1IGhlYWx0aCBvZiBkYW1hZ2UgYW5kIGhhcyAxMDAgaGVhbHRoXCIpO1xuICAgICAgICAgICAgcHJpbnQoXCJOT1RFOiBZb3VyIGhlYWx0aCBjYW4gZ28gYmVsb3cgemVybyBhbmQgeW91IGhhdmUgYSBvbmUgY2hhbmNlIHRvIGtpbGwgdGhlIGVuZW15IGJ1dCBpZiB5b3UgZG9uJ3QgeW91IHdpbGwgZGllLlwiKVxuICAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgIH1cblxuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAICAgICBAOkAgIEA6QCAgICAgICBAXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQEAgQDo6Ojo6Ojo6OkBAQEBAICBAOkBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQDo6OjpAQEA6Ojo6QDo6Ojo6QCBAQDo6XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBAICAgQEBAICAgICBAQEBAQEBAQEBAQEBAOjo6Ojo6QFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAOjpAQDpAQCAgICAgIEBAQEBAQEBAICAgICBAICBAQDo6OkAgICBAXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgQDpAIEA6Ojo6QEBAQEBAQEBAQEBAQEBAQEBAQEAgQCAgICBAICAgQDo6OkBAOkBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQEAgICBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEA6OkAgICBAQEA6OkBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEAgICAgQCAgICBAQCAgQEBAQEBAQEBAQEBAQEBAQEBAOkBAICAgICBAOkBAQDpcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICA6Ojo6QEA6OiAgICAgICAgICBAQEBAQEBAQEBAQEBAQEBAQEBAQDogICBAOjo6OjpAXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgIDpAQEBAQEBAQEBAQDpAQEBAQCBAQEBAQEBAQEBAQEBAQEBAQEBAQEA6QCAgIDo6Ojo6QFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQDpAIEBAOjo6OkBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgQEBAQDpAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAOkBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgQDpAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQCAgICAgQEBAQEBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICBAQDpAQCBAQEAgIEBAQEBAQEBAQEBAQEBAQEBAQEBAICAgICAgQEBAQEBAQEBAQCAgIEA6QFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICBAOjpAICAgICAgICAgICBAQEBAQEBAQEBAQEBAQEBAQEAgICAgIEBAQEBAQDo6QCAgICBAXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgQDpAICAgICAgICAgICAgQEBAQEBAQEBAQEBAQEBAQEBAQCAgICBAQEBAOjo6OkAgICBAXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgOjpAICA6QCAgICAgICAgICAgICBAQEBAQEBAQEBAQEBAQEAgICAgICBAOjo6OkBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICBAQEAgJCQkJCAgICAgIEAkOkAgICBAQEBAQEBAQEBAQEBAQEBAQCAgIEA6OkBAQEBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEAgQCQkJEAgICAgQCQkJCQ6ICAgICBAQEBAQEBAQEBAQEBAICAgQDo6QEBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICQkIEAgICAgJCQkJCQkJCAgICAgICAgIEBAQEBAQEBAXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6JCQkJEAgICAgQEBAICAgIEBAICAgICAgICBAOkBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAOiAgICAgICAgICAgIEAgICAgQFwiKVxuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG5NaXN0eSBoYXMgZGVhbHQgNSBkYW1hZ2UgdG8geW91XCIpXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG58fFlvdXIgaGVhbHRoIGlzXCIsIHBsYXllckhlYWx0aCArIFwifHxcIilcblxuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG58fCBFbmVtaWVzIEhlYWx0aCBpc1wiLCB5b3VuZ01pc3R5SGVhbHRoICsgXCJ8fFwiKTtcblxuICAgICAgICBwcmludChcIlxcblxcblxcbigxKSBOb3JtYWwgYXR0YWNrIDc1JSBjaGFuY2UgaXQgaGl0cyBhbmQgaXQgZGVhbHNcIiwgbm9ybWFsQXR0YWNrKVxuICAgICAgICBwcmludChcIlxcbigyKSBTdHJvbmcgYXR0YWNrOiA0NSUgY2hhbmNlIG9mIGhpdHRpbmcgYW5kIGRlYWxzXCIsIHN0cm9uZ0F0dGFjaylcbiAgICAgICAgcHJpbnQoXCJcXG4oMykgSGVhbDogSGVhbHNcIiwgaGVhbCwgXCJvZiBoZWFsdGggXCIpXG4gICAgICAgIHByaW50KFwiXFxuKDQpaXRlbXM6IE5vIGl0ZW1zIGZvdW5kXCIpXG4gICAgICAgIGNvdW50ID0gY291bnQgKyAxXG5cbiAgICAgICAgaW5wdXQgPSBnZXRJbnB1dCgpO1xuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjFcIikge1xuXG4gICAgICAgICAgICBwbGF5ZXJBdHRhY2tSYW5kb20gPSBNYXRoLnJhbmRvbSgpO1xuICAgICAgICAgICAgaWYgKHBsYXllckF0dGFja1JhbmRvbSA8PSAwLjc1KSB7XG4gICAgICAgICAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG5Zb3UgZGVhbHRcIiwgbm9ybWFsQXR0YWNrLCBcImRhbWFnZSB0byB0aGUgWW91bmcgTWlzdHlcIilcbiAgICAgICAgICAgICAgICB5b3VuZ01pc3R5SGVhbHRoID0geW91bmdNaXN0eUhlYWx0aCAtIG5vcm1hbEF0dGFjaztcblxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwcmludChcIlxcblxcblxcblxcbllvdSBtaXNzZWQgdGhlIGF0dGFja1wiKVxuXG5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEZ1bi50aHJlYWRTbGVlcCgxMDAwKVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMlwiKSB7XG5cbiAgICAgICAgICAgIHBsYXllckF0dGFja1JhbmRvbSA9IE1hdGgucmFuZG9tKCk7XG4gICAgICAgICAgICBpZiAocGxheWVyQXR0YWNrUmFuZG9tIDw9IDAuNDUpIHtcbiAgICAgICAgICAgICAgICBwcmludChcIlxcblxcblxcblxcbnlvdSBkZWFsdFwiLCBzdHJvbmdBdHRhY2ssIFwiZGFtYWdlIHRvIHRoZSB5b3VuZyBNaXN0eVwiKVxuICAgICAgICAgICAgICAgIHlvdW5nTWlzdHlIZWFsdGggPSB5b3VuZ01pc3R5SGVhbHRoIC0gc3Ryb25nQXR0YWNrO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwcmludChcIlxcblxcblxcblxcbllvdSBtaXNzZWQgdGhlIGF0dGFja1wiKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIzXCIpIHtcbiAgICAgICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxueW91IGhlYWxlZFwiLCBoZWFsLCBcImhlYWx0aFwiKVxuICAgICAgICAgICAgcGxheWVySGVhbHRoID0gcGxheWVySGVhbHRoICsgaGVhbDtcbiAgICAgICAgICAgIEZ1bi50aHJlYWRTbGVlcCgxMDAwKVxuICAgICAgICB9XG5cbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwiZmlyc3QgZmlnaHRcIiAmJiBwbGF5ZXJIZWFsdGggPD0gMCkge1xuICAgICAgICBwcmludChcIllvdSBkaWVkXCIpXG4gICAgICAgIGdhbWVPdmVyID0gdHJ1ZVxuICAgIH1cblxuICAgIGlmIChzY3JlZW4gPT0gXCJmaXJzdCBmaWdodFwiICYmIHlvdW5nTWlzdHlIZWFsdGggPD0gMCkge1xuICAgICAgICBwcmludChcIlxcbllPVSBXT04sIHlvdSBnZXQgMTAwIGNvaW5zXCIpXG4gICAgICAgIGNvaW5zID0gY29pbnMgKyAxMDBcblxuICAgICAgICBzY3JlZW4gPSBcIk1haW4gaHViXCJcbiAgICB9XG5cblxuXG5cblxuXG5cblxuXG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWFpbiBodWJcIikge1xuXG4gICAgICAgIHByaW50KFwiXFxuV2hlcmUgZG8geW91IHdhbnQgdG8gZ29cIilcbiAgICAgICAgcHJpbnQoXCJcXG4oMSlHbyB0byBNaXN0IFRvd2VyIFxcbigyKUdvIHRvIFVwZ3JhZGUgU3RvcmUgXFxuKDMpR28gdG8gTWlzdHkgRm9yZXN0XCIpXG5cbiAgICAgICAgaW5wdXQgPSBnZXRJbnB1dCgpO1xuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjFcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcIk1pc3QgVG93ZXJcIjtcblxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMlwiKSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwic2hvcFwiXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIzXCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID0gXCJNaXN0eSBGb3Jlc3QgRW50cmFuY2VcIjtcblxuICAgICAgICB9XG4gICAgfVxuXG5cblxuXG5cblxuXG5cblxuICAgIC8vTWlzdCBUb3dlclxuXG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWlzdCBUb3dlclwiICYmIG1pc3RHYXVyZGlhbkJlYXRlbiA9PSBmYWxzZSkge1xuXG5cbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgXywuX1wiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgLCcgICAsYC0uXCIpXG4gICAgICAgIHByaW50KFwifC4gICAgICAgIC8gICAgIHxcXFxcICBgLlwiKVxuICAgICAgICBwcmludChcIlxcXFwgXFxcXCAgICAgICggICwtLC1gICkuIGAtLl8gX19cIilcbiAgICAgICAgcHJpbnQoXCIgXFxcXCBcXFxcICAgICAgXFxcXHxcXFxcLCcgICAgIGBcXFxcICAvJyAgYFxcXFxcIilcbiAgICAgICAgcHJpbnQoXCIgIFxcXFwgXFxcXCAgICAgIGAgfCwgLCAgLyAgXFxcXCBcXFxcICAgICBcXFxcXCIpXG4gICAgICAgIHByaW50KFwiICAgXFxcXCBcXFxcICAgICAgICAgYCxfL2AsIC9cXFxcLGAtLl9fL2AuXCIpXG4gICAgICAgIHByaW50KFwiICAgIFxcXFwgXFxcXCAgICAgICAgICAgIHwgYCAvICAgIC8gICAgYC0uX1wiKVxuICAgICAgICBwcmludChcIiAgICAgXFxcXFxcXFxcXFxcICAgICAgICAgICBgLS8nICAgIC8gICAgICAgICBgLS5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICBcXFxcXFxcXGAvIF9fX19fX18sLS9fICAgLycgICAgICAgICAgICAgXFxcXFwiKVxuICAgICAgICBwcmludChcIiAgICAgLS0tJ2B8ICAgICAgIHxgICApLCcgYC0tLS4gICwgICAgICAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgIFxcXFwuLi1gLS0uLl9fX3xfLC8gICAgICAgICAgLyAgICAgICAvXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICB8ICAgIHxgLC0sLi4uLC8gICAgICAsJyAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICBcXFxcICAgIHwgfF98ICAgLyAgICAgLCcgX18gIHItJycsXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgfF9fX3wvICB8LCAvICBfXyAvLScnICBgJ2ApICB8ICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICBfLC0nICAgfHxfX1xcXFxcXFxcIC8sLScgLyAgICAgXywuLS18ICAoXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgLi0nICAgICAgICkgICBgKF8gICAvIF8sLi0nICAsLScgXywvXCIpXG5cblxuICAgICAgICBwcmludChcIlxcbkFzIHlvdSBhcHByb2FjaCB0aGUgZW50cmFuY2Ugb2YgdGhlIHRvd2VyLCB0aGUgTWlzdCBHdWFyZGlhbiBmYWxscyBmcm9tIHRoZSBza3kuXCIpXG5cbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApXG5cbiAgICAgICAgcHJpbnQoXCJcIilcblxuICAgICAgICBwcmludChcIlRoZSBNaXN0IEd1YXJkaWFuIGRlYWxzIDQwIGRhbWFnZSBldmVyeSBhdHRhY2sgYnV0IGhhcyB0ZXJyaWJsZSBhY2N1cmFjeSBhbmQgaGFzIDUwMCBoZWFsdGguXCIpXG5cbiAgICAgICAgcHJpbnQoXCJcXG4oSGFzIGEgNjAlIGNoYW5jZSBvZiBoaXR0aW5nIHlvdSlcIilcblxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoMzAwMClcblxuICAgICAgICBtaXN0R3VhcmRpYW5IZWFsdGggPSA1MDBcblxuICAgICAgICBwbGF5ZXJIZWFsdGggPSBtYXhQbGF5ZXJIZWFsdGhcblxuICAgICAgICBjb3VudCA9IDBcblxuXG5cbiAgICAgICAgc2NyZWVuID0gXCJNaXN0IEd1YXJkaWFuIFRvd2VyIEJvc3NcIjtcbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWlzdCBHdWFyZGlhbiBUb3dlciBCb3NzXCIgJiYgcGxheWVySGVhbHRoID4gMCAmJiBtaXN0R3VhcmRpYW5IZWFsdGggPiAwKSB7XG5cbiAgICAgICAgbWlzdEd1YXJkaWFuQXR0YWNrUmFuZG9tID0gTWF0aC5yYW5kb20oKTtcblxuICAgICAgICBub3JtYWxBdHRhY2sgPSBzdHJlbmd0aCAqIDAuMVxuICAgICAgICBzdHJvbmdBdHRhY2sgPSBzdHJlbmd0aCAqIDAuMjVcbiAgICAgICAgaGVhbCA9IHN0cmVuZ3RoICogMC4xXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG4gICAgICAgIHByaW50KFwiXFxuICAgICAgXywuXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgLGAgLS4pXCIpXG4gICAgICAgIHByaW50KFwiICAgICAoIF8vLVxcXFxcXFxcLS5fXCIpXG4gICAgICAgIHByaW50KFwiICAgIC8sfGAtLS5fLC1efCAgICAgICAgICAgICxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgXFxcXF98IHxgLS5fL3x8ICAgICAgICAgICwnfFwiKVxuICAgICAgICBwcmludChcIiAgICAgIHwgIGAtLCAvIHwgICAgICAgICAvICAvXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgfCAgICAgfHwgfCAgICAgICAgLyAgL1wiKVxuICAgICAgICBwcmludChcIiAgICAgICBgci0uX3x8LyAgIF9fICAgLyAgL1wiKVxuICAgICAgICBwcmludChcIiAgIF9fLC08XyAgICAgKWAtLyAgYC4vICAvXCIpXG4gICAgICAgIHByaW50KFwiICAnICBcXFxcICAgYC0tLScgICBcXFxcICAgLyAgL1wiKVxuICAgICAgICBwcmludChcIiAgICAgIHwgICAgICAgICAgIHwuLyAgL1wiKVxuICAgICAgICBwcmludChcIiAgICAgIC8gICAgICAgICAgIC8vICAvXCIpXG4gICAgICAgIHByaW50KFwiICBcXFxcXy8nIFxcXFwgICAgICAgICB8LyAgL1wiKVxuICAgICAgICBwcmludChcIiAgIHwgICAgfCAgIF8sXi0nLyAgL1wiKVxuICAgICAgICBwcmludChcIiAgIHwgICAgLCBgYCAgKFxcXFwvICAvX1wiKVxuICAgICAgICBwcmludChcIiAgICBcXFxcLC4tPi5fICAgIFxcXFxYLT0vXlwiKVxuICAgICAgICBwcmludChcIiAgICAoICAvICAgYC0uXy8vXmBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgIGBZLS5fX19fKF9ffVwiKVxuICAgICAgICBwcmludChcIiAgICAgIHwgICAgIHtfXylcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAoKVwiKVxuXG5cblxuXG4gICAgICAgIGlmIChtaXN0R3VhcmRpYW5BdHRhY2tSYW5kb20gPiAwLjQwICYmIGNvdW50ID4gMCkge1xuXG4gICAgICAgICAgICBwcmludChcIlxcbihNaXN0IEd1YXJkaWFuIGhhcyBkZWFsdFwiLCA0NSwgXCJkYW1hZ2UgdG8geW91KVwiKVxuXG4gICAgICAgICAgICBwbGF5ZXJIZWFsdGggPSBwbGF5ZXJIZWFsdGggLSA0MDtcblxuXG4gICAgICAgIH0gZWxzZSBpZiAobWlzdEd1YXJkaWFuQXR0YWNrUmFuZG9tIDw9IDAuNDApIHtcbiAgICAgICAgICAgIHByaW50KFwiXFxuKE1pc3QgR3VhcmRpYW4gTWlzc2VkKVwiKVxuXG4gICAgICAgIH1cblxuXG5cblxuICAgICAgICBwcmludChcIlxcblxcbnx8WW91ciBoZWFsdGggaXNcIiwgcGxheWVySGVhbHRoICsgXCJ8fFwiKVxuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG58fCBNaXN0IEd1YXJkaWFuIEhlYWx0aCBpc1wiLCBtaXN0R3VhcmRpYW5IZWFsdGggKyBcInx8XCIpO1xuXG4gICAgICAgIHByaW50KFwiXFxuXFxuKDEpIE5vcm1hbCBhdHRhY2sgNzUlIGNoYW5jZSBpdCBoaXRzIGFuZCBpdCBkZWFsc1wiLCBub3JtYWxBdHRhY2spXG4gICAgICAgIHByaW50KFwiXFxuKDIpIFN0cm9uZyBhdHRhY2s6IDQ1JSBjaGFuY2Ugb2YgaGl0dGluZyBhbmQgZGVhbHNcIiwgc3Ryb25nQXR0YWNrKVxuICAgICAgICBwcmludChcIlxcbigzKSBIZWFsOiBIZWFsc1wiLCBoZWFsLCBcIm9mIGhlYWx0aCBcIilcblxuICAgICAgICBjb3VudCA9IGNvdW50ICsgMVxuXG4gICAgICAgIGlucHV0ID0gZ2V0SW5wdXQoKTtcblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgIHBsYXllckF0dGFja1JhbmRvbSA9IE1hdGgucmFuZG9tKCk7XG4gICAgICAgICAgICBpZiAocGxheWVyQXR0YWNrUmFuZG9tIDw9IDAuNzUpIHtcbiAgICAgICAgICAgICAgICBwcmludChcIlxcblxcblxcblxcbllvdSBkZWFsdFwiLCBub3JtYWxBdHRhY2ssIFwiZGFtYWdlIHRvIHRoZSB0aGUgTWlzdCBHdWFyZGlhbiBcIilcbiAgICAgICAgICAgICAgICBtaXN0R3VhcmRpYW5IZWFsdGggPSBtaXN0R3VhcmRpYW5IZWFsdGggLSBub3JtYWxBdHRhY2s7XG4gICAgICAgICAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApXG5cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG5Zb3UgbWlzc2VkIHRoZSBhdHRhY2tcIilcbiAgICAgICAgICAgICAgICBGdW4udGhyZWFkU2xlZXAoMTAwMClcblxuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjJcIikge1xuICAgICAgICAgICAgcGxheWVyQXR0YWNrUmFuZG9tID0gTWF0aC5yYW5kb20oKTtcbiAgICAgICAgICAgIGlmIChwbGF5ZXJBdHRhY2tSYW5kb20gPD0gMC40NSkge1xuICAgICAgICAgICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxueW91IGRlYWx0XCIsIHN0cm9uZ0F0dGFjaywgXCJkYW1hZ2UgdG8gdGhlIE1pc3QgR3VhcmRpYW4gXCIpXG4gICAgICAgICAgICAgICAgbWlzdEd1YXJkaWFuSGVhbHRoID0gbWlzdEd1YXJkaWFuSGVhbHRoIC0gc3Ryb25nQXR0YWNrO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwcmludChcIlxcblxcblxcblxcbllvdSBtaXNzZWQgdGhlIGF0dGFja1wiKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIzXCIpIHtcbiAgICAgICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxueW91IGhlYWxlZFwiLCBoZWFsLCBcImhlYWx0aFwiKVxuICAgICAgICAgICAgcGxheWVySGVhbHRoID0gcGxheWVySGVhbHRoICsgaGVhbDtcbiAgICAgICAgICAgIEZ1bi50aHJlYWRTbGVlcCgxMDAwKVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHNjcmVlbiA9PSBcIk1pc3QgR3VhcmRpYW4gVG93ZXIgQm9zc1wiICYmIHBsYXllckhlYWx0aCA8IDEpIHtcbiAgICAgICAgcHJpbnQoXCJcXG5cXG5fXyAgIF9fICAgICAgICAgICBfX19fX18gXyAgICAgICAgICBfXCIpXG4gICAgICAgIHByaW50KFwiXFxcXCBcXFxcIC8gLyAgICAgICAgICAgfCAgXyAgKF8pICAgICAgICB8IHxcIilcbiAgICAgICAgcHJpbnQoXCIgXFxcXCBWIC9fX18gIF8gICBfICB8IHwgfCB8XyAgX19fICBfX3wgfFwiKVxuICAgICAgICBwcmludChcIiAgXFxcXCAvLyBfIFxcXFx8IHwgfCB8IHwgfCB8IHwgfC8gXyBcXFxcLyBfYCB8XCIpXG4gICAgICAgIHByaW50KFwiICB8IHwgKF8pIHwgfF98IHwgfCB8LyAvfCB8ICBfXy8gKF98IHxcIilcbiAgICAgICAgcHJpbnQoXCIgIFxcXFxfL1xcXFxfX18vIFxcXFxfXyxffCB8X19fLyB8X3xcXFxcX19ffFxcXFxfXyxffFwiKVxuICAgICAgICBnYW1lT3ZlciA9IHRydWVcbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWlzdCBHdWFyZGlhbiBUb3dlciBCb3NzXCIgJiYgbWlzdEd1YXJkaWFuSGVhbHRoIDwgMSkge1xuXG4gICAgICAgIHByaW50KFwiXFxuWU9VIFdPTlwiKVxuICAgICAgICBwcmludChcIlxcblRpbWUgdG8gZmlnaHQgdGhlIE1pc3QgRHJhZ29uXCIpXG5cbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKDIwMDApXG4gICAgICAgIG1pc3RHYXVyZGlhbkJlYXRlbiA9IHRydWU7XG5cbiAgICAgICAgc2NyZWVuID0gXCJNaXN0IFRvd2VyXCJcblxuICAgIH1cblxuXG4gICAgaWYgKHNjcmVlbiA9PSBcIk1pc3QgVG93ZXJcIiAmJiBtaXN0R2F1cmRpYW5CZWF0ZW4gPT0gdHJ1ZSkge1xuXG4gICAgICAgIHByaW50KFwiXFxuWW91IGVudGVyIHRoZSB0b3dlciBhbmQgc2VlIGEgbGFyZ2UgY29sbGVjdGlvbiBvZiBzdGFpcnMgdGhhdCBwcm9iYWJseSBsZWFkIHRvIHRoZSByb29mIG9mIHRoZSB0b3dlclwiKTtcblxuICAgICAgICBwcmludChcIlxcbigxKUNsaW1iIHRoZSBzdGFpcnMgdG8gdGhlIHJvb2YgXFxuKDIpR28gYmFja1wiKVxuXG4gICAgICAgIGlucHV0ID0gZ2V0SW5wdXQoKTtcblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIxXCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID0gXCJNaXN0IERyYWdvblwiXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIyXCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID09IFwiTWFpbiBodWJcIlxuICAgICAgICB9XG5cbiAgICB9XG5cblxuICAgIGlmIChzY3JlZW4gPT0gXCJNaXN0IERyYWdvblwiKSB7XG5cbiAgICAgICAgcHJpbnQoXCJcXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcL1wiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF5gJy5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBeICAgYCcuXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICggICAgICAgICAgICAgICAgICAgICAgICAgXiAgICAgIGAnLlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgKSAgKSAgICAgICAgXFxcXC8gICAgICAgICAgICAgIF4gICAgICAgICBgJy5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAoICAgKSBAICAgICAgIC9eICAgICAgICAgICAgICBeICAgICAgICAgICAgYCcuXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICkgICkpIEBAICApICAgIC8gIF4gICAgICAgICAgICAgXiAgICAgICAgICAgICAgIGAnLlwiKVxuICAgICAgICBwcmludChcIiAgICAgICggKCApIClAQCAgICAgIC8gICAgXiAgICAgICAgICAgIF4gICAgICAgICAgICAgICAgICBgJy5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgKSkgICggQEAgQCApICAgIC8gICAgICBeICAgICAgICAgICBeICAgICAgICAgICAgICAgICAgICAgYCcuXCIpXG4gICAgICAgIHByaW50KFwiICAgKCAoIEBAQEBAKEAgICAgIC8gICAgICAgfFxcXFxfL3wsICAgICAgXiAgICAgICAgICAgICAgICAgICAgICAgIGAnLlwiKVxuICAgICAgICBwcmludChcIiAgKSAgKUBAQChAQEAgICAgIC8gICAgICBfL34vfi9+fEMgICAgIF4gICAgICAgICAgICAgICAgICAgICAgICAgICBgJy5cIilcbiAgICAgICAgcHJpbnQoXCIoKEBAQChAQEBAQCggICAgIC8gICAgIF8oQCl+KEApfi9cXFxcQyAgICBeICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCcuXCIpXG4gICAgICAgIHByaW50KFwiICApKUBAQChAQClAQCAgIC8gICAgIC9+L34vfi9+L2BcXFxcfmBDICAgXiAgICAgICAgICAgICBfXy5fXyAgICAgICAgICAgICAgIGAnLlwiKVxuICAgICAgICBwcmludChcIiAgIClAQEBAKEBAKUBAQCggICAgIChvfi9+byleLCkgXFxcXH4gXFxcXEMgIF4gICAgICAgICAgLicgLV8nLSdcXFwiLi4uICAgICAgICAgICAgIGAuXCIpXG4gICAgICAgIHByaW50KFwiICAgICggKEBAQClAQEAoQEBAQEBAX35efl5+LC0vXFxcXH4gXFxcXH4gXFxcXEMvXiAgICAgICAgL2Atfl4sLX4tYF9+LV5gO18gICAgICAgICAgIGAuXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgQCApQEBAKEBAQEBAQEAgICBcXFxcXl5eLyAgKGBeXFxcXC5+XiBDXi4sICAvfl5+Xn5eL19eLV9gfi1gfi1+XlxcXFwtIC9gJy0uL2AnLS4gO1wiKVxuICAgICAgICBwcmludChcIiAgICAgICAoQCAoQEBAQChAQCAgICAgIGAnJyAgKCggfiAgLmAgLix+Xn5eLWAtXn5gLydeYC1+IF9gfi1gX14tflxcXFwgICAgICAgICBeXlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgQGpnc0AgICAgICAgICAgICAgKCgoYCB+IC4tfi1cXFxcIH5gLV9+YC0vXy1gfiBgLSB+LV8tIGB+YDtcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgLyAgICAgICAgICAgICAgICAgL34oKCgoYCAuIH4tflxcXFxgIGAgIH4gfDpgLV8tfl9+YCAgfiBfYC1gO1wiKVxuICAgICAgICBwcmludChcIiAgICAgICAgIC8gICAgICAgICAgICAgICAgIC9+LSgoKCgoKGAuXFxcXC1+LVxcXFwgfmAtYH5eXFxcXC0gXl8tfiB+YCAtX34tX2B+YDtcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgIC8gICAgICAgICAgICAgICAgIC8tfi0vKCgoKCgoKGBcXFxcfi1+XFxcXH5gXi1gfmBcXFxcIC1+YH5cXFxcLV4gLV9+LV9gfi1gO1wiKVxuICAgICAgICBwcmludChcIiAgICAgICAvICAgICAgICAgICAgICAgICAvfi1+LyAgYCgoKCgoKHwtfi18KChgLi1+LmBZYF8sfmBcXFxcIGAsLSB+LV9gfi1gO1wiKVxuICAgICAgICBwcmludChcIiAgICAgIC8gICAgICAgICAgICAgIF9fXy8tfi0vICAgICBgXFxcIlxcXCJcXFwiXFxcInx+LX58XFxcIicnICAgIC9+LV4gLicgICAgYDp+YC1fYH4tfmA7XCIpXG4gICAgICAgIHByaW50KFwiICAgICAvICAgICAgICAgX19fX18vICAvfi1+LyAgICAgICAgICAgfC1+LXwgICAgICAvLX4tfi5gICAgICAgYDp+XmAtX2BeLTpcIilcbiAgICAgICAgcHJpbnQoXCIgICAgLyAgICBfX19fXy8gICAgICAgICgoKCggICAgICAgICAgICAoKCgoICAgICAgKCgoKChgICAgICAgICAgICBgOn5eLV9+LWA7XCIpXG4gICAgICAgIHByaW50KFwiICAgIFxcXFxfX18vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGA6X14tfmA7XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgOn4tXmA6XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLGB+LX5gLGBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICxcXFwiYH4uLCdcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAsXFxcIi1gLFxcXCJgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICxcXFwiX2AsXFxcIlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICxcXFwiLFxcXCJgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgO34tfl9+fjtcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJy4gfi4nXCIpXG5cbiAgICAgICAgcHJpbnQoXCJcXG5Zb3UgcmVhY2ggdGhlIHJvb2Ygb2YgdGhlIHRvd2VyIGFuZCBhcmUgZ3JlZXRlZCBieSBhIHJvYXIgZnJvbSB0aGUgTWlzdCBEcmFnb24uIFRoZSBtaXN0IERyYWdvbiBoYXMgMTAwMCBoZWFsdGguXCIpXG5cbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKDIwMDApXG5cbiAgICAgICAgcHJpbnQoXCJcXG4oTWlzdCBkcmFnb24gZGVhbHMgMzUgZGFtYWdlIHdpdGggaGlzIHJlZ3VsYXIgYXR0YWNrIGFuZCBoYXMgYSAwJSBjaGFuY2UgaW4gbWlzc2luZyBpdCwgXFxuaGFzIGEgc3Ryb25nIGF0dGFjayB0aGF0IGRlYWxzIDExMCBkYW1hZ2UgYnV0IGhhcyBhIDc1JSBjaGFuY2UgbWlzc2luZyBpdCwgY2FuIGhlYWwgNTUgaGVhbHRoKVwiKVxuXG4gICAgICAgIEZ1bi50aHJlYWRTbGVlcCgyMDAwKVxuXG4gICAgICAgIGNvdW50ID0gMFxuICAgICAgICBwbGF5ZXJIZWFsdGggPSBtYXhQbGF5ZXJIZWFsdGhcbiAgICAgICAgbWlzdERyYWdvbkhlYWx0aCA9IDEwMDBcbiAgICAgICAgc2NyZWVuID0gXCJNaXN0IERyYWdvbiBCb3NzXCJcblxuICAgIH1cblxuXG4gICAgaWYgKHNjcmVlbiA9PSBcIk1pc3QgRHJhZ29uIEJvc3NcIikge1xuXG4gICAgICAgIG1pc3REcmFnb25BdHRhY2tSYW5kb20gPSBNYXRoLnJhbmRvbSgpO1xuICAgICAgICBtaXN0RHJhZ29uQXR0YWNrQ2hhbmNlID0gTWF0aC5yYW5kb20oKTtcblxuICAgICAgICBub3JtYWxBdHRhY2sgPSBzdHJlbmd0aCAqIDAuMVxuICAgICAgICBzdHJvbmdBdHRhY2sgPSBzdHJlbmd0aCAqIDAuMjVcbiAgICAgICAgaGVhbCA9IHN0cmVuZ3RoICogMC4xXG5cblxuXG5cblxuICAgICAgICBwcmludChcIiAgICAgfFxcXFwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC98XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgfCBcXFxcICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLyB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgfCAgXFxcXCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvICB8ICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICB8ICAgXFxcXCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLyAgIHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICB8ICAgIFxcXFwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvICAgIHwgICAgIFwiKVxuICAgICAgICBwcmludChcIl9fX19fKSAgICAgXFxcXCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvICAgICAoX19fXyBcIilcbiAgICAgICAgcHJpbnQoXCJcXFxcICAgICAgICAgICBcXFxcICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvICAgICAgICAgIC8gXCIpXG4gICAgICAgIHByaW50KFwiIFxcXFwgICAgICAgICAgIFxcXFwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvICAgICAgICAgIC8gIFwiKVxuICAgICAgICBwcmludChcIiAgXFxcXCAgICAgICAgICAgYC0tX19fX18gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9fX19fLS0nICAgICAgICAgIC8gICBcIilcbiAgICAgICAgcHJpbnQoXCIgICBcXFxcICAgICAgICAgICAgICAgICAgXFxcXCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8gICAgICAgICAgICAgICAgIC8gICAgXCIpXG4gICAgICAgIHByaW50KFwiX19fXykgICAgICAgICAgICAgICAgICBcXFxcICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8gICAgICAgICAgICAgICAgIChfX19fIFwiKVxuICAgICAgICBwcmludChcIlxcXFwgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgICAgICAgIC98ICAgICAgfFxcXFwgICAgICAgIC8gICAgICAgICAgICAgICAgICAgICAgLyBcIilcbiAgICAgICAgcHJpbnQoXCIgXFxcXCAgICAgICAgICAgICAgICAgICAgICAgXFxcXCAgICAgIHwgLyAgICAgIFxcXFwgfCAgICAgIC8gICAgICAgICAgICAgICAgICAgICAgLyAgXCIpXG4gICAgICAgIHByaW50KFwiICBcXFxcICAgICAgICAgICAgICAgICAgICAgICBcXFxcICAgICB8fCAgICAgICAgfHwgICAgIC8gICAgICAgICAgICAgICAgICAgICAgLyAgIFwiKVxuICAgICAgICBwcmludChcIiAgIFxcXFwgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgICAgfCBcXFxcX19fX19fLyB8ICAgIC8gICAgICAgICAgICAgICAgICAgICAgLyAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgXFxcXCAgICAgICAgICAgICAgICAgICAgICAgXFxcXCAgLyBcXFxcICAgICAgICAvIFxcXFwgIC8gICAgICAgICAgICAgICAgICAgICAgLyAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgIC8gICAgICAgICAgICAgICAgICAgICAgICBcXFxcfCAoKlxcXFwgIFxcXFwvICAvKikgfC8gICAgICAgICAgICAgICAgICAgICAgIFxcXFwgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgIC8gICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgICBcXFxcfCBcXFxcLyB8LyAgIC8gICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgIC8gICAgICAgICAgICAgICAgICAgICAgICAgICAgfCAgIHwgICAgfCAgIHwgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcICAgXCIpXG4gICAgICAgIHByaW50KFwiIC8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHxcXFxcIF9cXFxcX19fXy9fIC98ICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgIFwiKVxuICAgICAgICBwcmludChcIi9fX19fX18gICAgICAgICAgICAgICAgICAgICAgIHwgfCBcXFxcKV9fX18oLyB8IHwgICAgICAgICAgICAgICAgICAgICAgX19fX19fXFxcXCBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgKSAgICAgICAgICAgICAgICAgICAgICB8ICBcXFxcIHwvdnZcXFxcfCAvICB8ICAgICAgICAgICAgICAgICAgICAgKCAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgLyAgICAgICAgICAgICAgICAgICAgICAvICAgIHwgfCAgfCB8ICAgIFxcXFwgICAgICAgICAgICAgICAgICAgICBcXFxcICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgLyAgICAgICAgICAgICAgICAgICAgICAvICAgICB8fFxcXFxeXi98fCAgICAgXFxcXCAgICAgICAgICAgICAgICAgICAgIFxcXFwgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgLyAgICAgICAgICAgICAgICAgICAgICAvICAgICAvIFxcXFw9PT09LyBcXFxcICAgICBcXFxcICAgICAgICAgICAgICAgICAgICAgXFxcXCAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgL19fX19fX18gICAgICAgICAgIF9fX18vICAgICAgXFxcXF9fX19fX19fLyAgICAgIFxcXFxfX19fICAgICAgICAgICBfX19fX19cXFxcICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgKSAgICAgICAgIC8gICB8ICAgICAgIHwgIF9fX18gIHwgICAgICAgfCAgIFxcXFwgICAgICAgICAoICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgIHwgICAgICAgLyAgICAgfCAgICAgICBcXFxcX19fX19fX18vICAgICAgIHwgICAgIFxcXFwgICAgICAgfCAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICB8ICAgICAvICAgICAgIHwgICAgICAgfCAgX19fXyAgfCAgICAgICB8ICAgICAgIFxcXFwgICAgIHwgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgfCAgIC8gICAgICAgICB8ICAgICAgIFxcXFxfX19fX19fXy8gICAgICAgfCAgICAgICAgIFxcXFwgICB8ICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgIHwgLyAgICAgICAgICAgIFxcXFwgICAgICBcXFxcIF9fX19fXyAvICAgICAgL19fX19fXy4uICAgIFxcXFwgfCAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAvICAgICAgICAgICAgICB8ICAgICAgXFxcXFxcXFxfX19fX18vLyAgICAgIHwgICAgICAgIFxcXFwgICAgIFxcXFwgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgfCAgICAgICBcXFxcIF9fX18gLyAgICAgICB8TExMTEwvXyAgXFxcXCAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgIHwgICAgICAvIFxcXFxfX19fLyBcXFxcICAgICAgfCAgICAgIFxcXFwgICB8ICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICB8ICAgICAvIC8gXFxcXF9fLyBcXFxcIFxcXFwgICAgIHwgICAgIF9fXFxcXCAgL19fICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgfCAgICB8IHwgICAgICAgIHwgfCAgICB8ICAgICBcXFxcICAgICAgLyAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgIHwgICAgfCB8ICAgICAgICB8IHwgICAgfCAgICAgIFxcXFwgICAgLyAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICB8ICAgIHwgIFxcXFwgICAgICAvICB8ICAgIHwgICAgICAgXFxcXCAgLyAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgfCAgICAgXFxcXF9fXFxcXCAgICAvX18vICAgICB8ICAgICAgICBcXFxcLyAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgLyAgICBfX19cXFxcICApICAoICAvX19fICAgIFxcXFwgICAgICAgICAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgfC9cXFxcL1xcXFx8ICAgICkgICAgICAoICAgIHwvXFxcXC9cXFxcfCAgICAgICAgICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICggKCAgKSAgICAgICAgICAgICAgICAoICApIClcIilcblxuXG5cblxuXG4gICAgICAgIGlmIChjb3VudCA+IDApIHtcblxuICAgICAgICAgICAgaWYgKG1pc3REcmFnb25BdHRhY2tSYW5kb20gPCAwLjI1KSB7XG5cbiAgICAgICAgICAgICAgICBpZiAobWlzdERyYWdvbkF0dGFja0NoYW5jZSA8IDAuMjUpIHtcblxuICAgICAgICAgICAgICAgICAgICBwbGF5ZXJIZWFsdGggLSAxMTBcblxuICAgICAgICAgICAgICAgICAgICBwcmludChcIlxcbk1pc3QgZHJhZ29uIGhhcyBkZWFsdCAxMTAgZGFtYWdlXCIpXG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB9IGVsc2UgaWYgKG1pc3REcmFnb25BdHRhY2tSYW5kb20gPCAwLjI1KSB7XG4gICAgICAgICAgICAgICAgcHJpbnQoXCJcXG5NaXN0IERyYWdvbiBNaXNzZWRcIilcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKG1pc3REcmFnb25BdHRhY2tSYW5kb20gPiAwLjI1ICYmIG1pc3REcmFnb25BdHRhY2tSYW5kb20gPCAwLjQ1ICYmIG1pc3REcmFnb25IZWFsdGggPCA2MDApIHtcblxuICAgICAgICAgICAgICAgIG1pc3REcmFnb25IZWFsdGggPSBtaXN0RHJhZ29uSGVhbHRoICsgNTU7XG5cbiAgICAgICAgICAgICAgICBwcmludChcIlxcbk1pc3QgRHJhZ29uIGhhcyBoZWFsZWQgNTUgaGVhbHRoXCIpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChtaXN0RHJhZ29uQXR0YWNrUmFuZG9tID4gMC4yNSkge1xuXG4gICAgICAgICAgICAgICAgcGxheWVySGVhbHRoID0gcGxheWVySGVhbHRoIC0gMzU7XG5cbiAgICAgICAgICAgICAgICBwcmludChcIk1pc3QgRHJhZ29uIGhhcyBkZWFsdCAzNSBkYW1hZ2VcIilcblxuICAgICAgICAgICAgfVxuXG4gICAgICAgIH1cblxuXG4gICAgICAgIHByaW50KFwiXFxuXFxufHxZb3VyIGhlYWx0aCBpc1wiLCBwbGF5ZXJIZWFsdGggKyBcInx8XCIpXG5cblxuICAgICAgICBwcmludChcIlxcblxcbnx8IE1pc3QgRHJhZ29uIEhlYWx0aCBpc1wiLCBtaXN0RHJhZ29uSGVhbHRoICsgXCJ8fFwiKTtcblxuICAgICAgICBwcmludChcIlxcblxcbigxKSBOb3JtYWwgYXR0YWNrIDc1JSBjaGFuY2UgaXQgaGl0cyBhbmQgaXQgZGVhbHNcIiwgbm9ybWFsQXR0YWNrKVxuICAgICAgICBwcmludChcIlxcbigyKSBTdHJvbmcgYXR0YWNrOiA0NSUgY2hhbmNlIG9mIGhpdHRpbmcgYW5kIGRlYWxzXCIsIHN0cm9uZ0F0dGFjaylcbiAgICAgICAgcHJpbnQoXCJcXG4oMykgSGVhbDogSGVhbHNcIiwgaGVhbCwgXCJvZiBoZWFsdGggXCIpXG5cbiAgICAgICAgY291bnQgPSBjb3VudCArIDFcblxuICAgICAgICBpbnB1dCA9IGdldElucHV0KCk7XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMVwiKSB7XG4gICAgICAgICAgICBwbGF5ZXJBdHRhY2tSYW5kb20gPSBNYXRoLnJhbmRvbSgpO1xuICAgICAgICAgICAgaWYgKHBsYXllckF0dGFja1JhbmRvbSA8PSAwLjc1KSB7XG4gICAgICAgICAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG5Zb3UgZGVhbHRcIiwgbm9ybWFsQXR0YWNrLCBcImRhbWFnZSB0byB0aGUgdGhlIE1pc3QgRHJhZ29uXCIpXG4gICAgICAgICAgICAgICAgbWlzdERyYWdvbkhlYWx0aCA9IG1pc3REcmFnb25IZWFsdGggLSBub3JtYWxBdHRhY2s7XG4gICAgICAgICAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApXG5cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG5Zb3UgbWlzc2VkIHRoZSBhdHRhY2tcIilcbiAgICAgICAgICAgICAgICBGdW4udGhyZWFkU2xlZXAoMTAwMClcblxuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjJcIikge1xuICAgICAgICAgICAgcGxheWVyQXR0YWNrUmFuZG9tID0gTWF0aC5yYW5kb20oKTtcbiAgICAgICAgICAgIGlmIChwbGF5ZXJBdHRhY2tSYW5kb20gPD0gMC40NSkge1xuICAgICAgICAgICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxueW91IGRlYWx0XCIsIHN0cm9uZ0F0dGFjaywgXCJkYW1hZ2UgdG8gdGhlIE1pc3QgRHJhZ29uXCIpXG4gICAgICAgICAgICAgICAgbWlzdERyYWdvbkhlYWx0aCA9IG1pc3REcmFnb25IZWFsdGggLSBzdHJvbmdBdHRhY2s7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxuWW91IG1pc3NlZCB0aGUgYXR0YWNrXCIpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBGdW4udGhyZWFkU2xlZXAoMTAwMClcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjNcIikge1xuICAgICAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG55b3UgaGVhbGVkXCIsIGhlYWwsIFwiaGVhbHRoXCIpXG4gICAgICAgICAgICBwbGF5ZXJIZWFsdGggPSBwbGF5ZXJIZWFsdGggKyBoZWFsO1xuICAgICAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApXG4gICAgICAgIH1cblxuICAgIH1cblxuXG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWlzdCBEcmFnb24gQm9zc1wiICYmIHBsYXllckhlYWx0aCA8IDEpIHtcbiAgICAgICAgcHJpbnQoXCJcXG5cXG5fXyAgIF9fICAgICAgICAgICBfX19fX18gXyAgICAgICAgICBfXCIpXG4gICAgICAgIHByaW50KFwiXFxcXCBcXFxcIC8gLyAgICAgICAgICAgfCAgXyAgKF8pICAgICAgICB8IHxcIilcbiAgICAgICAgcHJpbnQoXCIgXFxcXCBWIC9fX18gIF8gICBfICB8IHwgfCB8XyAgX19fICBfX3wgfFwiKVxuICAgICAgICBwcmludChcIiAgXFxcXCAvLyBfIFxcXFx8IHwgfCB8IHwgfCB8IHwgfC8gXyBcXFxcLyBfYCB8XCIpXG4gICAgICAgIHByaW50KFwiICB8IHwgKF8pIHwgfF98IHwgfCB8LyAvfCB8ICBfXy8gKF98IHxcIilcbiAgICAgICAgcHJpbnQoXCIgIFxcXFxfL1xcXFxfX18vIFxcXFxfXyxffCB8X19fLyB8X3xcXFxcX19ffFxcXFxfXyxffFwiKVxuICAgICAgICBnYW1lT3ZlciA9IHRydWVcbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWlzdCBEcmFnb24gQm9zc1wiICYmIG1pc3REcmFnb25IZWFsdGggPCAxKSB7XG5cblxuXG4gICAgICAgIHNjcmVlbiA9IFwiRW5kaW5nXCJcblxuICAgIH1cblxuXG5cblxuICAgIGlmIChzY3JlZW4gPT0gXCJFbmRpbmdcIikge1xuXG5cblxuICAgICAgICBsZXQgc3RvcEFtb3VudCA9IDUwMFxuXG4gICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX18gICBfXyAgIF9fXyAgICBfICAgXyAgICAgICAgICBfXyAgICAgIF9fIF9fXyAgICBfICBfICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcIFxcXFwgLyAvICAvIF8gXFxcXCAgfCB8IHwgfCAgICBvIE8gT1xcXFwgXFxcXCAgICAvIC98XyBffCAgfCBcXFxcfCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgViAvICB8IChfKSB8IHwgfF98IHwgICBvICAgICAgXFxcXCBcXFxcL1xcXFwvIC8gIHwgfCAgIHwgLmAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffF98XyAgIFxcXFxfX18vICAgXFxcXF9fXy8gICBUU19fW09dICBcXFxcXy9cXFxcXy8gIHxfX198ICB8X3xcXFxcX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98IC0tLSB8X3wtLS0tLXxffC0tLS0tfCB7PT09PT09fF98LS0tLS18X3wtLS0tLXxffC0tLS0tfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nLi9vLS0wMDAnLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nXCIpXG5cbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKHN0b3BBbW91bnQpXG4gICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9fICAgX18gICBfX18gICAgXyAgIF8gICAgICAgICAgX18gICAgICBfXyBfX18gICAgXyAgXyAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcIFxcXFwgLyAvICAvIF8gXFxcXCAgfCB8IHwgfCAgICBvIE8gT1xcXFwgXFxcXCAgICAvIC98XyBffCAgfCBcXFxcfCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBWIC8gIHwgKF8pIHwgfCB8X3wgfCAgIG8gICAgICBcXFxcIFxcXFwvXFxcXC8gLyAgfCB8ICAgfCAuYCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3xffF8gICBcXFxcX19fLyAgIFxcXFxfX18vICAgVFNfX1tPXSAgXFxcXF8vXFxcXF8vICB8X19ffCAgfF98XFxcXF98XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98IC0tLSB8X3wtLS0tLXxffC0tLS0tfCB7PT09PT09fF98LS0tLS18X3wtLS0tLXxffC0tLS0tfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAtYC0wLTAtJy1gLTAtMC0nLWAtMC0wLScuL28tLTAwMCctYC0wLTAtJy1gLTAtMC0nLWAtMC0wLSdcIilcbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKHN0b3BBbW91bnQpXG4gICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX18gICBfXyAgIF9fXyAgICBfICAgXyAgICAgICAgICBfXyAgICAgIF9fIF9fXyAgICBfICBfICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBcXFxcIC8gLyAgLyBfIFxcXFwgIHwgfCB8IHwgICAgbyBPIE9cXFxcIFxcXFwgICAgLyAvfF8gX3wgIHwgXFxcXHwgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBWIC8gIHwgKF8pIHwgfCB8X3wgfCAgIG8gICAgICBcXFxcIFxcXFwvXFxcXC8gLyAgfCB8ICAgfCAuYCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffF98XyAgIFxcXFxfX18vICAgXFxcXF9fXy8gICBUU19fW09dICBcXFxcXy9cXFxcXy8gIHxfX198ICB8X3xcXFxcX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffCAtLS0gfF98LS0tLS18X3wtLS0tLXwgez09PT09PXxffC0tLS0tfF98LS0tLS18X3wtLS0tLXxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAtYC0wLTAtJy1gLTAtMC0nLWAtMC0wLScuL28tLTAwMCctYC0wLTAtJy1gLTAtMC0nLWAtMC0wLSdcIilcbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKHN0b3BBbW91bnQpXG4gICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX18gICBfXyAgIF9fXyAgICBfICAgXyAgICAgICAgICBfXyAgICAgIF9fIF9fXyAgICBfICBfICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgXFxcXCAvIC8gIC8gXyBcXFxcICB8IHwgfCB8ICAgIG8gTyBPXFxcXCBcXFxcICAgIC8gL3xfIF98ICB8IFxcXFx8IHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcIFYgLyAgfCAoXykgfCB8IHxffCB8ICAgbyAgICAgIFxcXFwgXFxcXC9cXFxcLyAvICB8IHwgICB8IC5gIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffF98XyAgIFxcXFxfX18vICAgXFxcXF9fXy8gICBUU19fW09dICBcXFxcXy9cXFxcXy8gIHxfX198ICB8X3xcXFxcX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3wgLS0tIHxffC0tLS0tfF98LS0tLS18IHs9PT09PT18X3wtLS0tLXxffC0tLS0tfF98LS0tLS18XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJy4vby0tMDAwJy1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJ1wiKVxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoc3RvcEFtb3VudClcbiAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX18gICBfXyAgIF9fXyAgICBfICAgXyAgICAgICAgICBfXyAgICAgIF9fIF9fXyAgICBfICBfICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcIFxcXFwgLyAvICAvIF8gXFxcXCAgfCB8IHwgfCAgICBvIE8gT1xcXFwgXFxcXCAgICAvIC98XyBffCAgfCBcXFxcfCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgViAvICB8IChfKSB8IHwgfF98IHwgICBvICAgICAgXFxcXCBcXFxcL1xcXFwvIC8gIHwgfCAgIHwgLmAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffF98XyAgIFxcXFxfX18vICAgXFxcXF9fXy8gICBUU19fW09dICBcXFxcXy9cXFxcXy8gIHxfX198ICB8X3xcXFxcX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98IC0tLSB8X3wtLS0tLXxffC0tLS0tfCB7PT09PT09fF98LS0tLS18X3wtLS0tLXxffC0tLS0tfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nLi9vLS0wMDAnLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nXCIpXG4gICAgICAgIEZ1bi50aHJlYWRTbGVlcChzdG9wQW1vdW50KVxuICAgICAgICBwcmludChcIlxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX18gICBfXyAgIF9fXyAgICBfICAgXyAgICAgICAgICBfXyAgICAgIF9fIF9fXyAgICBfICBfICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBcXFxcIC8gLyAgLyBfIFxcXFwgIHwgfCB8IHwgICAgbyBPIE9cXFxcIFxcXFwgICAgLyAvfF8gX3wgIHwgXFxcXHwgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBWIC8gIHwgKF8pIHwgfCB8X3wgfCAgIG8gICAgICBcXFxcIFxcXFwvXFxcXC8gLyAgfCB8ICAgfCAuYCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffF98XyAgIFxcXFxfX18vICAgXFxcXF9fXy8gICBUU19fW09dICBcXFxcXy9cXFxcXy8gIHxfX198ICB8X3xcXFxcX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffCAtLS0gfF98LS0tLS18X3wtLS0tLXwgez09PT09PXxffC0tLS0tfF98LS0tLS18X3wtLS0tLXxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAtYC0wLTAtJy1gLTAtMC0nLWAtMC0wLScuL28tLTAwMCctYC0wLTAtJy1gLTAtMC0nLWAtMC0wLSdcIilcbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKHN0b3BBbW91bnQpXG4gICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX18gICBfXyAgIF9fXyAgICBfICAgXyAgICAgICAgICBfXyAgICAgIF9fIF9fXyAgICBfICBfICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgXFxcXCAvIC8gIC8gXyBcXFxcICB8IHwgfCB8ICAgIG8gTyBPXFxcXCBcXFxcICAgIC8gL3xfIF98ICB8IFxcXFx8IHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcIFYgLyAgfCAoXykgfCB8IHxffCB8ICAgbyAgICAgIFxcXFwgXFxcXC9cXFxcLyAvICB8IHwgICB8IC5gIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffF98XyAgIFxcXFxfX18vICAgXFxcXF9fXy8gICBUU19fW09dICBcXFxcXy9cXFxcXy8gIHxfX198ICB8X3xcXFxcX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98IC0tLSB8X3wtLS0tLXxffC0tLS0tfCB7PT09PT09fF98LS0tLS18X3wtLS0tLXxffC0tLS0tfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nLi9vLS0wMDAnLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nXCIpXG4gICAgICAgIEZ1bi50aHJlYWRTbGVlcChzdG9wQW1vdW50KVxuICAgICAgICBwcmludChcIlxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfXyAgIF9fICAgX19fICAgIF8gICBfICAgICAgICAgIF9fICAgICAgX18gX19fICAgIF8gIF8gIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgXFxcXCAvIC8gIC8gXyBcXFxcICB8IHwgfCB8ICAgIG8gTyBPXFxcXCBcXFxcICAgIC8gL3xfIF98ICB8IFxcXFx8IHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBWIC8gIHwgKF8pIHwgfCB8X3wgfCAgIG8gICAgICBcXFxcIFxcXFwvXFxcXC8gLyAgfCB8ICAgfCAuYCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98X3xfICAgXFxcXF9fXy8gICBcXFxcX19fLyAgIFRTX19bT10gIFxcXFxfL1xcXFxfLyAgfF9fX3wgIHxffFxcXFxffFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3wgLS0tIHxffC0tLS0tfF98LS0tLS18IHs9PT09PT18X3wtLS0tLXxffC0tLS0tfF98LS0tLS18XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAtYC0wLTAtJy1gLTAtMC0nLWAtMC0wLScuL28tLTAwMCctYC0wLTAtJy1gLTAtMC0nLWAtMC0wLSdcIilcbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKHN0b3BBbW91bnQpXG4gICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfXyAgIF9fICAgX19fICAgIF8gICBfICAgICAgICAgIF9fICAgICAgX18gX19fICAgIF8gIF8gIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcIFxcXFwgLyAvICAvIF8gXFxcXCAgfCB8IHwgfCAgICBvIE8gT1xcXFwgXFxcXCAgICAvIC98XyBffCAgfCBcXFxcfCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcIFYgLyAgfCAoXykgfCB8IHxffCB8ICAgbyAgICAgIFxcXFwgXFxcXC9cXFxcLyAvICB8IHwgICB8IC5gIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98X3xfICAgXFxcXF9fXy8gICBcXFxcX19fLyAgIFRTX19bT10gIFxcXFxfL1xcXFxfLyAgfF9fX3wgIHxffFxcXFxffFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98IC0tLSB8X3wtLS0tLXxffC0tLS0tfCB7PT09PT09fF98LS0tLS18X3wtLS0tLXxffC0tLS0tfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJy4vby0tMDAwJy1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJ1wiKVxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoc3RvcEFtb3VudClcbiAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfXyAgIF9fICAgX19fICAgIF8gICBfICAgICAgICAgIF9fICAgICAgX18gX19fICAgIF8gIF8gIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBcXFxcIC8gLyAgLyBfIFxcXFwgIHwgfCB8IHwgICAgbyBPIE9cXFxcIFxcXFwgICAgLyAvfF8gX3wgIHwgXFxcXHwgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgViAvICB8IChfKSB8IHwgfF98IHwgICBvICAgICAgXFxcXCBcXFxcL1xcXFwvIC8gIHwgfCAgIHwgLmAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98X3xfICAgXFxcXF9fXy8gICBcXFxcX19fLyAgIFRTX19bT10gIFxcXFxfL1xcXFxfLyAgfF9fX3wgIHxffFxcXFxffFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffCAtLS0gfF98LS0tLS18X3wtLS0tLXwgez09PT09PXxffC0tLS0tfF98LS0tLS18X3wtLS0tLXxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nLi9vLS0wMDAnLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nXCIpXG4gICAgICAgIEZ1bi50aHJlYWRTbGVlcChzdG9wQW1vdW50KVxuICAgICAgICBwcmludChcIlxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfXyAgIF9fICAgX19fICAgIF8gICBfICAgICAgICAgIF9fICAgICAgX18gX19fICAgIF8gIF8gIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgXFxcXCAvIC8gIC8gXyBcXFxcICB8IHwgfCB8ICAgIG8gTyBPXFxcXCBcXFxcICAgIC8gL3xfIF98ICB8IFxcXFx8IHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBWIC8gIHwgKF8pIHwgfCB8X3wgfCAgIG8gICAgICBcXFxcIFxcXFwvXFxcXC8gLyAgfCB8ICAgfCAuYCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98X3xfICAgXFxcXF9fXy8gICBcXFxcX19fLyAgIFRTX19bT10gIFxcXFxfL1xcXFxfLyAgfF9fX3wgIHxffFxcXFxffFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3wgLS0tIHxffC0tLS0tfF98LS0tLS18IHs9PT09PT18X3wtLS0tLXxffC0tLS0tfF98LS0tLS18XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAtYC0wLTAtJy1gLTAtMC0nLWAtMC0wLScuL28tLTAwMCctYC0wLTAtJy1gLTAtMC0nLWAtMC0wLSdcIilcbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKHN0b3BBbW91bnQpXG4gICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX18gICBfXyAgIF9fXyAgICBfICAgXyAgICAgICAgICBfXyAgICAgIF9fIF9fXyAgICBfICBfICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgXFxcXCAvIC8gIC8gXyBcXFxcICB8IHwgfCB8ICAgIG8gTyBPXFxcXCBcXFxcICAgIC8gL3xfIF98ICB8IFxcXFx8IHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcIFYgLyAgfCAoXykgfCB8IHxffCB8ICAgbyAgICAgIFxcXFwgXFxcXC9cXFxcLyAvICB8IHwgICB8IC5gIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffF98XyAgIFxcXFxfX18vICAgXFxcXF9fXy8gICBUU19fW09dICBcXFxcXy9cXFxcXy8gIHxfX198ICB8X3xcXFxcX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3wgLS0tIHxffC0tLS0tfF98LS0tLS18IHs9PT09PT18X3wtLS0tLXxffC0tLS0tfF98LS0tLS18XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJy4vby0tMDAwJy1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJ1wiKVxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoc3RvcEFtb3VudClcbiAgICAgICAgcHJpbnQoXCIgXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9fICAgX18gICBfX18gICAgXyAgIF8gICAgICAgICAgX18gICAgICBfXyBfX18gICAgXyAgXyAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgXFxcXCAvIC8gIC8gXyBcXFxcICB8IHwgfCB8ICAgIG8gTyBPXFxcXCBcXFxcICAgIC8gL3xfIF98ICB8IFxcXFx8IHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgViAvICB8IChfKSB8IHwgfF98IHwgICBvICAgICAgXFxcXCBcXFxcL1xcXFwvIC8gIHwgfCAgIHwgLmAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3xffF8gICBcXFxcX19fLyAgIFxcXFxfX18vICAgVFNfX1tPXSAgXFxcXF8vXFxcXF8vICB8X19ffCAgfF98XFxcXF98XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3wgLS0tIHxffC0tLS0tfF98LS0tLS18IHs9PT09PT18X3wtLS0tLXxffC0tLS0tfF98LS0tLS18XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nLi9vLS0wMDAnLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nXCIpXG5cbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKHN0b3BBbW91bnQpXG4gICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9fICAgX18gICBfX18gICAgXyAgIF8gICAgICAgICAgX18gICAgICBfXyBfX18gICAgXyAgXyAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBcXFxcIC8gLyAgLyBfIFxcXFwgIHwgfCB8IHwgICAgbyBPIE9cXFxcIFxcXFwgICAgLyAvfF8gX3wgIHwgXFxcXHwgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcIFYgLyAgfCAoXykgfCB8IHxffCB8ICAgbyAgICAgIFxcXFwgXFxcXC9cXFxcLyAvICB8IHwgICB8IC5gIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3xffF8gICBcXFxcX19fLyAgIFxcXFxfX18vICAgVFNfX1tPXSAgXFxcXF8vXFxcXF8vICB8X19ffCAgfF98XFxcXF98XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffCAtLS0gfF98LS0tLS18X3wtLS0tLXwgez09PT09PXxffC0tLS0tfF98LS0tLS18X3wtLS0tLXxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJy4vby0tMDAwJy1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJ1wiKVxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoc3RvcEFtb3VudClcbiAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfXyAgIF9fICAgX19fICAgIF8gICBfICAgICAgICAgIF9fICAgICAgX18gX19fICAgIF8gIF8gIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBcXFxcIC8gLyAgLyBfIFxcXFwgIHwgfCB8IHwgICAgbyBPIE9cXFxcIFxcXFwgICAgLyAvfF8gX3wgIHwgXFxcXHwgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgViAvICB8IChfKSB8IHwgfF98IHwgICBvICAgICAgXFxcXCBcXFxcL1xcXFwvIC8gIHwgfCAgIHwgLmAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98X3xfICAgXFxcXF9fXy8gICBcXFxcX19fLyAgIFRTX19bT10gIFxcXFxfL1xcXFxfLyAgfF9fX3wgIHxffFxcXFxffFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffCAtLS0gfF98LS0tLS18X3wtLS0tLXwgez09PT09PXxffC0tLS0tfF98LS0tLS18X3wtLS0tLXxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nLi9vLS0wMDAnLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nXCIpXG4gICAgICAgIEZ1bi50aHJlYWRTbGVlcChzdG9wQW1vdW50KVxuICAgICAgICBwcmludChcIlxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX18gICBfXyAgIF9fXyAgICBfICAgXyAgICAgICAgICBfXyAgICAgIF9fIF9fXyAgICBfICBfICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBcXFxcIC8gLyAgLyBfIFxcXFwgIHwgfCB8IHwgICAgbyBPIE9cXFxcIFxcXFwgICAgLyAvfF8gX3wgIHwgXFxcXHwgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBWIC8gIHwgKF8pIHwgfCB8X3wgfCAgIG8gICAgICBcXFxcIFxcXFwvXFxcXC8gLyAgfCB8ICAgfCAuYCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffF98XyAgIFxcXFxfX18vICAgXFxcXF9fXy8gICBUU19fW09dICBcXFxcXy9cXFxcXy8gIHxfX198ICB8X3xcXFxcX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffCAtLS0gfF98LS0tLS18X3wtLS0tLXwgez09PT09PXxffC0tLS0tfF98LS0tLS18X3wtLS0tLXxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAtYC0wLTAtJy1gLTAtMC0nLWAtMC0wLScuL28tLTAwMCctYC0wLTAtJy1gLTAtMC0nLWAtMC0wLSdcIilcbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKHN0b3BBbW91bnQpXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX18gICBfXyAgIF9fXyAgICBfICAgXyAgICAgICAgICBfXyAgICAgIF9fIF9fXyAgICBfICBfICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcIFxcXFwgLyAvICAvIF8gXFxcXCAgfCB8IHwgfCAgICBvIE8gT1xcXFwgXFxcXCAgICAvIC98XyBffCAgfCBcXFxcfCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgViAvICB8IChfKSB8IHwgfF98IHwgICBvICAgICAgXFxcXCBcXFxcL1xcXFwvIC8gIHwgfCAgIHwgLmAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffF98XyAgIFxcXFxfX18vICAgXFxcXF9fXy8gICBUU19fW09dICBcXFxcXy9cXFxcXy8gIHxfX198ICB8X3xcXFxcX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98IC0tLSB8X3wtLS0tLXxffC0tLS0tfCB7PT09PT09fF98LS0tLS18X3wtLS0tLXxffC0tLS0tfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nLi9vLS0wMDAnLWAtMC0wLSctYC0wLTAtJy1gLTAtMC0nXCIpXG5cbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKHN0b3BBbW91bnQpXG4gICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX18gICBfXyAgIF9fXyAgICBfICAgXyAgICAgICAgICBfXyAgICAgIF9fIF9fXyAgICBfICBfICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgXFxcXCAvIC8gIC8gXyBcXFxcICB8IHwgfCB8ICAgIG8gTyBPXFxcXCBcXFxcICAgIC8gL3xfIF98ICB8IFxcXFx8IHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcXFxcIFYgLyAgfCAoXykgfCB8IHxffCB8ICAgbyAgICAgIFxcXFwgXFxcXC9cXFxcLyAvICB8IHwgICB8IC5gIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBffF98XyAgIFxcXFxfX18vICAgXFxcXF9fXy8gICBUU19fW09dICBcXFxcXy9cXFxcXy8gIHxfX198ICB8X3xcXFxcX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3wgLS0tIHxffC0tLS0tfF98LS0tLS18IHs9PT09PT18X3wtLS0tLXxffC0tLS0tfF98LS0tLS18XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJy4vby0tMDAwJy1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJ1wiKVxuXG4gICAgICAgIEZ1bi50aHJlYWRTbGVlcChzdG9wQW1vdW50KVxuICAgICAgICBwcmludChcIlxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfXyAgIF9fICAgX19fICAgIF8gICBfICAgICAgICAgIF9fICAgICAgX18gX19fICAgIF8gIF8gIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgXFxcXCAvIC8gIC8gXyBcXFxcICB8IHwgfCB8ICAgIG8gTyBPXFxcXCBcXFxcICAgIC8gL3xfIF98ICB8IFxcXFx8IHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBWIC8gIHwgKF8pIHwgfCB8X3wgfCAgIG8gICAgICBcXFxcIFxcXFwvXFxcXC8gLyAgfCB8ICAgfCAuYCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF98X3xfICAgXFxcXF9fXy8gICBcXFxcX19fLyAgIFRTX19bT10gIFxcXFxfL1xcXFxfLyAgfF9fX3wgIHxffFxcXFxffFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3wgLS0tIHxffC0tLS0tfF98LS0tLS18IHs9PT09PT18X3wtLS0tLXxffC0tLS0tfF98LS0tLS18XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAtYC0wLTAtJy1gLTAtMC0nLWAtMC0wLScuL28tLTAwMCctYC0wLTAtJy1gLTAtMC0nLWAtMC0wLSdcIilcblxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoc3RvcEFtb3VudClcbiAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9fICAgX18gICBfX18gICAgXyAgIF8gICAgICAgICAgX18gICAgICBfXyBfX18gICAgXyAgXyAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgXFxcXCAvIC8gIC8gXyBcXFxcICB8IHwgfCB8ICAgIG8gTyBPXFxcXCBcXFxcICAgIC8gL3xfIF98ICB8IFxcXFx8IHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXFwgViAvICB8IChfKSB8IHwgfF98IHwgICBvICAgICAgXFxcXCBcXFxcL1xcXFwvIC8gIHwgfCAgIHwgLmAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3xffF8gICBcXFxcX19fLyAgIFxcXFxfX18vICAgVFNfX1tPXSAgXFxcXF8vXFxcXF8vICB8X19ffCAgfF98XFxcXF98XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3wgLS0tIHxffC0tLS0tfF98LS0tLS18IHs9PT09PT18X3wtLS0tLXxffC0tLS0tfF98LS0tLS18XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAtYC0wLTAtJy1gLTAtMC0nLWAtMC0wLScuL28tLTAwMCctYC0wLTAtJy1gLTAtMC0nLWAtMC0wLSdcIilcblxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoc3RvcEFtb3VudClcblxuICAgICAgICBwcmludChcIlxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcblxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgX18gICBfXyAgIF9fXyAgICBfICAgXyAgICAgICAgICBfXyAgICAgIF9fIF9fXyAgICBfICBfICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBcXFxcIC8gLyAgLyBfIFxcXFwgIHwgfCB8IHwgICAgbyBPIE9cXFxcIFxcXFwgICAgLyAvfF8gX3wgIHwgXFxcXHwgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcXCBWIC8gIHwgKF8pIHwgfCB8X3wgfCAgIG8gICAgICBcXFxcIFxcXFwvXFxcXC8gLyAgfCB8ICAgfCAuYCB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICBffF98XyAgIFxcXFxfX18vICAgXFxcXF9fXy8gICBUU19fW09dICBcXFxcXy9cXFxcXy8gIHxfX198ICB8X3xcXFxcX3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICBffCAtLS0gfF98LS0tLS18X3wtLS0tLXwgez09PT09PXxffC0tLS0tfF98LS0tLS18X3wtLS0tLXxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgIC1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJy4vby0tMDAwJy1gLTAtMC0nLWAtMC0wLSctYC0wLTAtJ1wiKVxuXG4gICAgICAgIGdhbWVPdmVyID0gdHJ1ZVxuICAgIH1cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG4gICAgLy9zaG9wXG5cblxuXG5cbiAgICBpZiAoc2NyZWVuID09IFwic2hvcFwiKSB7XG5cblxuICAgICAgICBwcmludChcIlxcbiAgICAgICAgICAgICAgICBfX19fX19fX19fX19fX1wiKVxuICAgICAgICBwcmludChcIiAgICBfXywuLC0tLScnJycnICAgICAgICAgICAgICAnJycnJy0tLS4uLl9cIilcbiAgICAgICAgcHJpbnQoXCIgLC0nICAgICAgICAgICAgIC4uLi4uOjo6Jyc6Oi46ICAgICAgICAgICAgJ2AtLlwiKVxuICAgICAgICBwcmludChcIicgICAgICAgICAgIC4uLjo6Oi4uLi4uICAgICAgICdcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAnJyc6OjonJycnJyAgICAgICAuICAgICAgICAgICAgICAgLFwiKVxuICAgICAgICBwcmludChcInwnLS4uXyAgICAgICAgICAgJycnJyc6OjouLjo6JzogICAgICAgICAgX18sLC1cIilcbiAgICAgICAgcHJpbnQoXCIgJy0uLl8nJ2AtLS0uLi4uLl9fX19fX19fX19fX19fLi4uLi4tLS0nJ19fLCwtXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgJydgLS0tLi4uLi5fX19fX19fX19fX19fXy4uLi4uLS0tJydcIilcblxuICAgICAgICBwcmludChcIlxcblxcblxcbkhleVwiLCBwbGF5ZXJOYW1lLCBcIldoYXQgZG8geW91IHdhbnQgZG8/XCIpXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG5TdHJlbmd0aDpcIiwgc3RyZW5ndGgsIFwiXFxuTWF4IEhlYWx0aDpcIiwgbWF4UGxheWVySGVhbHRoLCBcIlxcbllvdSBoYXZlXCIsIGNvaW5zLCBcImNvaW5zXCIsIFwiXFxuXFxuKDEpIFVwZ3JhZGUgc3RyZW5ndGggQ09TVFM6IFwiLCBzdG9yZUNvc3RTdHJlbmd0aCwgXCJcXG4oMikgVXBncmFkZSBoZWFsdGggQ09TVFM6IFwiLCBzdG9yZUNvc3RIZWFsdGgsIFwiXFxuKDMpUmVzZXQgTWlzdHkgc3RyZW5ndGggQ09TVFM6XCIsIG1pc3R5U3RyZW5ndGgsIFwiXFxuKDQpIEdvIGJhY2tcIilcblxuICAgICAgICBpbnB1dCA9IGdldElucHV0KCk7XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMVwiKSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiVXBncmFkZSBTdHJlbmd0aFwiO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMlwiKSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiVXBncmFkZSBIZWFsdGhcIjtcblxuXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIzXCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID0gXCJSZXNldCBNaXN0eSBTdHJlbmd0aFwiXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCI0XCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID0gXCJNYWluIGh1YlwiO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHNjcmVlbiA9PSBcIlJlc2V0IE1pc3R5IFN0cmVuZ3RoXCIgJiYgY29pbnMgPj0gbWlzdHlTdHJlbmd0aCkge1xuXG4gICAgICAgIHByaW50KFwiXFxuQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIHJlc2V0IE1pc3R5IHN0cmVuZ3RoIGxldmVsP1xcbiBUaGlzIHdpbGwgcmVzdWx0IGluIGxvd2VyIGxldmVsZWQgZW5lbWllcyB0aGF0IGdpdmUgbG93IGFtb3VudHMgb2YgY29pbnMuXCIpXG5cbiAgICAgICAgcHJpbnQoXCJcXG4oMSlZZXNcXG4oMilObyBnbyBiYWNrXCIpXG5cbiAgICAgICAgaW5wdXQgPSBnZXRJbnB1dCgpO1xuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjFcIikge1xuXG4gICAgICAgICAgICBwcmludChcIk1pc3R5IFN0cmVuZ3RoIGxldmVsIGhhdmUgYmVlbiByZXNldHRlZFwiKVxuXG4gICAgICAgICAgICBtaXN0eVN0cmVuZ3RoID0gNzVcblxuICAgICAgICAgICAgY29pbnMgPSBjb2lucyAtIG1pc3R5U3RyZW5ndGhcblxuICAgICAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApXG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwic2hvcFwiXG4gICAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHNjcmVlbiA9PSBcIlJlc2V0IE1pc3R5IFN0cmVuZ3RoXCIgJiYgY29pbnMgPCBtaXN0eVN0cmVuZ3RoKSB7XG5cbiAgICAgICAgcHJpbnQoXCJZb3UgZG9uJ3QgaGF2ZSBlbm91Z2ggY29pbnNcIilcblxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoMTAwMClcblxuICAgICAgICBzY3JlZW4gPSBcInNob3BcIlxuICAgIH1cblxuICAgIGlmIChzY3JlZW4gPT0gXCJVcGdyYWRlIFN0cmVuZ3RoXCIgJiYgY29pbnMgPj0gc3RvcmVDb3N0U3RyZW5ndGgpIHtcblxuICAgICAgICBjb2lucyA9IGNvaW5zIC0gc3RvcmVDb3N0U3RyZW5ndGg7XG4gICAgICAgIHN0cmVuZ3RoID0gc3RyZW5ndGggKyAyNVxuICAgICAgICBzdG9yZUNvc3RTdHJlbmd0aCA9IHN0b3JlQ29zdFN0cmVuZ3RoICsgMzVcblxuICAgICAgICBwcmludChcIlxcblxcbllvdXIgc3RyZW5ndGggaXMgbm93XCIsIHN0cmVuZ3RoKVxuICAgICAgICBwcmludChcIllvdSBoYXZlXCIsIGNvaW5zLCBcImNvaW5zXCIpXG5cbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApXG5cbiAgICAgICAgc2NyZWVuID0gXCJzaG9wXCJcblxuICAgIH0gZWxzZSBpZiAoc2NyZWVuID09IFwiVXBncmFkZSBTdHJlbmd0aFwiICYmIGNvaW5zIDwgc3RvcmVDb3N0U3RyZW5ndGgpIHtcblxuICAgICAgICBwcmludChcIlxcblxcbllvdSBkb24ndCBoYXZlIGVub3VnaCBjb2luc1wiKVxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoMTAwMClcblxuICAgICAgICBzY3JlZW4gPSBcInNob3BcIlxuICAgIH1cblxuICAgIGlmIChzY3JlZW4gPT0gXCJVcGdyYWRlIEhlYWx0aFwiICYmIGNvaW5zID49IHN0b3JlQ29zdEhlYWx0aCkge1xuXG4gICAgICAgIGNvaW5zID0gY29pbnMgLSBzdG9yZUNvc3RIZWFsdGg7XG4gICAgICAgIG1heFBsYXllckhlYWx0aCA9IG1heFBsYXllckhlYWx0aCArIDI1XG4gICAgICAgIHN0b3JlQ29zdEhlYWx0aCA9IHN0b3JlQ29zdEhlYWx0aCArIDI1XG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG5Zb3VyIG1heCBoZWFsdGggaXMgbm93XCIsIHN0b3JlQ29zdEhlYWx0aClcbiAgICAgICAgcHJpbnQoXCJZb3UgaGF2ZVwiLCBjb2lucywgXCJjb2luc1wiKVxuXG4gICAgICAgIEZ1bi50aHJlYWRTbGVlcCgxMDAwKVxuXG4gICAgICAgIHNjcmVlbiA9IFwic2hvcFwiXG5cbiAgICB9IGVsc2UgaWYgKHNjcmVlbiA9PSBcIlVwZ3JhZGUgSGVhbHRoXCIgJiYgY29pbnMgPCBzdG9yZUNvc3RIZWFsdGgpIHtcblxuICAgICAgICBwcmludChcIlxcblxcbllvdSBkb24ndCBoYXZlIGVub3VnaCBjb2luc1wiKVxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoMTAwMClcblxuICAgICAgICBzY3JlZW4gPSBcInNob3BcIlxuICAgIH1cblxuXG5cblxuXG5cbiAgICAvL01pc3R5IEZvcmVzdFxuXG5cblxuXG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWlzdHkgRm9yZXN0IEVudHJhbmNlXCIpIHtcblxuXG4gICAgICAgIHByaW50KFwiICBfX19fX18gX19fX19fIF9fX19fXyBfX19fX18gX19fX19fIF9fX19fXyBfX19fX18gX19fX19fICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHxfX19fX198X19fX19ffF9fX19fX3xfX19fX198X19fX19ffF9fX19fX3xfX19fX198X19fX19ffCAgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfCAgXFxcXC8gIChfKSAgIHwgfCAgICAgICAgIHwgIF9fX198ICAgICAgICAgICAgICAgIHwgfCB8IHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfCBcXFxcICAvIHxfIF9fX3wgfF8gXyAgIF8gIHwgfF9fIF9fXyAgXyBfXyBfX18gIF9fX3wgfF98IHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfCB8XFxcXC98IHwgLyBfX3wgX198IHwgfCB8IHwgIF9fLyBfIFxcXFx8ICdfXy8gXyBcXFxcLyBfX3wgX198IHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfCB8ICB8IHwgXFxcXF9fIFxcXFwgfF98IHxffCB8IHwgfCB8IChfKSB8IHwgfCAgX18vXFxcXF9fIFxcXFwgfF98IHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfF98ICB8X3xffF9fXy9cXFxcX198XFxcXF9fLCB8IHxffCAgXFxcXF9fXy98X3wgIFxcXFxfX198fF9fXy9cXFxcX198IHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfCAgICAgICAgICAgICAgICAgIF9fLyB8ICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8IHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHxffCAgICBfX19fICBfX19fX19ffF9fXy8gICAgICBfXyAgICAgX19fX18gIF9fX19fXyBfICB8X3wgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfCAgIHwgIF8gXFxcXHwgIF9fX19cXFxcIFxcXFwgICAgICAgIC8gL1xcXFwgICB8ICBfXyBcXFxcfCAgX19fX3wgfCB8IHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfCAgIHwgfF8pIHwgfF9fICAgXFxcXCBcXFxcICAvXFxcXCAgLyAvICBcXFxcICB8IHxfXykgfCB8X18gIHwgfCB8IHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfCAgIHwgIF8gPHwgIF9ffCAgIFxcXFwgXFxcXC8gIFxcXFwvIC8gL1xcXFwgXFxcXCB8ICBfICAvfCAgX198IHwgfCB8IHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfCAgIHwgfF8pIHwgfF9fX18gICBcXFxcICAvXFxcXCAgLyBfX19fIFxcXFx8IHwgXFxcXCBcXFxcfCB8X19fX3xffCB8IHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfCAgIHxfX19fL3xfX19fX198ICAgXFxcXC8gIFxcXFwvXy8gICAgXFxcXF9cXFxcX3wgIFxcXFxfXFxcXF9fX19fXyhfKSB8IHwgICAgXCIpXG4gICAgICAgIHByaW50KFwiIHwgfCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8IHwgIFwiKVxuICAgICAgICBwcmludChcIiB8X3xfX19fIF9fX19fXyBfX19fX18gX19fX19fIF9fX19fXyBfX19fX18gX19fX19fIF9fX19ffF98XCIpXG4gICAgICAgIHByaW50KFwiIHxfX19fX198X19fX19ffF9fX19fX3xfX19fX198X19fX19ffF9fX19fX3xfX19fX198X19fX19ffCBcIilcblxuICAgICAgICBwcmludChcIlxcbigxKUdvIGluIFxcbigyKUdvIGJhY2tcIilcblxuICAgICAgICBpbnB1dCA9IGdldElucHV0KCk7XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMVwiKSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiTWlzdHkgRm9yZXN0IENyb3Nzcm9hZHMgQ0hFQ0tcIjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjJcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcIk1haW4gaHViXCI7XG4gICAgICAgIH1cblxuICAgIH1cblxuXG5cblxuXG5cblxuICAgIGlmIChzY3JlZW4gPT0gXCJNaXN0eSBGb3Jlc3QgQ3Jvc3Nyb2FkcyBDSEVDS1wiKSB7XG5cbiAgICAgICAgZmlnaHRDaGFuY2UgPSBNYXRoLnJhbmRvbSgpO1xuXG4gICAgICAgIGlmIChmaWdodENoYW5jZSA8PSAwLjI1KSB7XG5cbiAgICAgICAgICAgIG5leHRTY3JlZW4gPSBcIk1pc3R5IEZvcmVzdCBDcm9zc3JvYWRzXCI7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiTWlzdHkgRmlnaHRcIlxuXG5cblxuXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZmlnaHRDaGFuY2UgPiAwLjI1KSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiTWlzdHkgRm9yZXN0IENyb3Nzcm9hZHNcIlxuXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWlzdHkgRm9yZXN0IENyb3Nzcm9hZHNcIikge1xuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5Zb3UgdGhpbmsgdGhlcmUgdHdvIHBhdGhzIHRvIHRha2UsIG9uZSBvbiB5b3VyIGxlZnQgYW5kIG9uZSBvbiB5b3VyIHJpZ2h0LiBZb3UgZG8gbm90IGtub3cgd2hhdCBlYWNoIHBhdGggY29udGFpblwiKVxuICAgICAgICBwcmludChcIlxcbigxKUdvIGxlZnQgXFxuKDIpR28gcmlnaHQgXFxuKDMpR28gYmFjayB0byBlbnRyYW5jZVwiKVxuXG4gICAgICAgIGlucHV0ID0gZ2V0SW5wdXQoKTtcblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIxXCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID0gXCJMZWZ0IHBhdGggQ0hFQ0tcIjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjJcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcIlJpZ2h0IHBhdGggQ0hFQ0tcIlxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiM1wiKSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiTWlzdHkgRm9yZXN0IEVudHJhbmNlXCJcbiAgICAgICAgfVxuICAgIH1cblxuXG5cblxuXG4gICAgLy8gTGVmdCBQYXRoXG5cblxuICAgIGlmIChzY3JlZW4gPT0gXCJMZWZ0IHBhdGggQ0hFQ0tcIikge1xuXG4gICAgICAgIGZpZ2h0Q2hhbmNlID0gTWF0aC5yYW5kb20oKTtcblxuXG5cbiAgICAgICAgaWYgKGZpZ2h0Q2hhbmNlIDw9IDAuMjUpIHtcblxuICAgICAgICAgICAgbmV4dFNjcmVlbiA9IFwiTGVmdCBwYXRoXCI7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiTWlzdHkgRmlnaHRcIlxuXG5cblxuXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZmlnaHRDaGFuY2UgPiAwLjI1KSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiTGVmdCBwYXRoXCJcblxuICAgICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHNjcmVlbiA9PSBcIkxlZnQgcGF0aFwiKSB7XG5cblxuICAgICAgICBwcmludChcIlxcblxcblBZPzVHP0pQNUc/fiE3NVBCJiFZR1k/IVA1IX43NTVQSjc3Sj8/WT8/Sko3Pz9KNyE3IX43PyE/WT9KSj83N35+fko/fjd+IUpCQn4hWT9HN0dAUCFKSlA3WSZHIX5+fiE/SlBcIilcbiAgICAgICAgcHJpbnQoXCI3P1lQI0c/N1lCUDdZN35HQCNQWTc3UDU/ISFZR1BKP0o1NVk1WUo/WT9KUEJZPzVQSjU3N1k/IT81NT9QRzdKPz8hSj9Kfn5+PyZQfko1Qj8mJjU/N35QQiZCP34hIX43P1lKXCIpXG4gICAgICAgIHByaW50KFwiWTU1WTVHQlBKWUJQSj83IyZQNyEhUFkhSlBHRzU1NTVQR0I1Pz9KWUo3WVlCI1lKUDVQUFlZWUpZWUc/P1BQWVA1IT9KNSE3WT9ZJkdKN1BCQCMhfn4/JiZZIVk3SkohNz83IVwiKVxuICAgICAgICBwcmludChcIllZWTU1NUJCI0IjJlA3UEBHXllZR0dQUFk3SlA1WTdKNUIjSiFZWTc/SllKP1AjUFlKPzVQR0dQR0IjUEdZQiNQWVBQfjVHSllZUFAmUH5+QkA1XjdHJiZQPz9QWVk3ITc/fn5cIilcbiAgICAgICAgcHJpbnQoXCJKWVBZWT9HRzU1SlkjIyYmUFlQQiYjUFlZWVlZSkpZWVlZQiMjSn5+IUdZNz83NSM1ISEhISE3IVBCWUo/SllQQiNCI0dHRyYmI0ohSiMjP0dAUFkmQEJKNTVKR1BZPzchSjchXCIpXG4gICAgICAgIHByaW50KFwiITVQP0pQQkdZISE3WSZAJiYjRzVKSjc/Nzc3ISE3Nzc3P0pZRyNCNT81Qkp+fn5KQjUhfn5+fllCNTchITc3IT81Qlk3SkJHWUcjIzU3RyYmJiZAJllKUFA1UEdKSlk/IUo3IVwiKVxuICAgICAgICBwcmludChcIn5ZQkpZI0I/fiEhISEjQCZHSko/Nz8/Pzc/NyE3Sj8/Nz83ITc/NUIjIyMmRzVKSlAmQjU1WUcjR1khfjdKNyEhfjdQUD9HWV5+ITUmJiMmJiYmJkp+ISNQR1Ahfn4hSllZP35cIilcbiAgICAgICAgcHJpbnQoXCJKWTVZUEIhfn5+fn5QJkBCPyFZNzdKSj8/WT83ISFKP0o3ISEhfn4hNz9KNTVHQiMjIyYmJiMjI0I1Sj83IX5+fn5+fj9HI0chfn5+IVkjQCYmQEJ+fkojUD9+fn5+fn43WVk/XCIpXG4gICAgICAgIHByaW50KFwiWTd+RyNQfn5+fn5ZJiYmPz9ZWX5+N1khN1k/fn4/WT9+fn5+fn5+fn5+fn5+fiEhNz9ZNUcjIyMjI0c3fn5+fn5+fn5+fjdQQlkhfn5+IUJAJkBCN1BHP35+fn5+fn5+fko1NVwiKVxuICAgICAgICBwcmludChcIiF+fkomUH5+fn5QQiNAIyF+SjU/fiFZN34hSkpKNT9+fn5+fn5+fn5+fn5+fn5+fn5+fn5+N0pHIyMmRzd+fn5+fn5+fn5+fj9QQlBKPyEhIyYmJiNZfn5+fn5+fn5+fn4/NUpcIilcbiAgICAgICAgcHJpbnQoXCJ+fn4hQlB+N1lHUDcjQEd+fn4/NTchWTd+fjc1NT9+fn5+fn5+fn5+fn5+fn5+fn5+fn5+fn5+fllQRyMjNSF+fn5+fn5+fn5+fjdQIyMjQiMmJkBQfn5+fn5+fn5+fn4hWTU3XCIpXG4gICAgICAgIHByaW50KFwifn5+flAjUCM1IX4/JkBKfn5+fkpZWUp+fjdZWTd+fn5+fn5+fn5+fn5+fn5+fn5+fn5+fn5+fn5KSiE/QiZHN35+fn5+fn5+fn5+fjcjIyMjJiYmIyF+fn5+fn5+fn4hSjVZIVwiKVxuICAgICAgICBwcmludChcIn5+fn5QJiNKfn5+UEAmIX5+fn4hWTU3fjdZWTd+fn5+fn5+fn5+fn5+fn5+fn5+fn5+fn5+fn4hWVkhfiFCJkI3fn5+fn5+fn5+fn5+PyMjI0dCQCZZfn5+fn5+fn4hSjU1Sn5cIilcbiAgICAgICAgcHJpbnQoXCJ+fn5+RyYjIX5+NyZAR35+fn5+fj81N35KNTd+fn5+fn5+fn5+fn5+fn5+fn5+fn5+fn5+fn4hSjU/fn5+P0ImQjd+fn5+fn5+fn5+fn5HIyNZNyYmJiF+fn5+fn4hWTU1NT9+XCIpXG4gICAgICAgIHByaW50KFwifn5+NSNCIzV+fkJAJjd+fn5+fiFZSiE3WTUhfn5+fn5+fn5+fn5+fn5+fn5+fn4hISEhNz8/WTU/fn5+fn4hRyYjSn5+fn5+fn5+fn5+UCMjUH41QEBQITc3P0pKWVlZWVk3flwiKVxuICAgICAgICBwcmludChcIjc3WSNCNUIjWUomQEd+fn4hISFKWT83WTU1PyEhfiEhISEhITc3Nzc3Nzc/SkpZWVlZNTVZWVlZPyEhNzc3IT8jIyM1ISE3Nzc/P0pZNSMjIyM1NSYmJlBZWVk1NTU1NTU1NT9cIilcbiAgICAgICAgcHJpbnQoXCIjIyMjIyMjIyMmJiYjWVlZNTU1NTU1WVlZWVlZWVlZNTVQUEdHR0dHR0dQUFA1NTU1NTU1NTU1NVBQR0dHQkIjIyMjI0JHR0dHQiMjIyMjIyMjIyYmJiYmI0JCQiMjIyMjIyMjXCIpXG4gICAgICAgIHByaW50KFwiIyMjIyYmJiYmJiYmJiMjIyMjIyMjI0JHR0dCQkIjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjJiYmJiYmJiYmJiYmJiYjIyMjIyMjI1wiKVxuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5UaGVyZSBpcyBhIHN0cmFpZ2h0IHBhdGggdG8gZm9sbG93IGJ1dCB5b3UgYXJlIHN1cnJvdW5kZWQgYnkgdHJlZXMgb2YgdGhlIE1pc3R5IEZvcmVzdC5cXG5Zb3Ugd29uZGVyIGlmIHRoZXJlJ3MgYW55dGhpbmcgb2ZmIHRoZSBwYXRoLiBNYXliZSBzb21ldGhpbmcgdGhhdCBjb3VsZCBoZWxwIHlvdS5cIik7XG5cbiAgICAgICAgcHJpbnQoXCJcXG4oMSlEbyB5b3UgZ28gaW50byB0aGUgdHJlZXMgXFxuKDIpc3RheSBvbiBwYXRoIFxcbigzKUdvIGJhY2sgdG8gdGhlIGNyb3Nzcm9hZHNcIik7XG4gICAgICAgIGlucHV0ID0gZ2V0SW5wdXQoKTtcblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIxXCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID0gXCJpbnRvIHRoZSB0cmVlc1wiXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIyXCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID0gXCJHaWFudCBMYWtlXCJcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjNcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcIk1pc3R5IEZvcmVzdCBDcm9zc3JvYWRzIENIRUNLXCJcbiAgICAgICAgfVxuICAgIH1cblxuXG5cbiAgICBpZiAoc2NyZWVuID09IFwiaW50byB0aGUgdHJlZXNcIikge1xuXG5cbiAgICAgICAgcHJpbnQoXCJcXG4gICAgICBfX19fX1wiKVxuICAgICAgICBwcmludChcIiAgICAgYC5fX18sJ1wiKVxuICAgICAgICBwcmludChcIiAgICAgIChfX18pXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgPCAgID5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgKSAoXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgL2AtLlxcXFxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgIC8gICAgIFxcXFxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgLyBfICAgIF9cXFxcXCIpXG4gICAgICAgIHByaW50KFwiICAgOiwnIGAtLicgYDpcIilcbiAgICAgICAgcHJpbnQoXCIgICB8ICAgICAgICAgfFwiKVxuICAgICAgICBwcmludChcIiAgIDogICAgICAgICA7XCIpXG4gICAgICAgIHByaW50KFwiICAgIFxcICAgICAgIC9cIilcbiAgICAgICAgcHJpbnQoXCIgICAgIGAuX19fLicgXCIpXG5cblxuXG4gICAgICAgIHByaW50KFwiXFxuWW91IGV4cGxvcmUgaW50byB0aGUgdHJlZXMgYW5kIGZvdW5kIGFuIGl0ZW0gY2FsbGVkIHRoZSB0cmVlIGltbW9iaWxpemVyIG9uIHRvcCBhIGRlYWQgdHJlZS4gWW91IHRha2UgdGhlIGl0ZW0uXCIpXG4gICAgICAgIHByaW50KFwiXFxuTm93IHdoYXQgZG8geW91IHdhbnQgdG8gZG8/XCIpXG4gICAgICAgIHRyZWVJbW1vYmlsaXplciA9IHRydWU7XG4gICAgICAgIHByaW50KFwiXFxuKDEpR28gYmFjayB0byBMZWZ0IEVudHJhbmNlIFxcbigyKWV4cGxvcmUgbW9yZVwiKVxuICAgICAgICBpbnB1dCA9IGdldElucHV0KCk7XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMVwiKSB7XG4gICAgICAgICAgICBzY3JlZW4gPSBcIkxlZnQgcGF0aCBDSEVDS1wiO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMlwiKSB7XG4gICAgICAgICAgICBzY3JlZW4gPSBcImRlYXRoXCJcbiAgICAgICAgfVxuICAgIH1cblxuXG5cblxuXG4gICAgLy9vclxuXG5cbiAgICAvL0dpYW50IExha2VcblxuXG5cblxuICAgIGlmIChzY3JlZW4gPT0gXCJHaWFudCBMYWtlXCIgJiYgdHJlZUVzc2VuY2UgPT0gZmFsc2UgfHwgc2NyZWVuID09IFwiR2lhbnQgTGFrZVwiICYmIGR1bmdlb25LZXkgPT0gdHJ1ZSkge1xuXG4gICAgICAgIHByaW50KFwiXFxuWW91IGZpbmQgdGhpcyBnaWFudCBsYWtlIHdpdGggY2xlYXIgd2F0ZXIgaW4gaXQuXCIpO1xuICAgICAgICBwcmludChcIlxcblxcbiAgICAgICAgICAgICAgLC4gIF9+LS4sICAgICAgICAgICAgICAgLlx0XHRcdFx0XHRcIik7XG4gICAgICAgIHByaW50KFwiICAgICAgICAgICB+LmBfIFxcXFwvLF8uIFxcXFxfXHRcdFx0XHRcdFx0XCIpO1xuICAgICAgICBwcmludChcIiAgICAgICAgICAvICwsXz5AYCxfX2B+LikgICAgICAgICAgICAgfCAgICAgICAgICAgLlx0XHRcdFwiKTtcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgfCB8ICBAQEBALiAgOiwhIC4gICAgICAgICAgIC4gICAgICAgICAgLlx0XHRcdFwiKTtcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgfC8gICBeXkAgICAgIC4hICBcXFxcICAgICAgICAgIHwgICAgICAgICAvXHRcdFx0XCIpO1xuICAgICAgICBwcmludChcIiAgICAgICAgICBgLiAuXl5eICAgICAsLiAgICAuICAgICAgICAgfCAgICAgICAgLiAgICAgICAgICAgICAuXHRcdFwiKTtcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgIC5eXl4gICAuICAgICAgICAgIFxcXFwgICAgICAgICAgICAgICAgLyAgICAgICAgICAuXHRcdFwiKTtcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgLl5eXiAgICAgICAuICAuICAgICBcXFxcICAgICAgIHwgICAgICAvICAgICAgIC4gLlx0XHRcIik7XG4gICAgICAgIHByaW50KFwiLiwuLC4gICAgIF5eXiAgICAgICAgICAgICBgIC4gICAuLCt+LmBeYC5+KywuICAgICAsIC5cdFx0XHRcIik7XG4gICAgICAgIHByaW50KFwiJiYmJiYmLCAgLF5eXl4uICAuIC5fIC4uX18gXyAgLi4gICAgICAgICAgICAgLi4gLl8gX18gX19fXyBfXyBfIC4uIC4gIC4gIFwiKTtcbiAgICAgICAgcHJpbnQoXCIlJSUlJSUlJSVeXl5eXl4lJSYmO18sLi09fi5gXmAufj0tLixfXywuLT1+LmBeYC5+PS0uLF9fLC4tPX4uYF5gLn49LS4sICAgXCIpO1xuICAgICAgICBwcmludChcIiYmJiYmJSUlJSUlJSUlJSUlJSUlJSUlJiY7LC4tPX4uYF5gLn49LS4sX18sLi09fi5gXmAufj0tLixfXywuLT1+LmBeYC5+PSBcIik7XG4gICAgICAgIHByaW50KFwiJSUlJSUmJiYmJiYmJiYmJiUlJSUmJiZfLC47XmAufj0tLixfXywuLT1+LmBeYC5+PS0uLF9fLC4tPX4uYF5gLn49LS4sX18sIFwiKTtcbiAgICAgICAgcHJpbnQoXCIlJSUlJSUlJSUmJiYmJiYmJiYtPX4uYF5gLn49LS4sX18sLi09fi5gXmAufj0tLixfXywuLT09LS1eLn49LS4sX18sLi09fi4gXCIpO1xuICAgICAgICBwcmludChcIiMjbWp5IyMjIyMqOi5cdFx0XHRcdFx0XHRcdFx0XCIpO1xuICAgICAgICBwcmludChcIl8sLi09fi5gXmAufj0tLixfXywuLT1+LmBeYC5+PS0uLF9fLC4tPX4uYF5gLn49LS4sLi09fi5gXmAufj0tLixfXywuLT1+LiBcIik7XG4gICAgICAgIHByaW50KFwiXHRcdFx0XHRcdFx0XHRcdFx0XHRcIik7XG4gICAgICAgIHByaW50KFwifmAuXmAufj0tLixfXywuLT1+LmBeYC5+PS0uLF9fLC4tPX4uYF5gLn49LS4sX18sLi09fi5gXmAufj0tLixfXywuLT1+LmBeIFwiKTtcblxuICAgICAgICBwcmludChcIlxcbigxKURyaW5rIHRoZSB3YXRlciAgXFxuKDIpc3dpbSB0byBjb250aW51ZSBcXG4oMylleHBsb3JlIHRoZSB3YXRlciBcXG4oNClHbyBiYWNrXCIpO1xuICAgICAgICBpbnB1dCA9IGdldElucHV0KCk7XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMVwiKSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiZGVhdGhcIjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjJcIikge1xuICAgICAgICAgICAgcHJpbnQoXCJcXG5Zb3Ugc3dpbSBhY3Jvc3MgdGhlIGVudGlyZSBsYWtlIGJ1dCB5b3UgcmVhbGl6ZSB5b3Ugc3VjayBhdCBzd2ltbWluZyBzbyB5b3UgZ28gYmFjayB0byB0aGUgc2hvcmUuXCIpO1xuICAgICAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiM1wiKSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiZXhwbG9yZSBsYWtlXCJcblxuXG5cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjRcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcIkxlZnQgcGF0aCBDSEVDS1wiXG4gICAgICAgIH1cblxuICAgIH0gZWxzZSBpZiAoc2NyZWVuID09IFwiR2lhbnQgTGFrZVwiICYmIHRyZWVFc3NlbmNlID09IHRydWUgJiYgZHVuZ2VvbktleSA9PSBmYWxzZSkge1xuXG4gICAgICAgIHByaW50KFwiXFxuWW91IGZpbmQgdGhpcyBnaWFudCBsYWtlIHdpdGggY2xlYXIgd2F0ZXIgaW4gaXQuXCIpO1xuICAgICAgICBwcmludChcIlxcblxcbiAgICAgICAgICAgICAgLC4gIF9+LS4sICAgICAgICAgICAgICAgLlx0XHRcdFx0XHRcIik7XG4gICAgICAgIHByaW50KFwiICAgICAgICAgICB+LmBfIFxcXFwvLF8uIFxcXFxfXHRcdFx0XHRcdFx0XCIpO1xuICAgICAgICBwcmludChcIiAgICAgICAgICAvICwsXz5AYCxfX2B+LikgICAgICAgICAgICAgfCAgICAgICAgICAgLlx0XHRcdFwiKTtcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgfCB8ICBAQEBALiAgOiwhIC4gICAgICAgICAgIC4gICAgICAgICAgLlx0XHRcdFwiKTtcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgfC8gICBeXkAgICAgIC4hICBcXFxcICAgICAgICAgIHwgICAgICAgICAvXHRcdFx0XCIpO1xuICAgICAgICBwcmludChcIiAgICAgICAgICBgLiAuXl5eICAgICAsLiAgICAuICAgICAgICAgfCAgICAgICAgLiAgICAgICAgICAgICAuXHRcdFwiKTtcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgIC5eXl4gICAuICAgICAgICAgIFxcXFwgICAgICAgICAgICAgICAgLyAgICAgICAgICAuXHRcdFwiKTtcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgLl5eXiAgICAgICAuICAuICAgICBcXFxcICAgICAgIHwgICAgICAvICAgICAgIC4gLlx0XHRcIik7XG4gICAgICAgIHByaW50KFwiLiwuLC4gICAgIF5eXiAgICAgICAgICAgICBgIC4gICAuLCt+LmBeYC5+KywuICAgICAsIC5cdFx0XHRcIik7XG4gICAgICAgIHByaW50KFwiJiYmJiYmLCAgLF5eXl4uICAuIC5fIC4uX18gXyAgLi4gICAgICAgICAgICAgLi4gLl8gX18gX19fXyBfXyBfIC4uIC4gIC4gIFwiKTtcbiAgICAgICAgcHJpbnQoXCIlJSUlJSUlJSVeXl5eXl4lJSYmO18sLi09fi5gXmAufj0tLixfXywuLT1+LmBeYC5+PS0uLF9fLC4tPX4uYF5gLn49LS4sICAgXCIpO1xuICAgICAgICBwcmludChcIiYmJiYmJSUlJSUlJSUlJSUlJSUlJSUlJiY7LC4tPX4uYF5gLn49LS4sX18sLi09fi5gXmAufj0tLixfXywuLT1+LmBeYC5+PSBcIik7XG4gICAgICAgIHByaW50KFwiJSUlJSUmJiYmJiYmJiYmJiUlJSUmJiZfLC47XmAufj0tLixfXywuLT1+LmBeYC5+PS0uLF9fLC4tPX4uYF5gLn49LS4sX18sIFwiKTtcbiAgICAgICAgcHJpbnQoXCIlJSUlJSUlJSUmJiYmJiYmJiYtPX4uYF5gLn49LS4sX18sLi09fi5gXmAufj0tLixfXywuLT09LS1eLn49LS4sX18sLi09fi4gXCIpO1xuICAgICAgICBwcmludChcIiMjbWp5IyMjIyMqOi5cdFx0XHRcdFx0XHRcdFx0XCIpO1xuICAgICAgICBwcmludChcIl8sLi09fi5gXmAufj0tLixfXywuLT1+LmBeYC5+PS0uLF9fLC4tPX4uYF5gLn49LS4sLi09fi5gXmAufj0tLixfXywuLT1+LiBcIik7XG4gICAgICAgIHByaW50KFwiXHRcdFx0XHRcdFx0XHRcdFx0XHRcIik7XG4gICAgICAgIHByaW50KFwifmAuXmAufj0tLixfXywuLT1+LmBeYC5+PS0uLF9fLC4tPX4uYF5gLn49LS4sX18sLi09fi5gXmAufj0tLixfXywuLT1+LmBeIFwiKTtcblxuICAgICAgICBwcmludChcIlxcbigxKURyaW5rIHRoZSB3YXRlciAgXFxuKDIpc3dpbSB0byBjb250aW51ZSBcXG4oMylleHBsb3JlIHRoZSB3YXRlciBcXG4oNClHbyBiYWNrIFxcbig1KURyb3AgVHJlZSBlc3NlbmNlIGludG8gdGhlIGxha2VcIik7XG4gICAgICAgIGlucHV0ID0gZ2V0SW5wdXQoKTtcblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIxXCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID0gXCJkZWF0aFwiO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMlwiKSB7XG4gICAgICAgICAgICBwcmludChcIlxcbllvdSBzd2ltIGFjcm9zcyB0aGUgZW50aXJlIGxha2UgYnV0IHlvdSByZWFsaXplIHlvdSBzdWNrIGF0IHN3aW1taW5nIHNvIHlvdSBnbyBiYWNrIHRvIHRoZSBzaG9yZS5cIik7XG4gICAgICAgICAgICBGdW4udGhyZWFkU2xlZXAoMjAwMCk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIzXCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID0gXCJleHBsb3JlIGxha2VcIjtcblxuXG5cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjRcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcIkxlZnQgcGF0aCBDSEVDS1wiO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiNVwiKSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiR2V0dGluZyBkdW5nZW9uIGtleVwiO1xuICAgICAgICB9XG5cbiAgICB9XG5cblxuXG4gICAgaWYgKHNjcmVlbiA9PSBcIkdldHRpbmcgZHVuZ2VvbiBrZXlcIikge1xuXG4gICAgICAgIHByaW50KFwiXFxuICBhZDg4ODg4ODg4ODhiYVwiKVxuICAgICAgICBwcmludChcIiBkUCcgICAgICAgICBgXFxcIjhiLFwiKVxuICAgICAgICBwcmludChcIiA4ICAsYWFhLCAgICAgICBcXFwiWTg4OGEgICAgICxhYWFhLCAgICAgLGFhYSwgICxhYSxcIilcbiAgICAgICAgcHJpbnQoXCIgOCAgOCcgYDggICAgICAgICAgIFxcXCI4OGJhYWRQXFxcIlxcXCJcXFwiXFxcIlliYWFhZFBcXFwiXFxcIlxcXCJZYmRQXFxcIlxcXCJZYlwiKVxuICAgICAgICBwcmludChcIiA4ICA4ICAgOCAgICAgICAgICAgICAgXFxcIlxcXCJcXFwiICAgICAgICBcXFwiXFxcIlxcXCIgICAgICBcXFwiXFxcIiAgICA4YlwiKVxuICAgICAgICBwcmludChcIiA4ICA4LCAsOCAgICAgICAgICxhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFkZGRkZDg4UFwiKVxuICAgICAgICBwcmludChcIiA4ICBgXFxcIlxcXCJcXFwiJyAgICAgICAsZDhcXFwiXFxcIlwiKVxuICAgICAgICBwcmludChcIiBZYiwgICAgICAgICAsYWQ4XFxcIlwiKVxuICAgICAgICBwcmludChcIiAgXFxcIlk4ODg4ODg4ODg4UFxcXCJcIilcblxuICAgICAgICBwcmludChcIlxcbllvdSBkcm9wIHRoZSB0cmVlIGVzc2VuY2UgaW50byB0aGUsIHRoZSBsYWtlIHN0YXJ0ZWQgdG8gc2hha2UgYW5kIGl0IHNwaXQgb3V0IHRoZSBrZXkgdGhhdCBvcGVucyBzb21lIGRvb3IuXCIpXG5cbiAgICAgICAgcHJpbnQoXCJcXG5Zb3Ugc2hvdWxkIGZpbmQgb3V0IHdoZXJlIGl0IGdvZXMuXCIpXG5cbiAgICAgICAgZHVuZ2VvbktleSA9IHRydWVcblxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoMzAwMClcblxuICAgICAgICBzY3JlZW4gPSBcIkdpYW50IExha2VcIjtcblxuICAgIH1cblxuICAgIGlmIChzY3JlZW4gPT0gXCJleHBsb3JlIGxha2VcIikge1xuXG4gICAgICAgIHByaW50KFwiV2hpbGUgZXhwbG9yaW5nIHRoZSB3YXRlciB5b3UgZmluZCB0aGlzIHNlYSBtb25zdGVyIGx1cmtpbmcgYXQgdGhlIGJvdHRvbSBvZiB0aGUgc2VhXCIpO1xuXG4gICAgICAgIHByaW50KFwiXFxuKDEpSW50ZXJhY3Qgd2l0aCB0aGUgc2VhIG1vbnN0ZXIgXFxuKDIpZ28gYmFjayB0byB0aGUgc2hvcmVcIik7XG5cbiAgICAgICAgaW5wdXQgPSBnZXRJbnB1dCgpO1xuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjFcIikge1xuICAgICAgICAgICAgc2NyZWVuID0gXCJzZWEgbW9uc3RlclwiXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMlwiKSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiR2lhbnQgTGFrZVwiXG4gICAgICAgIH1cbiAgICB9XG5cblxuXG5cblxuICAgIC8vc2VhIG1vbnN0ZXJcblxuXG5cblxuICAgIGlmIChzY3JlZW4gPT0gXCJzZWEgbW9uc3RlclwiKSB7XG5cblxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9vXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvXFxcIiAgJFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXCIgbyAgICRcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXCIgICAgICAkXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICQgICAgICAkJCBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb1xcXCIgICAgIFxcXCIkbyBcIilcbiAgICAgICAgcHJpbnQoXCIgICAkb28gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJCAgICAgXFxcIiQkJFwiKVxuICAgICAgICBwcmludChcIiAgICRcXFwiJG9vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXCIgICAgICBcXFwibyQkIFwiKVxuICAgICAgICBwcmludChcIiAgXFxcIiQkbyRcXFwib1xcXCJvICAgICAgICAgICAgICAgICAgICAgICAgICBvXFxcIiAgICAgICRcXFwiJCQkXCIpXG4gICAgICAgIHByaW50KFwiICAgICBcXFwiXFxcIlxcXCJvXFxcIiRvXFxcIlxcXCJcXFwiXFxcIlxcXCJcXFwiXFxcIlxcXCIgXFxcIlxcXCJcXFwiIG9vIG9vb29vb29cXFwiXFxcIlxcXCIgICAgIG9cXFwiXFxcIm8kJCRcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgXFxcIiQkIG8gICAgICAgICAgICAgICAgICAgICAgICAgICAgb1xcXCJcXFwiJCQkXCIpXG4gICAgICAgIHByaW50KFwiICAgIG9vb28kJCQkJCQkJG9vXFxcIm8gbyAgICAgICAgICAgICAgICAgbyBcXFwibyBcXFwibyBcXFwiXFxcIm9vXCIpXG4gICAgICAgIHByaW50KFwiICBcXFwiJCQkJCQkJCQkJFxcXCJcXFwiXFxcIlxcXCIkJCQkb1xcXCJvJCBvIG8gbyAgXFxcIm8gXFxcIiAkXFxcIiRvJCRvb1xcXCJvICAkXFxcIm9cIilcbiAgICAgICAgcHJpbnQoXCIgICBcXFwiJCQkJCQkXFxcIiAgICAgICAgIFxcXCJcXFwiJCRvJG8kICQgXFxcIm9vbyRvJG8kJCQkJCRcXFwiJG8kbyAkXFxcIiRvXCIpXG4gICAgICAgIHByaW50KFwiICAgXFxcIiRcXFwiXFxcIiAgICAgICAgICAgICAgICAgXFxcIlxcXCJcXFwiXFxcIiQkJCQkbyQkJCQkJCQkJCAgICAgXFxcIiRvJCQkJG9cIilcbiAgICAgICAgcHJpbnQoXCIgICBcXFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcIiBcXFwiXFxcIiBcXFwiICBcXFwiJCQkJCAgICAgICBcXFwiICQkJG9cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxcXCIkJCQgICAgICAgICBcXFwiXFxcIlxcXCJcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXFxcIlxcXCIkXCIpXG5cbiAgICAgICAgcHJpbnQoXCJcXG5Zb3UgZ28gdG8gdGhlIHNlYSBtb25zdGVyIGFuZCBpdCBzZWVtcyB0byBiZSBmcmllbmRseS4gSXQgYWxzbyB0ZWxscyB5b3Ugc29tZXRoaW5nXCIpXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXFwiSWYgeW91IGhhdmUgc29tZSBzcGVjaWFsIHRyZWUgZXNzZW5jZSwgeW91IHNob3VsZCBkcm9wIGl0IGludG8gdGhpcyBsYWtlIGFuZCBpdCB3aWxsIHNwaXQgb3V0IGEga2V5IHRvIGEgZHVuZ2VvbiBkZWVwIGludG8gTWlzdHkgRm9yZXN0XFxcIlwiKVxuXG5cblxuICAgICAgICBwcmludChcIlxcbigxKSBIb3cgZG8gSSBnZXQgdHJlZSBlc3NlbmNlIFxcbigyKVdoeSBhcmUgeW91IHRlbGxpbmcgbWUgdGhpcyBcXG4oMylHbyBiYWNrIHRvIHRoZSBzaG9yZVwiKVxuXG4gICAgICAgIGlucHV0ID0gZ2V0SW5wdXQoKTtcblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIxXCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID0gXCJIb3cgZG8gSSBnZXQgaXRcIlxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMlwiKSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiV2h5IGFyZSB5b3UgdGVsbGluZyBtZSB0aGlzXCJcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjNcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcIkdpYW50IExha2VcIlxuICAgICAgICB9XG4gICAgfVxuXG5cbiAgICBpZiAoc2NyZWVuID09IFwiSG93IGRvIEkgZ2V0IGl0XCIpIHtcblxuICAgICAgICBwcmludChcIllvdSBhc2sgaG93IGFuZCB3aGVyZSB5b3UgZ2V0IHRoaXMgc3BlY2lhbCBlc3NlbmNlLlwiKVxuXG4gICAgICAgIHByaW50KFwiXFxuVGhlIHNlYSBtb25zdGVyIHJlcGxpZXMgXFxuXFzigJxZb3UgaGF2ZSB0byBraWxsIG9uZSBvZiB0aGUgTWlzdHkgZm9yZXN0IHRyZWVzIGFuZCBub3QgYW55IG9yZGluYXJ5IHRyZWUsIGEgdHJlZSB0aGF0IGNhbiBtb3ZlLCBnb29kIGx1Y2sgZmluZGluZyBvbmUuXFzigJ1cIilcblxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoNTAwMClcblxuICAgICAgICBzY3JlZW4gPSBcInNlYSBtb25zdGVyXCJcbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwiV2h5IGFyZSB5b3UgdGVsbGluZyBtZSB0aGlzXCIpIHtcblxuICAgICAgICBwcmludChcIllvdSBhc2sgdGhlIHNlYSBtb25zdGVyIHdoeSBpdCBpcyB0ZWxsaW5nIHlvdSB0aGlzLlwiKVxuXG4gICAgICAgIHByaW50KFwiXFxuVGhleSByZXBseTogXFxuXFzigJxXZWxsIHRoZSBmb3Jlc3QgaGFzIGJlZW4gY3Vyc2VkIGJ5IHRoZSBNaXN0IERyYWdvbiwgaXQgY29udHJvbHMgZXZlcnl0aGluZyBpbiB0aGlzIGZvcmVzdC4gRnJvbSB0aGUgdHJlZXMsIHRvIHRoZSBNaXN0aWVzLCBwcmV0dHkgbXVjaCBhbnl0aGluZy5cXG5FeGNlcHQgbWUsIG5vdCBldmVuIEkga25vdyB3aHkgdGhlIE1pc3QgZHJhZ29ucyBlZmZlY3QgZG9lc27igJl0IGltcGFjdCBtZSwgYnV0IGF0IGxlYXN0IEkgY2FuIGxpdmUgbXkgb3duIGxpZmUuIEkganVzdCBob3BlIG1lIHRlbGxpbmcgeW91IHRoaXMgXFzigJ1cIilcbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKDcwMDApXG5cbiAgICAgICAgc2NyZWVuID0gXCJzZWEgbW9uc3RlclwiXG4gICAgfVxuXG5cbiAgICAvLyBSaWdodCBQYXRoXG5cbiAgICBpZiAoc2NyZWVuID09IFwiUmlnaHQgcGF0aCBDSEVDS1wiKSB7XG5cbiAgICAgICAgZmlnaHRDaGFuY2UgPSBNYXRoLnJhbmRvbSgpO1xuXG5cblxuICAgICAgICBpZiAoZmlnaHRDaGFuY2UgPD0gMC4yNSkge1xuXG4gICAgICAgICAgICBuZXh0U2NyZWVuID0gXCJSaWdodCBwYXRoXCI7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiTWlzdHkgRmlnaHRcIlxuXG5cblxuXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZmlnaHRDaGFuY2UgPiAwLjI1KSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiUmlnaHQgcGF0aFwiXG5cbiAgICAgICAgfVxuXG5cblxuICAgIH1cblxuXG4gICAgaWYgKHNjcmVlbiA9PSBcIlJpZ2h0IHBhdGhcIikge1xuXG4gICAgICAgIHByaW50KFwiXFxuXFxuJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJlwiKVxuICAgICAgICBwcmludChcIiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiZcIilcbiAgICAgICAgcHJpbnQoXCIjIyMjJiYmJiYmJiYjIyYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYjXCIpXG4gICAgICAgIHByaW50KFwiI0IjI0IjIyMjIyMmI1AjJiZCQiMjJiYmJiYmJiYjIyYmJiYmI0IjIyMjJiMmIyMjI0IjIyMjIyYmJiYmJiYmJiYmJiYjJiYmJiYmJiYmJiYmJiYmJiYmJiMjIyYmIyMjIyNCQlwiKVxuICAgICAgICBwcmludChcIkdHQkdCQiNCR0JHUCYjJiZCR0IjJiYjI0IjQkJHR0dQR0JCIyMjQkJCIyNCI0IjIyMjQkIjI0dHI0JHR0dHR0IjJiYmJiYmJiYmI0IjJiYjIyYmIyYmJkJCIyMjIyNCI0JHQkJcIilcbiAgICAgICAgcHJpbnQoXCI3UEdZNUcjQkdQUFlQJiYmJiZCRzU1UDVZNTU1NVk1NVlZUFBCQkJHNVBCQjU1NUcjQkdHNTVZR0JQWTU1NVk1UEcjQkdHI0JCQiYmI0IjJiYmJiYmQkdHQkdCQlBQUFA1NT9+XCIpXG4gICAgICAgIHByaW50KFwiOjVCSkojRzchNz9KPyMmJlBZWTVZNVA1NTVZNVA1NVBQUDU1NVk1R0JCQiNCUDU1UCNCNT9ZRyNHNVk1UFlZNVk1NVBCR0JHWTVZQiYmJiYmJiYmR1k1I0JCQjU1WVlZWTUhLlwiKVxuICAgICAgICBwcmludChcIj81NT81R146Ojo6OlkmJkI3fjUhN1k1NTU1WUpKPzVQNTVZNVk1WTVZSj9KWVBHQiMjIyNHQiMjQlBZSiF+fiE3N146flAjQj8hNzd+NyMmJiYmQjohUCNQWTc3Nzd+OiE1NTdcIilcbiAgICAgICAgcHJpbnQoXCI1fjo1I1k6Ojo6OkomJiYhP1A1Oi4hNV5+WT9eOjdQN15eISF+fl5eOjo6Ojo6Ol5+IT9ZUEIjIyMjR34uOjo6Ojo6Ojo6fllCPzouLi46UCYmQEJ+NVB+Ojo6Ojo6Ojo6SlBQXCIpXG4gICAgICAgIHByaW50KFwiXjo6NyZZOjo6OjVCI0AjOjo/UCE6XjV+Ljo/Sj9QPzo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6LjpeN1AjIyNQfjo6Ojo6Ojo6Ojo6fjVHNTd+Xl5CJiYmQj86Ojo6Ojo6Ojo6Oj9QSlwiKVxuICAgICAgICBwcmludChcIjo6Ol5CNS5+P1BZfkJANTo6Oj9Qfn41fjouIVBQNzo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6WUdQIyNZOjo6Ojo6Ojo6Ojo6flkjI0JCQiYmQDUuOjo6Ojo6Ojo6Ol5ZUCFcIilcbiAgICAgICAgcHJpbnQoXCI6Ojo6NUI1QkpeLn4mQDcuOjo6SjU1WTo6flk1ITo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OllZOiFHJkdeOjo6Ojo6Ojo6Ojo6fkIjIyMmJiYjOjo6Ojo6Ojo6OjpKUFleXCIpXG4gICAgICAgIHByaW50KFwiOjo6OjUjIzcuOi5ZQCZeOjo6Ol41UH46flA1fjo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OjpZUF4uXkImR146Ojo6Ojo6Ojo6Oi4hIyMjUEJAJj86Ojo6Ojo6Ol5KUFBKOlwiKVxuICAgICAgICBwcmludChcIjo6OjpQI0I6OjpeJkA1Ojo6OjouN1B+Lj9QITo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo/UDc6Ojp+QiNHfjo6Ojo6Ojo6Ojo6OlAjIz9+JiYmXjo6Ojo6On5ZUDVQNzpcIilcbiAgICAgICAgcHJpbnQoXCI6OjpKI0IjWTo6R0Amfjo6Ojo6XllZXn41UH46Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6On5ZUDcuOjo6LjpHJkI3Ojo6Ojo6Ojo6Ojo1IyNZLkpAQFk6Ojo6Xj81UDVQNSE6XCIpXG4gICAgICAgIHByaW50KFwifl43IzUhUCM/PyZAUC46Ojo6OllQIV5ZUFA3Ojo6OjpeXl5efn5eXjo6Ojo6Xl46XjpeN1k1UFleXn4hNyFefkcjI1lefiE3Nz9KIV4hQiMjI0o/JiYmUFlZWVlQNVA1NTU1N1wiKVxuICAgICAgICBwcmludChcIlBQI0JQUFBCIyYmJkI3fn4hN0o1NTU1UDU1NUo/Pz9KWTU1NVBHUDVZSllZWVA1WTVZNVBQNTU1NVA1UDU1NTU1IyMjQkdHUFBQUFBQQiMjIyMjRyYmJiYjR1A1NTU1NVA1NTVcIilcbiAgICAgICAgcHJpbnQoXCJCIyNHI0IjIyMmJiYjR0JCR0dHUEdHUFA1NTU1UEJCR1BQNTVHIyMjQkIjIyMjIyNCQkdQUEdCQkIjQkdHR1A1NUIjIyMjIyNCUFBCIyMjIyMjIyMmJiYmJiYjQkdHR0JCQkJCXCIpXG4gICAgICAgIHByaW50KFwiJiYmJiYmJiYmJiYmJiYjIyMjIyMjIyMjQkdHQiMjIyMjQkdHQiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNCQkJCIyMjIyMjIyMjIyNCIyMjIyMjJiYmJiYmJiYmJiYmJiYmJlwiKVxuICAgICAgICBwcmludChcIiYmJiYmJiYmJiYmJiYmJiYmJiYmJiNCIyMjIyMjIyMjIyMjJiYjIyYmJiYmJiYmJiYmJiYmIyMjIyMjIyMjIyMjIyMjIyMjIyMjQiMjIyMjJiYmJiYmJiYmJiYmJiYmJiYmJiZcIilcbiAgICAgICAgcHJpbnQoXCImJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYjIyMmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmIyMjIyMjIyMjIyMjIyYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmXCIpXG4gICAgICAgIHByaW50KFwiJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiMjIyMmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJlwiKVxuICAgICAgICBwcmludChcIiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiZcIilcblxuICAgICAgICBwcmludChcIlxcblRoZSBwYXRoIGlzIHN1cGVyIGJ1bXB5IGFuZCBhbGwgb3ZlciB0aGUgcGxhY2UuIFlvdSBoZWFyIHNvdW5kcyBvZiBjcmVhdHVyZXMgbWFraW5nIGludGVyZXN0aW5nIHNvdW5kcy4gWW91IGRvblxc4oCZdCBmZWVsIHNhZmUgaGVyZS5cIik7XG5cbiAgICAgICAgcHJpbnQoXCJcXG4oMSlHbyBiYWNrIHRvIHRoZSBjcm9zc3JvYWRzXFxuKDIpa2VlcCBvbiBnb2luZ1wiKVxuXG4gICAgICAgIGlucHV0ID0gZ2V0SW5wdXQoKTtcblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgIHNjcmVlbiA9IFwiTWlzdHkgRm9yZXN0IENyb3Nzcm9hZHMgQ0hFQ0tcIlxuXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIyXCIpIHtcbiAgICAgICAgICAgIHNjcmVlbiA9IFwidHJlZSBwdXp6bGUgQ0hFQ0tcIlxuXG4gICAgICAgIH1cblxuICAgIH1cblxuXG5cblxuXG4gICAgLy90cmVlIHB1enpsZVxuXG5cbiAgICBpZiAoc2NyZWVuID09IFwidHJlZSBwdXp6bGUgQ0hFQ0tcIikge1xuICAgICAgICBmaWdodENoYW5jZSA9IE1hdGgucmFuZG9tKCk7XG5cblxuXG4gICAgICAgIGlmIChmaWdodENoYW5jZSA8PSAwLjI1KSB7XG5cbiAgICAgICAgICAgIG5leHRTY3JlZW4gPSBcInRyZWUgcHV6emxlXCI7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiTWlzdHkgRmlnaHRcIlxuXG5cblxuXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZmlnaHRDaGFuY2UgPiAwLjI1KSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwidHJlZSBwdXp6bGVcIlxuXG4gICAgICAgIH1cblxuICAgIH1cblxuICAgIGlmIChzY3JlZW4gPT0gXCJ0cmVlIHB1enpsZVwiICYmIHRyZWVFc3NlbmNlID09IGZhbHNlKSB7XG5cblxuICAgICAgICBwcmludChcIlxcbiAgICAgICAgICAgICAgICAgICAgICAuLS4tLiBfIF8gXyAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAvfCB8IHwoL3x8fHx8X3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgX3wgfCB8Ly0nYCdgJy98XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgLyBcXFxcL3wgICBvICArIF9fLi0gLyhcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgIHwgICd8L3wgLXwvKHx8fHwoX1ZfKVwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgYC5fLnwgfC9fL18pYC0nJyAvLy9fPFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgID4vLy9cXFxcXFxcXFxcXFxcXFxcXFxcXC8vPT08PDw9XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgIF8gPj4+XFxcXFxcXFxcXFxcPi8vPF9fPDw8LSdcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAvIGAtLl8+Pj4uLScgICB8PDxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgIEogICAgIF8uKSkgICAgIC88PDw8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgIHYgICB8ICAuLScnIHwvX18gICB8PDw8fHxfXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgIFxcXFxcXFxcXFxcXHx8fCBgLT4gXy8gLyBcXFxcICBgLTw8PDw8PCoqKiAqKlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgXFxcXFxcXFxcXFxcKip8fHx8IC8gICAgLz48PFxcXFwgICAgXFxcXDw8PCoqKioqKioqXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgID4+KiovLy8vICAgIC88Pj4+PmAuICAgfCoqKioqKiA8PF9cXFxcX1xcXFxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgID4+KioqL18gIC4nPj4+PD4+PjxcXFxcICB8KioqKio8PDx8X3xffFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgLi0nID4qKio+PnwvPi8vPj48XFxcXFxcXFwqKnwvXFxcXHwqKio8PDw8PHxffF98XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICBcXFxcLi0nIFxcXFwqKio8PDw+Pi8vL1xcXFxcXFxcXFxcXCoqKioqKjw8Pj48Pj4qKioqKlxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXC0uLS4tPDw8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgXFxcXC0nXy5KLS0uPDw8PD4+PDwqKioqPj4vLy8oXFxcXHxcXFxcKXwoLy88PDwsXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAoICAgKXwoLScgICg+Pj48PCoqKio8XFxcXFxcXFwpXy4+PDw8PC1cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgLi1gLSdfKVxcXFwtLi0tLlxcXFw+Pj48KioqKiovL3x8PihcXFxcIChcXFxcXFxcXF8uXFxcXDw8PDwgLi1cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAuJyBfLi0nKClcXFxcYC4qKj4+Ly8qKioqPDw8Pj48PGAtYGAtYGAtYDw8Li0nIF9cIilcbiAgICAgICAgcHJpbnQoXCIgICAgIC4tLSdfLic+Pj4+PD4+YC5cXFxcKioqKGAuXy4tLjw8PDw8PChfX19fX2BgPC4nXy4tJyB8PFwiKVxuICAgICAgICBwcmludChcIiAgICAvLScgICA+Pjw8Pj4+Pj4vLzw+Pj4vfFxcXFwgfCAgLzw8Pj48fCAgICAgYC0uXy8gICAgICBMXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAtPj4uPD4+PD4+Pj4+L3x8IFxcXFx8Lid8PDw+XFxcXFxcXFx8ICAuLS0tLS0nfC5fICAgIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAuLS0uXyA+PjwuJyBcXFxcPj4+Pj4+Ly8vfHwgIHwgIHw8PD4+PHwuJyAgICAgICApLS0tLS0nYC5cIilcbiAgICAgICAgcHJpbnQoXCIgICB8ICAgXy4tLScgICAgfC8vLy8vLy9cXFxcXFxcXFxcXFwtLS0tLSc8Pj4+Pj49PVxcXFxcXFxcPD48Pj4+PjwgPT09Ojo9PT0+Pj48KioqKnwgLidgLmBfICggICBgLS4gICAuLS0nXCIpXG4gICAgICAgIHByaW50KFwiICAvICAgIC4nPj48Pj4pXyAtLT4+Pj49PT06Ojo6PT0+PioqKioqKnwvPj4+LyAgYC4gIC4tLS5gLS58XCIpXG4gICAgICAgIHByaW50KFwiIC8gICAgLz4+Pj4+Pj4nYCdgJ2AtYDw9PT06Ojo8PDwgKioqKiooXFxcXCAuLS48KCAgICktKCAgIClcIilcbiAgICAgICAgcHJpbnQoXCIvLid8IC8+Pj4+Pj4+Li0uLS4tLl9cXFxcfD4gPS8vfHxcXFxcXFxcXCoqKioqKi0nQC0tJz4+YC0nPDxcXFxcYC0nYC5fXCIpXG4gICAgICAgIHByaW50KFwiICAgfC8+Pj4+Pj4+LSdgJ2AnYC0uXFxcXFxcXFw+Pj09PDw8PCoqKi4nXFxcXCB8X3wpX3w8PDw8PDw8IFxcXFxfIGAtIGAuXCIpXG4gICAgICAgIHByaW50KFwiICAvID4+Pj4+Pi4tLi4nJ2AnYC0uXFxcXFxcXFwuLT4+Pj48PD4oICAvKFxcXFxcXFxcXFxcXC8vLyA8PDw8PD0gICAgXFxcXF8gLi0nXCIpXG4gICAgICAgIHByaW50KFwiIC8tJyA+Pj4tLS0tXFxcXCgoOjo6OikpKS8vIC8+PD4+Kip8ICAgKFxcXFxcXFxcXFxcXFxcXFwvLy88PDw8LS0tLlwiKVxuICAgICAgICBwcmludChcInwuJyAgPj4+fCB8IHwgfFxcXFxfXy4nLic+Pj4+PioqKiouJy8gKFxcXFxcXFxcXFxcXFxcXFwvLy8vPDw8PC1gLWBcIilcbiAgICAgICAgcHJpbnQoXCIgYCAgID4+PnwtfC18IHw+Pj4+Pj4+Pj4+KioqKiAuLS0uIC9fXFxcXFxcXFxcXFxcLy8vLzw8PHxffF98PDw8XCIpXG4gICAgICAgIHByaW50KFwiICAgICA+Pj58X3xffC8+Pjw+Pjw8PioqKioqdnYoICAgIFYgIGAuXFxcXFxcXFw8PDw+Pj58X3xffDw8PDxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgIC8vLy8+Pj4+PmAuPj4+PioqKioqKj4+PjxgLS0nXFxcXCAgIC88PDw8PD4+Pj4+PDw8PDw8PFwiKVxuICAgICAgICBwcmludChcIiAgICAgJycgLy8vPj4+Pj48PD4+KioqKio+Pj4+PDw8PDw8YC0nPDw8PDw8Pj48PDw+PDw8PDw8PFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAnJyAgICAtPj4+Pj48PD4vLy8+Pj4+Pjw8PDw8PFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXD48PDw8PD4+Pjw8PDxcXFxcXFxcXFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgIC8vLy88PD4+PDw8Pj4+Pjw8PDw+XFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcPj48XFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAnJyAvIC8vLy8vLy8vPj4+PDw8XFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXDwgIFxcXFxcXFxcXFxcXCBcXFxcXFxcXFxcXFxcXFxcXFxcXFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAvfHwgLi8vLy98fHxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgIChNTU1NTU1NTU1NTU1NTU1NTU1NKVwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICB8YC0tLS0uTU1NTU1NTU0uLS0tJ3xcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgYC0tLS5fX19fICAgX19fXy4tLS0nXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICB8ICAgICAgIFxcXCJcXFwiXFxcIiAgICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAoICAgICAgICAgICAgICAgICApXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgYC0tLS0uX19fX18uLS0tLSdcIilcblxuXG4gICAgICAgIHByaW50KFwiXFxuWW91IGZpbmQgdGhpcyB3ZWlyZCBsb29raW5nIHRyZWUgaW4gdGhlIG1pZGRsZSBvZiB0aGUgcGF0aCwgaXQgbG9va3MgdW5uYXR1cmFsLCBcXG55b3UgdHJ5IHdhbGtpbmcgYXJvdW5kIGl0IGJ1dCB0aGUgdHJlZSBibG9ja3MgeW91ciB3YXkuXCIpOztcblxuICAgICAgICBwcmludChcIlxcblxcbiBXaGF0IGRvIHlvdSBkbz9cIik7XG5cbiAgICAgICAgcHJpbnQoXCJcXG4oMSlUcnkga2lsbGluZyBpdCBcXG4oMilicnV0ZSBmb3JjZSB0aHJvdWdoIHRoZSB0cmVlIFxcbigzKXVzZSBhbiBpdGVtIFxcbig0KUdvIGJhY2sgdG8gdGhlIFJpZ2h0IHBhdGhcIik7XG5cbiAgICAgICAgaW5wdXQgPSBnZXRJbnB1dCgpO1xuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjFcIikge1xuICAgICAgICAgICAgc2NyZWVuID0gXCJkZWF0aFwiO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjJcIikge1xuICAgICAgICAgICAgc2NyZWVuID0gXCJkZWF0aFwiO1xuICAgICAgICB9XG5cblxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjNcIiAmJiB0cmVlSW1tb2JpbGl6ZXIgPT0gdHJ1ZSkge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcInRyZWUgcHV6emxlIGZpbmlzaGVkXCJcblxuXG4gICAgICAgIH0gZWxzZSBpZiAoaW5wdXQgPT0gXCIzXCIgJiYgdHJlZUltbW9iaWxpemVyID09IGZhbHNlKSB7XG4gICAgICAgICAgICBzY3JlZW4gPSBcIkNhbm5vdCB1c2UgaXRlbVwiXG5cblxuXG5cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjRcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcIlJpZ2h0IHBhdGggQ0hFQ0tcIlxuICAgICAgICB9XG5cbiAgICB9XG5cblxuICAgIGlmIChzY3JlZW4gPT0gXCJDYW5ub3QgdXNlIGl0ZW1cIikge1xuXG4gICAgICAgIHByaW50KFwiWW91IGNhbid0IHVzZSBhbnkgaXRlbXMgb24gdGhlIHRyZWUsIGdvIGFuZCBleHBsb3JlIE1pc3R5IEZvcmVzdCB0byBmaW5kIHNvbWUgaXRlbXNcIilcbiAgICAgICAgRnVuLnRocmVhZFNsZWVwKDIwMDApXG4gICAgICAgIHNjcmVlbiA9IFwidHJlZSBwdXp6bGVcIlxuICAgIH1cblxuICAgIGlmIChzY3JlZW4gPT0gXCJ0cmVlIHB1enpsZSBmaW5pc2hlZFwiKSB7XG5cbiAgICAgICAgcHJpbnQoXCJcXG4gICAgIC9cXFxcXCIpXG4gICAgICAgIHByaW50KFwiX19fXy9fIFxcXFxfX19fXCIpXG4gICAgICAgIHByaW50KFwiXFxcXCAgX19fXFxcXCBcXFxcICAvXCIpXG4gICAgICAgIHByaW50KFwiIFxcXFwvIC8gIFxcXFwvIC9cIilcbiAgICAgICAgcHJpbnQoXCIgLyAvXFxcXF9fL18vXFxcXFwiKVxuICAgICAgICBwcmludChcIi9fX1xcXFwgXFxcXF9fX19fXFxcXFwiKVxuICAgICAgICBwcmludChcIiAgICBcXFxcICAvXCIpXG4gICAgICAgIHByaW50KFwiICAgICBcXFxcL1wiKVxuXG4gICAgICAgIHByaW50KFwiXFxuWW91IHVzZSB0aGUgcG90aW9uIG9uIHRoZSB0cmVlLCB0aGUgcG90aW9uIHJlZmlsZWQgaXRzZWxmIGJ5IG1hZ2ljLiBUaGUgdHJlZSB2YW5pc2hlcyBpbnRvIGR1c3QgYW5kIGxlYXZlcyBiZWhpbmQgaXRzIHRyZWUgZXNzZW5jZVwiKTtcblxuICAgICAgICBwcmludChcIlxcblxcblwiKTtcblxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoMjAwMCk7XG5cbiAgICAgICAgdHJlZUVzc2VuY2UgPSB0cnVlO1xuXG5cblxuICAgICAgICBzY3JlZW4gPSBcInRyZWUgcHV6emxlXCI7XG4gICAgfVxuXG5cblxuXG5cbiAgICAvL2R1bmdlb25cblxuICAgIGlmIChzY3JlZW4gPT0gXCJ0cmVlIHB1enpsZVwiICYmIHRyZWVFc3NlbmNlID09IHRydWUgJiYgZHVuZ2VvbktleSA9PSBmYWxzZSAmJiBkdW5nZW9uR2F0ZSA9PSBmYWxzZSkge1xuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4uLi4uLi4uLi4uLiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAuOn4hNz9ZWTU1UFBQUFBQUFBCR0dHR0dQR0dQUFA1NTVZWUo/NyF+XjouICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgIC5+P1k1UFA1WUo3IX5eOjpeXjouLi43Ol43P0ohfjo/OjpeXl5efiEhP0pZNTVQUFBZSjdeLiAgICAgICAgICAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICB+SlBCQlA1SjogICAgICAgLjp+ISEhISEhSj9eLko1Ll4/SiEhfn4hIX46LiAgICAgIC5eWVBQQkJQWSEuICAgICAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgOkpHR0p+Sl4gfj8uICAuXn4hNz8/NyFeOi4uOl43WUpKNVlQN146Li4uOn43Pz83IX5eLiAgLj9+IF5KXj9QQlleICAgICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAuSiZHNzogIDohfn5eXn5+fiE3N34uICAgIDpeXjogICAhI0BKICAgLl5eOiAgICAufjc/N35+fl5efn4hOiAgOiFHJlkuICAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgNUA1Ol41OiAgICAuLjpeIUohIX5efl4uICEhLjdZLiAgOkImNyAgIEpKOl4/IC5efl5+ISFKN146Oi4gICAgXjVeOjVARy4gICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgfkA1Nzo6Oi4uOjpefn5+OjohOjchICAuXn4/Pzo6Oi46fiFeITc3Xi46OjohWX5eOiAgITc6ITo6fn5+Xjo6Li46Ol43P0BKICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIDdAUDVHQkdHR0JHUDVZWVlZNVA1NTU1WVk1NUdCQkdCR1BZNVA1UEdHQkdHRzU1WVlZNTU1UDVZWVlZNVBHR0JHR0JHNVBANSAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAhQD8uOi46Xl4uOjo6Xjo6Ojo6Xjo6OjpeXjouLjpeOi46LiFAWS46OjpeOjo6OjpeOjo6Ojo6Ojo6Ol46Ojo6XjouOi43QDUgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgIUA3IC4uLlk1Li4uLkc3IC4gIUc6IC4uUD8gLiBeQn4gLiBeQEogICAgWVkgICBeR14gICBZSiAgICFQLiAgLjU/ICAgIUA1ICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICFAWX5+fn5ZNX5+IX5HP35+fjdCIX5+flBKfn5+IUc3fn5+N0A1fn4hfjVZfn5+IUchfiF+NTV+IX4/R35+fn5QSn5+fkpANSAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAhQD8gICAgN0ogICAgNV4gICA6UCAgICBZISAgICBQOiAgIF5ASiAgICA/NyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICAhQDUgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgfkA/ICAgID9KICAgIDVeICAgOlAuICAgWSEgICAgUDogICBeQEogICAgPz8gICAuUC4gICA3PyAgIF41ICAgIEohICAgIUA1ICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIH5APyAgICA/SiAgICA1XiAgIDpQLiAgIFkhICAgIFA6ICAgOkBKICAgID8/ICAgLlAuICAgNz8gICBeNSAgICBKISAgICFANSAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICB+QD8gICAgP0ogICAgNV4gICA6UC4gICBZISAgICBQOiAgIDpAWSAgICA/PyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICB+QDUgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgfkBKICAgID9KICAgIDVeICAgOlAuICAgWSEgICAgUDogICA6QFkgICAgPz8gICAuUC4gICA3PyAgIF41ICAgIEohICAgfkA1ICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIF5ASiAgICA/SiAgICA1XiAgIDpQLiAgIFkhICAgIFA6ICAgOiZZICAgID8/ICAgLlAuICAgNz8gICBeNSAgICBKISAgIH5ANSAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICBeQEogICAgN0ogICAgNX4gICA6UC4uICBZISAgLiBQOiAgIDomWSAgICA/NyAgIC5QLiAgIDc/IC4gXjUgIC4gSiEgLiB+QDUgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgXkBKICAuOkpZOjogIDV+IC5eflBeOiAgWSEgIDpeR35eLiA6JjUgIC46Sj86LiAuUC4gLjo/WV4uIF41ICAuXjU/Oi4gfkA1ICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIF5AWSAgICA1RyAgICA1XiAgIDcmXiAgIFkhICAgXiY/ICAgLiY1ICAgIDVQICAgLlAuICAgUFAgICBeNSAgIC5CNSAgIH5ANSAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICBeQFkgIC46WTU6LiAgNX4gLjohR346LiBZISAuOl5HITouIC4mNSAgLjo1NTouIC5QLiAuOlk1Oi4gXjUgIDpeNUo6LiB+QDUgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgXkBZICA6Lj9KLjogIDV+IC4uOlAuLi4gWSEgLi4gUDouLiAuJjUgIDouPz8uOiAuUC4gOi43PyAuIF41ICAuIEohLi4gfkBQICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIF5AWSAgICA/SiAgICA1XiAgIDpQLiAgIFkhICAgIFA6ICAgLiY1ICAgID8/ICAgLlAuICAgNz8gICBeNSAgICBKISAgIH5AUCAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICA6QDUgICAgP0ogICAgNV4gICA6UC4gICBZISAgICBQOiAgIC4jNSAgICA/PyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICB+QFAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgOkA1ICAgID9KICAgIDVeICAgOlAuICAgWSEgICAgUDogICAuI1AgICAgPz8gICAuUC4gICA3PyAgIF41ICAgIEohICAgfkBQICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIDpANSAgICA/SiAgICA1XiAgIDpQLiAgIFkhICAgIFA6ICAgLiNQICAgID8/ICAgLlAuICAgNz8gICBeNSAgICBKISAgIH5AUCAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICA6JlAgICAgP0ogICAgNV4gICA6UC4gICBZISAgICBQOiAgIC4jUCAgICA/PyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICBeQFAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICA6JlAgICAgN0ogICAgNV4gICA6UCAgICBZISAgICBQOiAgICAjUCAgICA/NyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICBeQFAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgOiZHOjo6OkpZOjo6OlAhOjo6fkdeOjo6NTc6OjpeR346Ojo6I0cuLjouSj8uOjpeR146Oi4/Si46LiFQLjo6Llk3LjouIUBQICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIDomR34hIX5ZNX4hISFHP34hfjdHISEhflBKfiEhIUc3fiFCJkAmQiNKfjVZISEhN0c3ISEhWTUhISE/RyEhISFQSiEhIT9AUCAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAuJlAgICAgP0ogICAgNV4gICAuUCAgICBZfiAgICBQOiAuJkBAJkBANyA/NyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICBeQFAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgLiNCNzc3IUpKITc3IVA1NyE3WVA/Sko3NTVKNzc3NTchN1BHJiZCQkohWUohISE3R0o3IT81WTdKNz9QSjchIVk/ISEhSkBQICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIC4jRyAgIDo6On5eIDc3Oi5+Xl5QIz8ufjo6IT8uLl5+Ol4uIEJHICAuOjo6XjouPyE6On46N0JHXl5eOn5KXi5efjpeOl5AUCAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAuI0cgICAuN1lKNyE1ICAuSiF+Skc3flkhICA/ITc3WUohICBCRyAgIC43WT83IUogIH5ZfiFQNX43WS4gXkp+N0pKNy5eQFAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAuI0cgIDohSj9KUEImSi4gICAgOkogLiAgIF5HQkc1Nzc/fjpCRyAgOn5KP1lHIyMhICAgLiA3ISAuICAuSiNCUD83Sn5+QFAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAuI0cuN346OjogLjo3QkJZN15eXl5eOl43NSNKXi4gLl46OiEjRy43fjo6Oi4ufkojRz9+Xl5eOjo6fkpCUCE6IC5eOjo3QFAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAuI0deSiAuPzchICAgID83N1BKXl5eNTUhWV4gICAuSjchIF4mRzpKIC4/N34gICA6WTdKUCFeXjdQSj8/ICAgID83NyB+QFAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAuQkIgfjU1NTU3NzcuIDo/IF5+LiA6Xi46PyAgOj83SjVQUEpCQiB+WTU1WTc/IS4gIX4gfl4gIF5eID86IC4hNz81UFA1QFAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgQkI6P35ePz8/Li4gIF43ITUhICBeWT86Si4gIC5eSj8hOn4mQi43IX4/PzcuLiAgISE/WTogLjdZXjdeICAuOko/Nzo3QFAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgQkI6Sjogfn4uICAuIUI1SjchIX5+IT9ZUFB+LiAgOn46LiEmQi5KLiAhITogIC43R1lKNyEhfiE/SjVHNy4gIDp+XiAhQFAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgIEJCLi5+fn5+fjc1RyNKXi4gICB+LiAgIDo3QkI1PyEhfn5eR0IgLn5+fn5+NzVCIz9eLiAgLl4gICA6IUdCUD8hIX5+ISZHICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgQiMuICAuNzc/UFlZfiAgXn5eflAhXn5eICB+NTVKSj9eICBHIyAgIC43N0pHSjVeICBeXl43WV5efi4gLjU1WUo/fiA6JkcgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgQiMgICAuIUo3ISAhISAgNzcuWSY1LiE/ICA3ITp+N146ICBHIyAgIC4hWTchID9eIC5Kfl5CI346Sl4gOko6fjd+XiA6JkcgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgIEcmNzc3Pzc3Sj83N1k1Sjc/WVBQUFk/N0o1WSEhNyEhISEhQiMhISE/NzdKPyE3NVk3Nzc1R0dQPzc3WVBKNz8/Nz8/SkBHICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgRyM3Nzc3NzchNzc3ITc3Nzc3ISEhNzc3NzchNzc3Nzc3NzdQRzc3NyEhISEhISEhISEhISF+fiEhISEhfn5+fn5+fn4hQjVcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgOjogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBeXiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLiBcIilcblxuICAgICAgICBwcmludChcIllvdSBmaW5kIGFuIGVudHJhbmNlIHRvIGEgY2xvc2VkIG1ldGFsIGdhdGUsIFRoaXMgZ2F0ZSBjb3VsZCBsZWFkIHNvIHNvbWV3aGVyZSwgYnV0IGl0IHJlcXVpcmVzIGEga2V5IHRvIG9wZW4gaXQuXCIpXG5cbiAgICAgICAgcHJpbnQoXCJcXG4oMSlXYWxrIGF3YXlcIilcblxuICAgICAgICBpbnB1dCA9IGdldElucHV0KCk7XG5cbiAgICAgICAgaWYgKGlucHV0ID09IFwiMVwiKSB7XG5cbiAgICAgICAgICAgIHNjcmVlbiA9IFwiUmlnaHQgcGF0aCBDSEVDS1wiO1xuICAgICAgICB9XG5cblxuXG4gICAgfVxuXG5cbiAgICBpZiAoc2NyZWVuID09IFwidHJlZSBwdXp6bGVcIiAmJiB0cmVlRXNzZW5jZSA9PSB0cnVlICYmIGR1bmdlb25LZXkgPT0gdHJ1ZSAmJiBkdW5nZW9uR2F0ZSA9PSBmYWxzZSkge1xuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4uLi4uLi4uLi4uLiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAuOn4hNz9ZWTU1UFBQUFBQUFBCR0dHR0dQR0dQUFA1NTVZWUo/NyF+XjouICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgIC5+P1k1UFA1WUo3IX5eOjpeXjouLi43Ol43P0ohfjo/OjpeXl5efiEhP0pZNTVQUFBZSjdeLiAgICAgICAgICAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICB+SlBCQlA1SjogICAgICAgLjp+ISEhISEhSj9eLko1Ll4/SiEhfn4hIX46LiAgICAgIC5eWVBQQkJQWSEuICAgICAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgOkpHR0p+Sl4gfj8uICAuXn4hNz8/NyFeOi4uOl43WUpKNVlQN146Li4uOn43Pz83IX5eLiAgLj9+IF5KXj9QQlleICAgICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAuSiZHNzogIDohfn5eXn5+fiE3N34uICAgIDpeXjogICAhI0BKICAgLl5eOiAgICAufjc/N35+fl5efn4hOiAgOiFHJlkuICAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgNUA1Ol41OiAgICAuLjpeIUohIX5efl4uICEhLjdZLiAgOkImNyAgIEpKOl4/IC5efl5+ISFKN146Oi4gICAgXjVeOjVARy4gICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgfkA1Nzo6Oi4uOjpefn5+OjohOjchICAuXn4/Pzo6Oi46fiFeITc3Xi46OjohWX5eOiAgITc6ITo6fn5+Xjo6Li46Ol43P0BKICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIDdAUDVHQkdHR0JHUDVZWVlZNVA1NTU1WVk1NUdCQkdCR1BZNVA1UEdHQkdHRzU1WVlZNTU1UDVZWVlZNVBHR0JHR0JHNVBANSAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAhQD8uOi46Xl4uOjo6Xjo6Ojo6Xjo6OjpeXjouLjpeOi46LiFAWS46OjpeOjo6OjpeOjo6Ojo6Ojo6Ol46Ojo6XjouOi43QDUgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgIUA3IC4uLlk1Li4uLkc3IC4gIUc6IC4uUD8gLiBeQn4gLiBeQEogICAgWVkgICBeR14gICBZSiAgICFQLiAgLjU/ICAgIUA1ICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICFAWX5+fn5ZNX5+IX5HP35+fjdCIX5+flBKfn5+IUc3fn5+N0A1fn4hfjVZfn5+IUchfiF+NTV+IX4/R35+fn5QSn5+fkpANSAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAhQD8gICAgN0ogICAgNV4gICA6UCAgICBZISAgICBQOiAgIF5ASiAgICA/NyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICAhQDUgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgfkA/ICAgID9KICAgIDVeICAgOlAuICAgWSEgICAgUDogICBeQEogICAgPz8gICAuUC4gICA3PyAgIF41ICAgIEohICAgIUA1ICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIH5APyAgICA/SiAgICA1XiAgIDpQLiAgIFkhICAgIFA6ICAgOkBKICAgID8/ICAgLlAuICAgNz8gICBeNSAgICBKISAgICFANSAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICB+QD8gICAgP0ogICAgNV4gICA6UC4gICBZISAgICBQOiAgIDpAWSAgICA/PyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICB+QDUgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgfkBKICAgID9KICAgIDVeICAgOlAuICAgWSEgICAgUDogICA6QFkgICAgPz8gICAuUC4gICA3PyAgIF41ICAgIEohICAgfkA1ICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIF5ASiAgICA/SiAgICA1XiAgIDpQLiAgIFkhICAgIFA6ICAgOiZZICAgID8/ICAgLlAuICAgNz8gICBeNSAgICBKISAgIH5ANSAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICBeQEogICAgN0ogICAgNX4gICA6UC4uICBZISAgLiBQOiAgIDomWSAgICA/NyAgIC5QLiAgIDc/IC4gXjUgIC4gSiEgLiB+QDUgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgXkBKICAuOkpZOjogIDV+IC5eflBeOiAgWSEgIDpeR35eLiA6JjUgIC46Sj86LiAuUC4gLjo/WV4uIF41ICAuXjU/Oi4gfkA1ICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIF5AWSAgICA1RyAgICA1XiAgIDcmXiAgIFkhICAgXiY/ICAgLiY1ICAgIDVQICAgLlAuICAgUFAgICBeNSAgIC5CNSAgIH5ANSAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICBeQFkgIC46WTU6LiAgNX4gLjohR346LiBZISAuOl5HITouIC4mNSAgLjo1NTouIC5QLiAuOlk1Oi4gXjUgIDpeNUo6LiB+QDUgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgXkBZICA6Lj9KLjogIDV+IC4uOlAuLi4gWSEgLi4gUDouLiAuJjUgIDouPz8uOiAuUC4gOi43PyAuIF41ICAuIEohLi4gfkBQICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIF5AWSAgICA/SiAgICA1XiAgIDpQLiAgIFkhICAgIFA6ICAgLiY1ICAgID8/ICAgLlAuICAgNz8gICBeNSAgICBKISAgIH5AUCAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICA6QDUgICAgP0ogICAgNV4gICA6UC4gICBZISAgICBQOiAgIC4jNSAgICA/PyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICB+QFAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgOkA1ICAgID9KICAgIDVeICAgOlAuICAgWSEgICAgUDogICAuI1AgICAgPz8gICAuUC4gICA3PyAgIF41ICAgIEohICAgfkBQICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIDpANSAgICA/SiAgICA1XiAgIDpQLiAgIFkhICAgIFA6ICAgLiNQICAgID8/ICAgLlAuICAgNz8gICBeNSAgICBKISAgIH5AUCAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICA6JlAgICAgP0ogICAgNV4gICA6UC4gICBZISAgICBQOiAgIC4jUCAgICA/PyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICBeQFAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICA6JlAgICAgN0ogICAgNV4gICA6UCAgICBZISAgICBQOiAgICAjUCAgICA/NyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICBeQFAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgOiZHOjo6OkpZOjo6OlAhOjo6fkdeOjo6NTc6OjpeR346Ojo6I0cuLjouSj8uOjpeR146Oi4/Si46LiFQLjo6Llk3LjouIUBQICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIDomR34hIX5ZNX4hISFHP34hfjdHISEhflBKfiEhIUc3fiFCJkAmQiNKfjVZISEhN0c3ISEhWTUhISE/RyEhISFQSiEhIT9AUCAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAuJlAgICAgP0ogICAgNV4gICAuUCAgICBZfiAgICBQOiAuJkBAJkBANyA/NyAgIC5QLiAgIDc/ICAgXjUgICAgSiEgICBeQFAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgLiNCNzc3IUpKITc3IVA1NyE3WVA/Sko3NTVKNzc3NTchN1BHJiZCQkohWUohISE3R0o3IT81WTdKNz9QSjchIVk/ISEhSkBQICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgIC4jRyAgIDo6On5eIDc3Oi5+Xl5QIz8ufjo6IT8uLl5+Ol4uIEJHICAuOjo6XjouPyE6On46N0JHXl5eOn5KXi5efjpeOl5AUCAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAuI0cgICAuN1lKNyE1ICAuSiF+Skc3flkhICA/ITc3WUohICBCRyAgIC43WT83IUogIH5ZfiFQNX43WS4gXkp+N0pKNy5eQFAgICAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAuI0cgIDohSj9KUEImSi4gICAgOkogLiAgIF5HQkc1Nzc/fjpCRyAgOn5KP1lHIyMhICAgLiA3ISAuICAuSiNCUD83Sn5+QFAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAuI0cuN346OjogLjo3QkJZN15eXl5eOl43NSNKXi4gLl46OiEjRy43fjo6Oi4ufkojRz9+Xl5eOjo6fkpCUCE6IC5eOjo3QFAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAuI0deSiAuPzchICAgID83N1BKXl5eNTUhWV4gICAuSjchIF4mRzpKIC4/N34gICA6WTdKUCFeXjdQSj8/ICAgID83NyB+QFAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAuQkIgfjU1NTU3NzcuIDo/IF5+LiA6Xi46PyAgOj83SjVQUEpCQiB+WTU1WTc/IS4gIX4gfl4gIF5eID86IC4hNz81UFA1QFAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgQkI6P35ePz8/Li4gIF43ITUhICBeWT86Si4gIC5eSj8hOn4mQi43IX4/PzcuLiAgISE/WTogLjdZXjdeICAuOko/Nzo3QFAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgQkI6Sjogfn4uICAuIUI1SjchIX5+IT9ZUFB+LiAgOn46LiEmQi5KLiAhITogIC43R1lKNyEhfiE/SjVHNy4gIDp+XiAhQFAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgIEJCLi5+fn5+fjc1RyNKXi4gICB+LiAgIDo3QkI1PyEhfn5eR0IgLn5+fn5+NzVCIz9eLiAgLl4gICA6IUdCUD8hIX5+ISZHICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgQiMuICAuNzc/UFlZfiAgXn5eflAhXn5eICB+NTVKSj9eICBHIyAgIC43N0pHSjVeICBeXl43WV5efi4gLjU1WUo/fiA6JkcgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgQiMgICAuIUo3ISAhISAgNzcuWSY1LiE/ICA3ITp+N146ICBHIyAgIC4hWTchID9eIC5Kfl5CI346Sl4gOko6fjd+XiA6JkcgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgIEcmNzc3Pzc3Sj83N1k1Sjc/WVBQUFk/N0o1WSEhNyEhISEhQiMhISE/NzdKPyE3NVk3Nzc1R0dQPzc3WVBKNz8/Nz8/SkBHICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgRyM3Nzc3NzchNzc3ITc3Nzc3ISEhNzc3NzchNzc3Nzc3NzdQRzc3NyEhISEhISEhISEhISF+fiEhISEhfn5+fn5+fn4hQjVcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgOjogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBeXiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLiBcIilcblxuICAgICAgICBwcmludChcIllvdSBmaW5kIGFuIGVudHJhbmNlIHRvIGEgY2xvc2VkIG1ldGFsIGdhdGUsIFRoaXMgZ2F0ZSBjb3VsZCBsZWFkIHNvIHNvbWV3aGVyZSwgYnV0IGl0IHJlcXVpcmVzIGEga2V5IHRvIG9wZW4gaXQuXCIpXG5cbiAgICAgICAgcHJpbnQoXCJcXG4oMSlXYWxrIGF3YXlcXG4oMilVc2Uga2V5XCIpXG5cbiAgICAgICAgaW5wdXQgPSBnZXRJbnB1dCgpO1xuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjFcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcIlJpZ2h0IHBhdGggQ0hFQ0tcIjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjJcIikge1xuXG4gICAgICAgICAgICBkdW5nZW9uR2F0ZSA9IHRydWVcbiAgICAgICAgICAgIHNjcmVlbiA9IFwidHJlZSBwdXp6bGVcIlxuICAgICAgICB9XG5cblxuICAgIH1cblxuICAgIGlmIChzY3JlZW4gPT0gXCJ0cmVlIHB1enpsZVwiICYmIHRyZWVFc3NlbmNlID09IHRydWUgJiYgZHVuZ2VvbktleSA9PSB0cnVlICYmIGR1bmdlb25HYXRlID09IHRydWUpIHtcblxuXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi46Ojo6Ojo6Ojo6Ojo6Li4uLi4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgIDpeITdKWTU1UFBQUFBQUFA1UEJHR0dHR1BHR1BQUFBQUDU1WVlKPzd+XjouICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgOiFKUFBQNVlKNyF+XjouLi46Oi4uIDdeLiE3SiF+IDc6LjpeOi46Xn4hNz9KWTVQUDU1SiFeLiAgICAgICAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAufllQQkI1Skp+ICAgICAgLjpeITc3ISE3N0pZIS43UC5+Sko3ISEhITc3fl4uICAgICAgOllZWUdCRzU/XiAgICAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgOkpHUD9eITcgOjdeIC46Xn4hNz83IV46LiAgLjp+PzVKUDU1ITouICAgLjp+Nz8/IX5eOi4gLjd+IH4/LiFZQlB+ICAgICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICA/JkI/Xi4gIF4hfl5+fn5+IT83fjogICAgXn5+Xi4gIDpCQFkgICA6fn5+LiAgIC5eNz83fn5+fn5+IX4uICBeIVBAUDogICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgP0BCOiBKNyAgICAgLjpeIVkhfn46Xn5eLn43IH5ZOiAgOjUjWSAgIDdKLjpKLjp+fjpeIX5KN35eLiAgICAgXlk6LjVAQjogICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAuQkIhIX5eXl5+fiEhIX5eOiF+IT8uLi5efjdZIX5eXn4hNzohIT8hfl5efj9ZIX46Li4hP34hOjp+ISEhfn5eXl5eISE/QD8gICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAuIyZCR1BQUFBHUFA1NTU1NTU1NTU1NTU1NTU1R0dHR0dQNTU1WTVQR0dHR1A1NTU1NTU1NTU1NTU1NTU1UFBQUEcmI0IjQEogICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAuQkBAJkc/IV4uICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLl4/WVA1JkBAQEogICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAuQkBAQEI6ITdKSjd+OiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuXjdZNVk/IV5+R0BAQEogICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAuQkBAQEIhWTohOiE/WVlKfiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQQjchfjd+NUpHQkBAQEogICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgIEJAQEBHN0JZQko1Sl43I1AgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQkJZWUdCSkchUDVAQEBZICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICBCQEBAUF41XjU/UEJZQiY1ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdCUD81NX41XlBZQEBAWSAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgQkBAQFB+NX5ZN0pHflAjNSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHRzUhUDUhUF5QWUBAQFkgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgIEdAQEA1IVl+WT9KR35QI1kgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUEI1IVA1IVBeUEpAQEBZICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICBHQEBANTdKIUpKSlB+UCNZICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBCNX5QWSFQXlA/QEBAWSAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgR0BAQDU/SjdKSkpQIVAjSiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA1QlB+UFkhNV41N0BAQFkgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgIEdAQEA1Pz8/P1lKNSFQJj8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgNSM1flBZPzUhR1kmQEBZICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICBHQEBAR0I1SllHUDU/UCY/ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFkmI1lHQkc1NyNQJkBAWSAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgUEBAQDVCSkpKI0c1UCNANyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBKJiNKUFBQWSFHNSNAQFkgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgIFBAQEBQIz9ZSiNQWVBCQDcgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSkAjWVBHRzU3RzUjQEBZICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgIFBAQEBZUDdZN0dQSjVCQCEgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyZQITVZSkohSjdCQEBZICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICBQQEBAPzVeNX41NTc/UEB+ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID9AUCFZWVk/N0o/QkBANSAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICBQQEBAP1BeNX41UCFKUEB+ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDdAUDdKNVk3Pz8/R0BANSAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICA1QEBAP1BeNX41UCFZUEBeICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDdAUDdKNVk3PzdKR0BANSAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgNUBAQD9QXlB+NVB+WUdAXiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhQFA/PzVZIUo3SlBAQDUgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgIDVAQEA3UDpQfjVQXllHJl4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfkBHSjdQWSFKIUo1QEA1ICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICA1QEBAN1BeUCFQRzdQQiY6ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH5AQlBZQkdZUEo1UEBANSAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgWUBAQDVCSkJKR0IhUEImOiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBeQEJZflA1flA3UFBAQDUgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgIFlAQCY3NV41flBHIVAjIy4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXkAmWUdCQkpQITVZQEA1ICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICBZQEAmSlBZQkcmUEc1QCMuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF4mQCNHUEBQQlBKR0BANSAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgWUBAJllKQjUjQDVCQEAjLiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6JkBAUFkjRzUjR0ImQFAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgIEpAQCZCQCM/NTU/JkJAQi4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiYjUCZKPyFZQEAmJkBQICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICBKQEBAJiMmNT9ZI0dQQEIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4jQDVHJllQJjVKI0BAUCAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgSkBAQDU3NSZZWSZZQkBHICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuI0BQUFA3NUI3NUdAQFAgICAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgIEpAQCZHQj9CPzdCWUJARyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLkJAWVBCNzVHWSNCQEBQICAgICAgICAgICAgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICA/QEBAI0JKIzVKJlA1QFAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5CQFAmUEomQkpCI0BAUCAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgP0BAJlBHWUBQP1kmI0BQICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQkAmUCE/WSY1WVBAQFAgICAgICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgP0BAJllKI1A/NT9HQkA1ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR0BQUEcmWVAmUCMmQFAgICAgICAgICAgIFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgID9AQCZCQCNZIyZHQkcmSiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH5ZRyZCQFBZQEAmJkBQICAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgP0BAJiMjI1lCQCNHPzogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuITUjIyNQWUJAQFAgICAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICA3QEAmWVkjJkc/OiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC43UCNCI0BAUCAgICAgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgN0BAQCZHPzogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6N1AmQEcgICBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICA3QEI/XiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF5KSiAgIFwiKVxuXG4gICAgICAgIHByaW50KFwiVGhlIGR1bmdlb24gZ2F0ZSBpcyBvcGVuLCB5b3UgY2FuIGVudGVyIHRvIHNlZSB3aGF0J3MgaW5zaWRlLlwiKVxuXG4gICAgICAgIHByaW50KFwiXFxuKDEpV2FsayBhd2F5ICgyKUdvIGluXCIpXG5cbiAgICAgICAgaW5wdXQgPSBnZXRJbnB1dCgpO1xuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjFcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcIlJpZ2h0IHBhdGggQ0hFQ0tcIjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjJcIikge1xuXG4gICAgICAgICAgICBzY3JlZW4gPSBcIkR1bmdlb25cIlxuICAgICAgICB9XG5cbiAgICB9XG5cblxuICAgIGlmIChzY3JlZW4gPT0gXCJEdW5nZW9uXCIgJiYgbWlzdEdhdXJkaWFuQmVhdGVuID09IGZhbHNlKSB7XG5cbiAgICAgICAgcHJpbnQoXCJcXG4gICAgICAgICAuLS0uXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAvLi0tLlxcXFxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgIHw9PT09fFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgfGA6OmB8XCIpXG4gICAgICAgIHByaW50KFwiICAgIC4tO2BcXFxcLi4uLi9gOy0uXCIpXG4gICAgICAgIHByaW50KFwiICAgLyAgfC4uLjo6Li4ufCAgXFxcXFwiKVxuICAgICAgICBwcmludChcIiAgfCAgIC8nJyc6OicnJ1xcXFwgICB8XCIpXG4gICAgICAgIHByaW50KFwiICA7LS0nXFxcXCAgIDo6ICAgL1xcXFwtLTtcIilcbiAgICAgICAgcHJpbnQoXCIgIDxfXz4sPi5fOjpfLjwsPF9fPlwiKVxuICAgICAgICBwcmludChcIiAgfCAgfC8gICBeXiAgIFxcXFx8ICB8XCIpXG4gICAgICAgIHByaW50KFwiICBcXFxcOjovfCAgICAgICAgfFxcXFw6Oi9cIilcbiAgICAgICAgcHJpbnQoXCIgIHx8fFxcXFx8ICAgICAgICB8L3x8fFwiKVxuICAgICAgICBwcmludChcIiAgJycnIHxfX18vXFxcXF9fX3wgJycnXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgIFxcXFxfIHx8IF8vXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgIDxfID48IF8+XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgIHwgIHx8ICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgIHwgIHx8ICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgX1xcXFwuOnx8Oi4vX1wiKVxuICAgICAgICBwcmludChcIiAgICAgL19fX18vXFxfX19fXFxcXFwiKVxuXG4gICAgICAgIHByaW50KFwiXFxuWW91IHNsb3dseSBzdGVwIGludG8gdGhlIGR1bmdlb24sIHRoZSBnYXRlIGJlaGluZCB5b3UgY2xvc2VzIGFuZCByaWdodCBpbiBmcm9udCBvZiB5b3UgaXMgdGhlIE1pc3QgR3VhcmRpYW4uIFxcblRoZSBNaXN0IGd1YXJkaWFuIGh1bnRzIGFuZCBraWxscyB1bndhbnRlZCB0cmF2ZWxsZXJzIHRoYXQgY29tZSBpbnRvIHRoZSBmb3Jlc3QuIFwiKVxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoMzAwMClcblxuICAgICAgICBwcmludChcIk5PVEU6IFRoZSBNaXN0IEd1YXJkaWFuIGRlYWxzIDM1IGRhbWFnZSBldmVyeSBhdHRhY2sgYnV0IGhhcyB0ZXJyaWJsZSBhY2N1cmFjeSBhbmQgaGFzIDYwMCBoZWFsdGguXCIpO1xuXG4gICAgICAgIHByaW50KFwiXFxuKEhhcyBhIDUwJSBjaGFuY2Ugb2YgaGl0dGluZyB5b3UpXCIpO1xuXG4gICAgICAgIGNvdW50ID0gMFxuXG4gICAgICAgIHBsYXllckhlYWx0aCA9IG1heFBsYXllckhlYWx0aDtcblxuICAgICAgICBGdW4udGhyZWFkU2xlZXAoMzAwMClcblxuICAgICAgICBzY3JlZW4gPSBcIk1pc3QgR3VhcmRpYW4gQm9zc1wiXG5cbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwiRHVuZ2VvblwiICYmIG1pc3RHYXVyZGlhbkJlYXRlbiA9PSB0cnVlKSB7XG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9fX19fX19fX19fX19fX19fX19fX19fICAgICAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8ICBfX19fX19fXyAgIF9fX19fX19fICB8ICAgICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHwgfCAgICAgICAgfCB8ICAgIF9fXyB8IHwgICAgIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfCB8ICAgICAgICB8IHwgICwnLC4oJ3wgfCAgICAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8IHwgICAgICAgIHwgfCA6ICAuJyAgfCB8ICAgICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHwgfCAgICAgICAgfCB8IDopIF8gICh8IHwgICAgIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfCB8ICAgICAgICB8IHwgIGA6XylfLHwgfCAgICAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8IHxfX19fX19fX3wgfF9fX19fX19ffCB8ICAgICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHwgIF9fX19fX19fICAgX19fX19fX18gIHwgICAgIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfCB8ICAgICAgICB8IHwgICAgICAgIHwgfCAgICAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8IHwgICAgICAgIHwgfCAgICAgICAgfCB8ICAgICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHwgfCAgICAgICAgfCB8ICAgICAgICB8IHwgICAgIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfCB8ICAgICAgICB8IHwgICAgICAgIHwgfCAgICAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8IHwgICAgICAgIHwgfCAgICAgICAgfCB8ICAgICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHwgfF9fX19fX19ffCB8X19fX19fX198IHwgICAgIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfF9fX19fX19fX19fX19fX19fX19fX19ffCAgICAgfFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8XCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19ffFwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYC5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgLlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYC5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYC5cIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAgICAgICAgICAuLjo6Ojo6Ojo6Ojo6OicgLjo6Ojo6Ojo6Ojo6Ojo6OiAgICAgICAgICAgICAgICAgICBgLlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgICAgICAgICAgLi46Ojo6Ojo6Ojo6Ojo6OjonIC46Ojo6Ojo6Ojo6Ojo6OjonICAgICAgICAgICAgICAgICAgICBgXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgICAgICAgIC4uOjo6Ojo6Ojo6Ojo6Ojo6OjonIC46Ojo6Ojo6Ojo6Ojo6Ojo6OlwiKVxuICAgICAgICBwcmludChcIiAgICAgICAgIC4uOjo6Ojo6Ojo6Ojo6Ojo6Ojo6OjonIC46Ojo6Ojo6Ojo6Ojo6Ojo6OidcIilcbiAgICAgICAgcHJpbnQoXCIgICAgIC4uOjo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OicgLjo6Ojo6Ojo6Ojo6Ojo6Ojo6OjpcIilcbiAgICAgICAgcHJpbnQoXCIgLi46Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6JyAuOjo6Ojo6Ojo6Ojo6Ojo6Ojo6OidcIilcbiAgICAgICAgcHJpbnQoXCIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLiAgLi4uLi4uLi4uLi4uLi4uLi4uLi4uLlwiKVxuICAgICAgICBwcmludChcIjo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OjonIC46Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OjonXCIpXG4gICAgICAgIHByaW50KFwiOjo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OjonIC46Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OlwiKVxuICAgICAgICBwcmludChcIjo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OjonIC46Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OidcIilcbiAgICAgICAgcHJpbnQoXCI6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OicgLjo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OjpcIilcbiAgICAgICAgcHJpbnQoXCI6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6JyAuOjo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OicgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIilcblxuXG4gICAgICAgIHByaW50KFwiXFxuaGVyZSBub3RoaW5nIHdvcnRoIHNlZWluZyBoZXJlLlwiKVxuXG4gICAgICAgIHByaW50KFwiXFxuKDEpR28gYmFja1wiKVxuXG4gICAgICAgIGlucHV0ID0gZ2V0SW5wdXQoKTtcblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIxXCIpIHtcblxuICAgICAgICAgICAgc2NyZWVuID0gXCJ0cmVlIHB1enpsZSBDSEVDS1wiXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWlzdCBHdWFyZGlhbiBCb3NzXCIgJiYgcGxheWVySGVhbHRoID4gMCAmJiBtaXN0R3VhcmRpYW5IZWFsdGggPiAwKSB7XG5cbiAgICAgICAgbWlzdEd1YXJkaWFuQXR0YWNrUmFuZG9tID0gTWF0aC5yYW5kb20oKTtcblxuICAgICAgICBub3JtYWxBdHRhY2sgPSBzdHJlbmd0aCAqIDAuMVxuICAgICAgICBzdHJvbmdBdHRhY2sgPSBzdHJlbmd0aCAqIDAuMjVcbiAgICAgICAgaGVhbCA9IHN0cmVuZ3RoICogMC4xXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG4gICAgICAgIHByaW50KFwiXFxuICAgICAgXywuXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgLGAgLS4pXCIpXG4gICAgICAgIHByaW50KFwiICAgICAoIF8vLVxcXFxcXFxcLS5fXCIpXG4gICAgICAgIHByaW50KFwiICAgIC8sfGAtLS5fLC1efCAgICAgICAgICAgICxcIilcbiAgICAgICAgcHJpbnQoXCIgICAgXFxcXF98IHxgLS5fL3x8ICAgICAgICAgICwnfFwiKVxuICAgICAgICBwcmludChcIiAgICAgIHwgIGAtLCAvIHwgICAgICAgICAvICAvXCIpXG4gICAgICAgIHByaW50KFwiICAgICAgfCAgICAgfHwgfCAgICAgICAgLyAgL1wiKVxuICAgICAgICBwcmludChcIiAgICAgICBgci0uX3x8LyAgIF9fICAgLyAgL1wiKVxuICAgICAgICBwcmludChcIiAgIF9fLC08XyAgICAgKWAtLyAgYC4vICAvXCIpXG4gICAgICAgIHByaW50KFwiICAnICBcXFxcICAgYC0tLScgICBcXFxcICAgLyAgL1wiKVxuICAgICAgICBwcmludChcIiAgICAgIHwgICAgICAgICAgIHwuLyAgL1wiKVxuICAgICAgICBwcmludChcIiAgICAgIC8gICAgICAgICAgIC8vICAvXCIpXG4gICAgICAgIHByaW50KFwiICBcXFxcXy8nIFxcXFwgICAgICAgICB8LyAgL1wiKVxuICAgICAgICBwcmludChcIiAgIHwgICAgfCAgIF8sXi0nLyAgL1wiKVxuICAgICAgICBwcmludChcIiAgIHwgICAgLCBgYCAgKFxcXFwvICAvX1wiKVxuICAgICAgICBwcmludChcIiAgICBcXFxcLC4tPi5fICAgIFxcXFxYLT0vXlwiKVxuICAgICAgICBwcmludChcIiAgICAoICAvICAgYC0uXy8vXmBcIilcbiAgICAgICAgcHJpbnQoXCIgICAgIGBZLS5fX19fKF9ffVwiKVxuICAgICAgICBwcmludChcIiAgICAgIHwgICAgIHtfXylcIilcbiAgICAgICAgcHJpbnQoXCIgICAgICAgICAgICAoKVwiKVxuXG5cblxuXG4gICAgICAgIGlmIChtaXN0R3VhcmRpYW5BdHRhY2tSYW5kb20gPiAwLjUwICYmIGNvdW50ID4gMCkge1xuXG4gICAgICAgICAgICBwcmludChcIlxcbihNaXN0IEd1YXJkaWFuIGhhcyBkZWFsdFwiLCAzNSwgXCJkYW1hZ2UgdG8geW91KVwiKVxuXG4gICAgICAgICAgICBwbGF5ZXJIZWFsdGggPSBwbGF5ZXJIZWFsdGggLSAzNTtcblxuXG4gICAgICAgIH0gZWxzZSBpZiAobWlzdEd1YXJkaWFuQXR0YWNrUmFuZG9tIDw9IDAuNTApIHtcbiAgICAgICAgICAgIHByaW50KFwiXFxuKE1pc3QgR3VhcmRpYW4gTWlzc2VkKVwiKVxuXG4gICAgICAgIH1cblxuXG5cblxuICAgICAgICBwcmludChcIlxcblxcbnx8WW91ciBoZWFsdGggaXNcIiwgcGxheWVySGVhbHRoICsgXCJ8fFwiKVxuXG5cbiAgICAgICAgcHJpbnQoXCJcXG5cXG58fCBNaXN0IEd1YXJkaWFuIEhlYWx0aCBpc1wiLCBtaXN0R3VhcmRpYW5IZWFsdGggKyBcInx8XCIpO1xuXG4gICAgICAgIHByaW50KFwiXFxuXFxuKDEpIE5vcm1hbCBhdHRhY2sgNzUlIGNoYW5jZSBpdCBoaXRzIGFuZCBpdCBkZWFsc1wiLCBub3JtYWxBdHRhY2spXG4gICAgICAgIHByaW50KFwiXFxuKDIpIFN0cm9uZyBhdHRhY2s6IDQ1JSBjaGFuY2Ugb2YgaGl0dGluZyBhbmQgZGVhbHNcIiwgc3Ryb25nQXR0YWNrKVxuICAgICAgICBwcmludChcIlxcbigzKSBIZWFsOiBIZWFsc1wiLCBoZWFsLCBcIm9mIGhlYWx0aCBcIilcblxuICAgICAgICBjb3VudCA9IGNvdW50ICsgMVxuXG4gICAgICAgIGlucHV0ID0gZ2V0SW5wdXQoKTtcblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgIHBsYXllckF0dGFja1JhbmRvbSA9IE1hdGgucmFuZG9tKCk7XG4gICAgICAgICAgICBpZiAocGxheWVyQXR0YWNrUmFuZG9tIDw9IDAuNzUpIHtcbiAgICAgICAgICAgICAgICBwcmludChcIlxcblxcblxcblxcbllvdSBkZWFsdFwiLCBub3JtYWxBdHRhY2ssIFwiZGFtYWdlIHRvIHRoZSB0aGUgTWlzdCBHdWFyZGlhbiBcIilcbiAgICAgICAgICAgICAgICBtaXN0R3VhcmRpYW5IZWFsdGggPSBtaXN0R3VhcmRpYW5IZWFsdGggLSBub3JtYWxBdHRhY2s7XG4gICAgICAgICAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApXG5cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcHJpbnQoXCJcXG5cXG5cXG5cXG5Zb3UgbWlzc2VkIHRoZSBhdHRhY2tcIilcbiAgICAgICAgICAgICAgICBGdW4udGhyZWFkU2xlZXAoMTAwMClcblxuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpbnB1dCA9PSBcIjJcIikge1xuICAgICAgICAgICAgcGxheWVyQXR0YWNrUmFuZG9tID0gTWF0aC5yYW5kb20oKTtcbiAgICAgICAgICAgIGlmIChwbGF5ZXJBdHRhY2tSYW5kb20gPD0gMC40NSkge1xuICAgICAgICAgICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxueW91IGRlYWx0XCIsIHN0cm9uZ0F0dGFjaywgXCJkYW1hZ2UgdG8gdGhlIE1pc3QgR3VhcmRpYW4gXCIpXG4gICAgICAgICAgICAgICAgbWlzdEd1YXJkaWFuSGVhbHRoID0gbWlzdEd1YXJkaWFuSGVhbHRoIC0gc3Ryb25nQXR0YWNrO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwcmludChcIlxcblxcblxcblxcbllvdSBtaXNzZWQgdGhlIGF0dGFja1wiKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgRnVuLnRocmVhZFNsZWVwKDEwMDApXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaW5wdXQgPT0gXCIzXCIpIHtcbiAgICAgICAgICAgIHByaW50KFwiXFxuXFxuXFxuXFxueW91IGhlYWxlZFwiLCBoZWFsLCBcImhlYWx0aFwiKVxuICAgICAgICAgICAgcGxheWVySGVhbHRoID0gcGxheWVySGVhbHRoICsgaGVhbDtcbiAgICAgICAgICAgIEZ1bi50aHJlYWRTbGVlcCgxMDAwKVxuICAgICAgICB9XG5cbiAgICB9XG5cbiAgICBpZiAoc2NyZWVuID09IFwiTWlzdCBHdWFyZGlhbiBCb3NzXCIgJiYgcGxheWVySGVhbHRoIDwgMSkge1xuICAgICAgICBwcmludChcIlxcblxcbl9fICAgX18gICAgICAgICAgIF9fX19fXyBfICAgICAgICAgIF9cIilcbiAgICAgICAgcHJpbnQoXCJcXFxcIFxcXFwgLyAvICAgICAgICAgICB8ICBfICAoXykgICAgICAgIHwgfFwiKVxuICAgICAgICBwcmludChcIiBcXFxcIFYgL19fXyAgXyAgIF8gIHwgfCB8IHxfICBfX18gIF9ffCB8XCIpXG4gICAgICAgIHByaW50KFwiICBcXFxcIC8vIF8gXFxcXHwgfCB8IHwgfCB8IHwgfCB8LyBfIFxcXFwvIF9gIHxcIilcbiAgICAgICAgcHJpbnQoXCIgIHwgfCAoXykgfCB8X3wgfCB8IHwvIC98IHwgIF9fLyAoX3wgfFwiKVxuICAgICAgICBwcmludChcIiAgXFxcXF8vXFxcXF9fXy8gXFxcXF9fLF98IHxfX18vIHxffFxcXFxfX198XFxcXF9fLF98XCIpXG4gICAgICAgIGdhbWVPdmVyID0gdHJ1ZVxuICAgIH1cblxuICAgIGlmIChzY3JlZW4gPT0gXCJNaXN0IEd1YXJkaWFuIEJvc3NcIiAmJiBtaXN0R3VhcmRpYW5IZWFsdGggPCAxKSB7XG5cbiAgICAgICAgY29pbnMgPSBjb2lucyArIDYwMDtcbiAgICAgICAgcHJpbnQoXCJcXG5ZT1UgV09OLCB5b3UgZ2V0XCIsIDYwMCwgXCJjb2luc1wiKVxuICAgICAgICBwcmludChcIlxcbllvdSBoYXZlXCIsIGNvaW5zLCBcImNvaW5zXCIpXG5cbiAgICAgICAgbWlzdEdhdXJkaWFuQmVhdGVuID0gdHJ1ZTtcbiAgICAgICAgc2NyZWVuID0gXCJEdW5nZW9uXCJcblxuICAgIH1cblxuXG5cblxuXG5cblxuXG5cbiAgICBpZiAoc2NyZWVuID09IFwiXCIpIHtcblxuICAgICAgICBwcmludChcIkVSUk9SXCIpXG4gICAgICAgIHRyZWVJbW1vYmlsaXplciA9IHRydWVcbiAgICAgICAgdHJlZUVzc2VuY2UgPSBmYWxzZVxuICAgICAgICB0cmVlSW1tb2JpbGl6ZXIgPSBmYWxzZVxuICAgICAgICBkdW5nZW9uR2F0ZSA9IGZhbHNlO1xuICAgICAgICBkdW5nZW9uS2V5ID0gZmFsc2U7XG4gICAgICAgIG1pc3RHYXVyZGlhbkJlYXRlbiA9IGZhbHNlO1xuXG4gICAgfVxuXG4gICAgaWYgKHNjcmVlbiA9PSBcImRlYXRoXCIpIHtcblxuICAgICAgICBwcmludChcIlxcblxcbl9fICAgX18gICAgICAgICAgIF9fX19fXyBfICAgICAgICAgIF9cIilcbiAgICAgICAgcHJpbnQoXCJcXFxcIFxcXFwgLyAvICAgICAgICAgICB8ICBfICAoXykgICAgICAgIHwgfFwiKVxuICAgICAgICBwcmludChcIiBcXFxcIFYgL19fXyAgXyAgIF8gIHwgfCB8IHxfICBfX18gIF9ffCB8XCIpXG4gICAgICAgIHByaW50KFwiICBcXFxcIC8vIF8gXFxcXHwgfCB8IHwgfCB8IHwgfCB8LyBfIFxcXFwvIF9gIHxcIilcbiAgICAgICAgcHJpbnQoXCIgIHwgfCAoXykgfCB8X3wgfCB8IHwvIC98IHwgIF9fLyAoX3wgfFwiKVxuICAgICAgICBwcmludChcIiAgXFxcXF8vXFxcXF9fXy8gXFxcXF9fLF98IHxfX18vIHxffFxcXFxfX198XFxcXF9fLF98XCIpXG4gICAgICAgIGdhbWVPdmVyID0gdHJ1ZTtcbiAgICB9XG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cbn1cblxuXG5cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBLHFCQUFxQjtBQUNyQixnQkFBZ0I7QUFDaEIsMEVBQTBFO0FBQzFFOzs7Ozs7Ozs7OztDQVdDLEdBQ0QsU0FDSSxLQUFLLEVBQ0wsUUFBUSxRQUdMLHdCQUF3QjtBQUMvQixZQUFZLFNBQVMsd0JBQXdCO0FBQzdDLGlGQUFpRjtBQUVqRixxRkFBcUY7QUFDckYsa0RBQWtEO0FBRWxELHNDQUFzQztBQUN0QyxzQ0FBc0M7QUFFdEMsSUFBSSxXQUFXLEtBQUs7QUFDcEIsSUFBSSxTQUFTO0FBQ2IsaUJBQWlCO0FBQ2pCLElBQUksUUFBZ0I7QUFDcEIsSUFBSSxhQUFxQjtBQUN6QixJQUFJLGVBQWU7QUFDbkIsSUFBSSxtQkFBbUI7QUFDdkIsSUFBSSxrQkFBa0I7QUFDdEIsSUFBSSxXQUFXO0FBQ2YsSUFBSSxlQUF1QjtBQUMzQixJQUFJLGVBQXVCO0FBQzNCLElBQUksT0FBZTtBQUNuQixJQUFJLHFCQUE2QjtBQUNqQyxJQUFJLFFBQWdCO0FBQ3BCLElBQUksUUFBZ0I7QUFDcEIsSUFBSSxnQkFBZ0I7QUFDcEIsSUFBSSxjQUFjO0FBQ2xCLElBQUksY0FBc0I7QUFDMUIsSUFBSSxjQUFzQjtBQUMxQixJQUFJLGFBQXFCO0FBQ3pCLElBQUksY0FBc0I7QUFDMUIsSUFBSSxnQkFBZ0IsS0FBSztBQUN6QixJQUFJLGNBQWMsS0FBSztBQUN2QixJQUFJLGtCQUFrQixLQUFLO0FBQzNCLElBQUksYUFBYSxLQUFLO0FBQ3RCLElBQUksY0FBYyxLQUFLO0FBQ3ZCLElBQUkscUJBQXFCLEtBQUs7QUFDOUIsSUFBSSxxQkFBcUI7QUFDekIsSUFBSSwyQkFBbUM7QUFDdkMsSUFBSSxrQkFBMEI7QUFDOUIsSUFBSSxvQkFBNEI7QUFDaEMsSUFBSSxtQkFBMkI7QUFDL0IsSUFBSSx5QkFBaUM7QUFDckMsSUFBSSx5QkFBaUM7QUFHckMsTUFBTyxZQUFZLEtBQUssQ0FBRTtJQUV0QixJQUFJLFVBQVUsZUFBZTtRQUN6QixNQUFNO1FBQ04sY0FBYztRQUNkLGVBQWU7UUFDZixjQUFjLGdCQUFnQjtRQUU5QixJQUFJLFdBQVcsQ0FBQztRQUVoQixTQUFTO0lBRWIsQ0FBQztJQUVELElBQUksVUFBVSxrQkFBa0IsZUFBZSxLQUFLLGVBQWUsR0FBRztRQUVsRSxlQUFlLGVBQWU7UUFFOUIsZUFBZSxXQUFXO1FBQzFCLGVBQWUsV0FBVztRQUMxQixPQUFPLFdBQVc7UUFLbEIsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFFTixNQUFNLHFCQUFxQixhQUFhO1FBR3hDLE1BQU0sd0JBQXdCLGVBQWU7UUFHN0MsTUFBTSw0QkFBNEIsY0FBYztRQUVoRCxNQUFNLDJEQUEyRDtRQUNqRSxNQUFNLHdEQUF3RDtRQUM5RCxNQUFNLHFCQUFxQixNQUFNO1FBRWpDLFFBQVE7UUFFUixJQUFJLFNBQVMsS0FBSztZQUNkLHFCQUFxQixLQUFLLE1BQU07WUFDaEMsSUFBSSxzQkFBc0IsTUFBTTtnQkFDNUIsTUFBTSxxQkFBcUIsY0FBYztnQkFDekMsY0FBYyxjQUFjO2dCQUM1QixJQUFJLFdBQVcsQ0FBQztZQUVwQixPQUFPO2dCQUNILE1BQU07Z0JBQ04sSUFBSSxXQUFXLENBQUM7WUFHcEIsQ0FBQztRQUVMLENBQUM7UUFFRCxJQUFJLFNBQVMsS0FBSztZQUNkLHFCQUFxQixLQUFLLE1BQU07WUFDaEMsSUFBSSxzQkFBc0IsTUFBTTtnQkFDNUIsTUFBTSxxQkFBcUIsY0FBYztnQkFDekMsY0FBYyxjQUFjO1lBQ2hDLE9BQU87Z0JBQ0gsTUFBTTtZQUNWLENBQUM7WUFDRCxJQUFJLFdBQVcsQ0FBQztRQUNwQixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFDZCxNQUFNLHNCQUFzQixNQUFNO1lBQ2xDLGVBQWUsZUFBZTtZQUM5QixJQUFJLFdBQVcsQ0FBQztRQUNwQixDQUFDO0lBRUwsQ0FBQztJQUVELElBQUksVUFBVSxrQkFBa0IsZUFBZSxHQUFHO1FBQzlDLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLFdBQVcsSUFBSTtJQUNuQixDQUFDO0lBRUQsSUFBSSxVQUFVLGtCQUFrQixjQUFjLEdBQUc7UUFDN0MsZ0JBQWdCLGdCQUFnQjtRQUNoQyxjQUFjLGdCQUFnQjtRQUM5QixRQUFRLFFBQVE7UUFDaEIsTUFBTSxzQkFBc0IsYUFBYTtRQUN6QyxNQUFNLGNBQWMsT0FBTztRQUUzQixTQUFTO0lBRWIsQ0FBQztJQVNELElBQUksVUFBVSxpQkFBaUI7UUFFM0IsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBRU4sTUFBTTtRQUNOLE1BQU07UUFFTixRQUFRO1FBRVIsSUFBSSxTQUFTLEtBQUs7WUFDZCxTQUFTO1FBRWIsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBRWQsTUFBTTtZQUNOLFdBQVcsSUFBSTtRQUNuQixDQUFDO0lBQ0wsQ0FBQztJQUVELElBQUksVUFBVSxlQUFlO1FBRXpCLE1BQU07UUFDTixhQUFhO1FBRWIsTUFBTSxNQUFNO1FBRVosTUFBTTtRQUNOLFFBQVE7UUFDUixRQUFRO1FBRVIsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztJQUVMLENBQUM7SUFFRCxJQUFJLFVBQVUsaUJBQWlCLG1CQUFtQixLQUFLLGVBQWUsR0FBRztRQUVyRSxlQUFlLGVBQWU7UUFDOUIsZUFBZSxXQUFXO1FBQzFCLGVBQWUsV0FBVztRQUMxQixPQUFPLFdBQVc7UUFJbEIsTUFBTTtRQUdOLElBQUksUUFBUSxHQUFHO1lBQ1gsTUFBTTtZQUNOLE1BQU07UUFDVixPQUFPLENBRVAsQ0FBQztRQUlELE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFHTixNQUFNO1FBRU4sTUFBTSx3QkFBd0IsZUFBZTtRQUk3QyxNQUFNLDRCQUE0QixtQkFBbUI7UUFFckQsTUFBTSwyREFBMkQ7UUFDakUsTUFBTSx3REFBd0Q7UUFDOUQsTUFBTSxxQkFBcUIsTUFBTTtRQUNqQyxNQUFNO1FBQ04sUUFBUSxRQUFRO1FBRWhCLFFBQVE7UUFFUixJQUFJLFNBQVMsS0FBSztZQUVkLHFCQUFxQixLQUFLLE1BQU07WUFDaEMsSUFBSSxzQkFBc0IsTUFBTTtnQkFDNUIsTUFBTSxxQkFBcUIsY0FBYztnQkFDekMsbUJBQW1CLG1CQUFtQjtZQUUxQyxPQUFPO2dCQUNILE1BQU07WUFHVixDQUFDO1lBQ0QsSUFBSSxXQUFXLENBQUM7UUFDcEIsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBRWQscUJBQXFCLEtBQUssTUFBTTtZQUNoQyxJQUFJLHNCQUFzQixNQUFNO2dCQUM1QixNQUFNLHFCQUFxQixjQUFjO2dCQUN6QyxtQkFBbUIsbUJBQW1CO1lBQzFDLE9BQU87Z0JBQ0gsTUFBTTtZQUNWLENBQUM7WUFDRCxJQUFJLFdBQVcsQ0FBQztRQUNwQixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFDZCxNQUFNLHNCQUFzQixNQUFNO1lBQ2xDLGVBQWUsZUFBZTtZQUM5QixJQUFJLFdBQVcsQ0FBQztRQUNwQixDQUFDO0lBRUwsQ0FBQztJQUVELElBQUksVUFBVSxpQkFBaUIsZ0JBQWdCLEdBQUc7UUFDOUMsTUFBTTtRQUNOLFdBQVcsSUFBSTtJQUNuQixDQUFDO0lBRUQsSUFBSSxVQUFVLGlCQUFpQixvQkFBb0IsR0FBRztRQUNsRCxNQUFNO1FBQ04sUUFBUSxRQUFRO1FBRWhCLFNBQVM7SUFDYixDQUFDO0lBV0QsSUFBSSxVQUFVLFlBQVk7UUFFdEIsTUFBTTtRQUNOLE1BQU07UUFFTixRQUFRO1FBRVIsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBRWIsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBRWQsU0FBUztRQUNiLENBQUM7UUFFRCxJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFFYixDQUFDO0lBQ0wsQ0FBQztJQVVELFlBQVk7SUFHWixJQUFJLFVBQVUsZ0JBQWdCLHNCQUFzQixLQUFLLEVBQUU7UUFHdkQsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFHTixNQUFNO1FBRU4sSUFBSSxXQUFXLENBQUM7UUFFaEIsTUFBTTtRQUVOLE1BQU07UUFFTixNQUFNO1FBRU4sSUFBSSxXQUFXLENBQUM7UUFFaEIscUJBQXFCO1FBRXJCLGVBQWU7UUFFZixRQUFRO1FBSVIsU0FBUztJQUNiLENBQUM7SUFFRCxJQUFJLFVBQVUsOEJBQThCLGVBQWUsS0FBSyxxQkFBcUIsR0FBRztRQUVwRiwyQkFBMkIsS0FBSyxNQUFNO1FBRXRDLGVBQWUsV0FBVztRQUMxQixlQUFlLFdBQVc7UUFDMUIsT0FBTyxXQUFXO1FBYWxCLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBS04sSUFBSSwyQkFBMkIsUUFBUSxRQUFRLEdBQUc7WUFFOUMsTUFBTSw4QkFBOEIsSUFBSTtZQUV4QyxlQUFlLGVBQWU7UUFHbEMsT0FBTyxJQUFJLDRCQUE0QixNQUFNO1lBQ3pDLE1BQU07UUFFVixDQUFDO1FBS0QsTUFBTSx3QkFBd0IsZUFBZTtRQUc3QyxNQUFNLGtDQUFrQyxxQkFBcUI7UUFFN0QsTUFBTSx5REFBeUQ7UUFDL0QsTUFBTSx3REFBd0Q7UUFDOUQsTUFBTSxxQkFBcUIsTUFBTTtRQUVqQyxRQUFRLFFBQVE7UUFFaEIsUUFBUTtRQUVSLElBQUksU0FBUyxLQUFLO1lBQ2QscUJBQXFCLEtBQUssTUFBTTtZQUNoQyxJQUFJLHNCQUFzQixNQUFNO2dCQUM1QixNQUFNLHFCQUFxQixjQUFjO2dCQUN6QyxxQkFBcUIscUJBQXFCO2dCQUMxQyxJQUFJLFdBQVcsQ0FBQztZQUVwQixPQUFPO2dCQUNILE1BQU07Z0JBQ04sSUFBSSxXQUFXLENBQUM7WUFHcEIsQ0FBQztRQUVMLENBQUM7UUFFRCxJQUFJLFNBQVMsS0FBSztZQUNkLHFCQUFxQixLQUFLLE1BQU07WUFDaEMsSUFBSSxzQkFBc0IsTUFBTTtnQkFDNUIsTUFBTSxxQkFBcUIsY0FBYztnQkFDekMscUJBQXFCLHFCQUFxQjtZQUM5QyxPQUFPO2dCQUNILE1BQU07WUFDVixDQUFDO1lBQ0QsSUFBSSxXQUFXLENBQUM7UUFDcEIsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBQ2QsTUFBTSxzQkFBc0IsTUFBTTtZQUNsQyxlQUFlLGVBQWU7WUFDOUIsSUFBSSxXQUFXLENBQUM7UUFDcEIsQ0FBQztJQUNMLENBQUM7SUFFRCxJQUFJLFVBQVUsOEJBQThCLGVBQWUsR0FBRztRQUMxRCxNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixXQUFXLElBQUk7SUFDbkIsQ0FBQztJQUVELElBQUksVUFBVSw4QkFBOEIscUJBQXFCLEdBQUc7UUFFaEUsTUFBTTtRQUNOLE1BQU07UUFFTixJQUFJLFdBQVcsQ0FBQztRQUNoQixxQkFBcUIsSUFBSTtRQUV6QixTQUFTO0lBRWIsQ0FBQztJQUdELElBQUksVUFBVSxnQkFBZ0Isc0JBQXNCLElBQUksRUFBRTtRQUV0RCxNQUFNO1FBRU4sTUFBTTtRQUVOLFFBQVE7UUFFUixJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFDYixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFFZCxVQUFVO1FBQ2QsQ0FBQztJQUVMLENBQUM7SUFHRCxJQUFJLFVBQVUsZUFBZTtRQUV6QixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBRU4sTUFBTTtRQUVOLElBQUksV0FBVyxDQUFDO1FBRWhCLE1BQU07UUFFTixJQUFJLFdBQVcsQ0FBQztRQUVoQixRQUFRO1FBQ1IsZUFBZTtRQUNmLG1CQUFtQjtRQUNuQixTQUFTO0lBRWIsQ0FBQztJQUdELElBQUksVUFBVSxvQkFBb0I7UUFFOUIseUJBQXlCLEtBQUssTUFBTTtRQUNwQyx5QkFBeUIsS0FBSyxNQUFNO1FBRXBDLGVBQWUsV0FBVztRQUMxQixlQUFlLFdBQVc7UUFDMUIsT0FBTyxXQUFXO1FBTWxCLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQU1OLElBQUksUUFBUSxHQUFHO1lBRVgsSUFBSSx5QkFBeUIsTUFBTTtnQkFFL0IsSUFBSSx5QkFBeUIsTUFBTTtvQkFFL0IsZUFBZTtvQkFFZixNQUFNO2dCQUNWLENBQUM7WUFFTCxPQUFPLElBQUkseUJBQXlCLE1BQU07Z0JBQ3RDLE1BQU07WUFDVixDQUFDO1lBRUQsSUFBSSx5QkFBeUIsUUFBUSx5QkFBeUIsUUFBUSxtQkFBbUIsS0FBSztnQkFFMUYsbUJBQW1CLG1CQUFtQjtnQkFFdEMsTUFBTTtZQUNWLE9BQU8sSUFBSSx5QkFBeUIsTUFBTTtnQkFFdEMsZUFBZSxlQUFlO2dCQUU5QixNQUFNO1lBRVYsQ0FBQztRQUVMLENBQUM7UUFHRCxNQUFNLHdCQUF3QixlQUFlO1FBRzdDLE1BQU0sZ0NBQWdDLG1CQUFtQjtRQUV6RCxNQUFNLHlEQUF5RDtRQUMvRCxNQUFNLHdEQUF3RDtRQUM5RCxNQUFNLHFCQUFxQixNQUFNO1FBRWpDLFFBQVEsUUFBUTtRQUVoQixRQUFRO1FBRVIsSUFBSSxTQUFTLEtBQUs7WUFDZCxxQkFBcUIsS0FBSyxNQUFNO1lBQ2hDLElBQUksc0JBQXNCLE1BQU07Z0JBQzVCLE1BQU0scUJBQXFCLGNBQWM7Z0JBQ3pDLG1CQUFtQixtQkFBbUI7Z0JBQ3RDLElBQUksV0FBVyxDQUFDO1lBRXBCLE9BQU87Z0JBQ0gsTUFBTTtnQkFDTixJQUFJLFdBQVcsQ0FBQztZQUdwQixDQUFDO1FBRUwsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBQ2QscUJBQXFCLEtBQUssTUFBTTtZQUNoQyxJQUFJLHNCQUFzQixNQUFNO2dCQUM1QixNQUFNLHFCQUFxQixjQUFjO2dCQUN6QyxtQkFBbUIsbUJBQW1CO1lBQzFDLE9BQU87Z0JBQ0gsTUFBTTtZQUNWLENBQUM7WUFDRCxJQUFJLFdBQVcsQ0FBQztRQUNwQixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFDZCxNQUFNLHNCQUFzQixNQUFNO1lBQ2xDLGVBQWUsZUFBZTtZQUM5QixJQUFJLFdBQVcsQ0FBQztRQUNwQixDQUFDO0lBRUwsQ0FBQztJQUlELElBQUksVUFBVSxzQkFBc0IsZUFBZSxHQUFHO1FBQ2xELE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLFdBQVcsSUFBSTtJQUNuQixDQUFDO0lBRUQsSUFBSSxVQUFVLHNCQUFzQixtQkFBbUIsR0FBRztRQUl0RCxTQUFTO0lBRWIsQ0FBQztJQUtELElBQUksVUFBVSxVQUFVO1FBSXBCLElBQUksYUFBYTtRQUVqQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFFTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFFTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUVoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFFTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFFTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFFTixJQUFJLFdBQVcsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFFTixJQUFJLFdBQVcsQ0FBQztRQUVoQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFFTixXQUFXLElBQUk7SUFDbkIsQ0FBQztJQXFCRCxNQUFNO0lBS04sSUFBSSxVQUFVLFFBQVE7UUFHbEIsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFFTixNQUFNLGFBQWEsWUFBWTtRQUUvQixNQUFNLGlCQUFpQixVQUFVLGlCQUFpQixpQkFBaUIsY0FBYyxPQUFPLFNBQVMsb0NBQW9DLG1CQUFtQixnQ0FBZ0MsaUJBQWlCLG9DQUFvQyxlQUFlO1FBRTVQLFFBQVE7UUFFUixJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFDYixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBR2IsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBRWQsU0FBUztRQUNiLENBQUM7UUFFRCxJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFDYixDQUFDO0lBQ0wsQ0FBQztJQUVELElBQUksVUFBVSwwQkFBMEIsU0FBUyxlQUFlO1FBRTVELE1BQU07UUFFTixNQUFNO1FBRU4sUUFBUTtRQUVSLElBQUksU0FBUyxLQUFLO1lBRWQsTUFBTTtZQUVOLGdCQUFnQjtZQUVoQixRQUFRLFFBQVE7WUFFaEIsSUFBSSxXQUFXLENBQUM7WUFFaEIsU0FBUztRQUNiLENBQUM7SUFDTCxPQUFPLElBQUksVUFBVSwwQkFBMEIsUUFBUSxlQUFlO1FBRWxFLE1BQU07UUFFTixJQUFJLFdBQVcsQ0FBQztRQUVoQixTQUFTO0lBQ2IsQ0FBQztJQUVELElBQUksVUFBVSxzQkFBc0IsU0FBUyxtQkFBbUI7UUFFNUQsUUFBUSxRQUFRO1FBQ2hCLFdBQVcsV0FBVztRQUN0QixvQkFBb0Isb0JBQW9CO1FBRXhDLE1BQU0sNEJBQTRCO1FBQ2xDLE1BQU0sWUFBWSxPQUFPO1FBRXpCLElBQUksV0FBVyxDQUFDO1FBRWhCLFNBQVM7SUFFYixPQUFPLElBQUksVUFBVSxzQkFBc0IsUUFBUSxtQkFBbUI7UUFFbEUsTUFBTTtRQUNOLElBQUksV0FBVyxDQUFDO1FBRWhCLFNBQVM7SUFDYixDQUFDO0lBRUQsSUFBSSxVQUFVLG9CQUFvQixTQUFTLGlCQUFpQjtRQUV4RCxRQUFRLFFBQVE7UUFDaEIsa0JBQWtCLGtCQUFrQjtRQUNwQyxrQkFBa0Isa0JBQWtCO1FBRXBDLE1BQU0sOEJBQThCO1FBQ3BDLE1BQU0sWUFBWSxPQUFPO1FBRXpCLElBQUksV0FBVyxDQUFDO1FBRWhCLFNBQVM7SUFFYixPQUFPLElBQUksVUFBVSxvQkFBb0IsUUFBUSxpQkFBaUI7UUFFOUQsTUFBTTtRQUNOLElBQUksV0FBVyxDQUFDO1FBRWhCLFNBQVM7SUFDYixDQUFDO0lBT0QsY0FBYztJQU1kLElBQUksVUFBVSx5QkFBeUI7UUFHbkMsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFFTixNQUFNO1FBRU4sUUFBUTtRQUVSLElBQUksU0FBUyxLQUFLO1lBRWQsU0FBUztRQUNiLENBQUM7UUFFRCxJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFDYixDQUFDO0lBRUwsQ0FBQztJQVFELElBQUksVUFBVSxpQ0FBaUM7UUFFM0MsY0FBYyxLQUFLLE1BQU07UUFFekIsSUFBSSxlQUFlLE1BQU07WUFFckIsYUFBYTtZQUViLFNBQVM7UUFLYixDQUFDO1FBRUQsSUFBSSxjQUFjLE1BQU07WUFFcEIsU0FBUztRQUViLENBQUM7SUFDTCxDQUFDO0lBRUQsSUFBSSxVQUFVLDJCQUEyQjtRQUdyQyxNQUFNO1FBQ04sTUFBTTtRQUVOLFFBQVE7UUFFUixJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFDYixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBRWQsU0FBUztRQUNiLENBQUM7SUFDTCxDQUFDO0lBTUQsWUFBWTtJQUdaLElBQUksVUFBVSxtQkFBbUI7UUFFN0IsY0FBYyxLQUFLLE1BQU07UUFJekIsSUFBSSxlQUFlLE1BQU07WUFFckIsYUFBYTtZQUViLFNBQVM7UUFLYixDQUFDO1FBRUQsSUFBSSxjQUFjLE1BQU07WUFFcEIsU0FBUztRQUViLENBQUM7SUFDTCxDQUFDO0lBRUQsSUFBSSxVQUFVLGFBQWE7UUFHdkIsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBR04sTUFBTTtRQUVOLE1BQU07UUFDTixRQUFRO1FBRVIsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBRWQsU0FBUztRQUNiLENBQUM7UUFFRCxJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFDYixDQUFDO0lBQ0wsQ0FBQztJQUlELElBQUksVUFBVSxrQkFBa0I7UUFHNUIsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUlOLE1BQU07UUFDTixNQUFNO1FBQ04sa0JBQWtCLElBQUk7UUFDdEIsTUFBTTtRQUNOLFFBQVE7UUFFUixJQUFJLFNBQVMsS0FBSztZQUNkLFNBQVM7UUFDYixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFDZCxTQUFTO1FBQ2IsQ0FBQztJQUNMLENBQUM7SUFNRCxJQUFJO0lBR0osWUFBWTtJQUtaLElBQUksVUFBVSxnQkFBZ0IsZUFBZSxLQUFLLElBQUksVUFBVSxnQkFBZ0IsY0FBYyxJQUFJLEVBQUU7UUFFaEcsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUVOLE1BQU07UUFDTixRQUFRO1FBRVIsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBQ2QsTUFBTTtZQUNOLElBQUksV0FBVyxDQUFDO1FBQ3BCLENBQUM7UUFFRCxJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFJYixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztJQUVMLE9BQU8sSUFBSSxVQUFVLGdCQUFnQixlQUFlLElBQUksSUFBSSxjQUFjLEtBQUssRUFBRTtRQUU3RSxNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBRU4sTUFBTTtRQUNOLFFBQVE7UUFFUixJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFDYixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFDZCxNQUFNO1lBQ04sSUFBSSxXQUFXLENBQUM7UUFDcEIsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBRWQsU0FBUztRQUliLENBQUM7UUFFRCxJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFDYixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztJQUVMLENBQUM7SUFJRCxJQUFJLFVBQVUsdUJBQXVCO1FBRWpDLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUVOLE1BQU07UUFFTixNQUFNO1FBRU4sYUFBYSxJQUFJO1FBRWpCLElBQUksV0FBVyxDQUFDO1FBRWhCLFNBQVM7SUFFYixDQUFDO0lBRUQsSUFBSSxVQUFVLGdCQUFnQjtRQUUxQixNQUFNO1FBRU4sTUFBTTtRQUVOLFFBQVE7UUFFUixJQUFJLFNBQVMsS0FBSztZQUNkLFNBQVM7UUFDYixDQUFDO1FBQ0QsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztJQUNMLENBQUM7SUFNRCxhQUFhO0lBS2IsSUFBSSxVQUFVLGVBQWU7UUFHekIsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBRU4sTUFBTTtRQUVOLE1BQU07UUFJTixNQUFNO1FBRU4sUUFBUTtRQUVSLElBQUksU0FBUyxLQUFLO1lBRWQsU0FBUztRQUNiLENBQUM7UUFFRCxJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFDYixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztJQUNMLENBQUM7SUFHRCxJQUFJLFVBQVUsbUJBQW1CO1FBRTdCLE1BQU07UUFFTixNQUFNO1FBRU4sSUFBSSxXQUFXLENBQUM7UUFFaEIsU0FBUztJQUNiLENBQUM7SUFFRCxJQUFJLFVBQVUsK0JBQStCO1FBRXpDLE1BQU07UUFFTixNQUFNO1FBQ04sSUFBSSxXQUFXLENBQUM7UUFFaEIsU0FBUztJQUNiLENBQUM7SUFHRCxhQUFhO0lBRWIsSUFBSSxVQUFVLG9CQUFvQjtRQUU5QixjQUFjLEtBQUssTUFBTTtRQUl6QixJQUFJLGVBQWUsTUFBTTtZQUVyQixhQUFhO1lBRWIsU0FBUztRQUtiLENBQUM7UUFFRCxJQUFJLGNBQWMsTUFBTTtZQUVwQixTQUFTO1FBRWIsQ0FBQztJQUlMLENBQUM7SUFHRCxJQUFJLFVBQVUsY0FBYztRQUV4QixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUVOLE1BQU07UUFFTixNQUFNO1FBRU4sUUFBUTtRQUVSLElBQUksU0FBUyxLQUFLO1lBQ2QsU0FBUztRQUViLENBQUM7UUFFRCxJQUFJLFNBQVMsS0FBSztZQUNkLFNBQVM7UUFFYixDQUFDO0lBRUwsQ0FBQztJQU1ELGFBQWE7SUFHYixJQUFJLFVBQVUscUJBQXFCO1FBQy9CLGNBQWMsS0FBSyxNQUFNO1FBSXpCLElBQUksZUFBZSxNQUFNO1lBRXJCLGFBQWE7WUFFYixTQUFTO1FBS2IsQ0FBQztRQUVELElBQUksY0FBYyxNQUFNO1lBRXBCLFNBQVM7UUFFYixDQUFDO0lBRUwsQ0FBQztJQUVELElBQUksVUFBVSxpQkFBaUIsZUFBZSxLQUFLLEVBQUU7UUFHakQsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBR04sTUFBTTtRQUVOLE1BQU07UUFFTixNQUFNO1FBRU4sUUFBUTtRQUVSLElBQUksU0FBUyxLQUFLO1lBQ2QsU0FBUztRQUNiLENBQUM7UUFDRCxJQUFJLFNBQVMsS0FBSztZQUNkLFNBQVM7UUFDYixDQUFDO1FBSUQsSUFBSSxTQUFTLE9BQU8sbUJBQW1CLElBQUksRUFBRTtZQUV6QyxTQUFTO1FBR2IsT0FBTyxJQUFJLFNBQVMsT0FBTyxtQkFBbUIsS0FBSyxFQUFFO1lBQ2pELFNBQVM7UUFLYixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztJQUVMLENBQUM7SUFHRCxJQUFJLFVBQVUsbUJBQW1CO1FBRTdCLE1BQU07UUFDTixJQUFJLFdBQVcsQ0FBQztRQUNoQixTQUFTO0lBQ2IsQ0FBQztJQUVELElBQUksVUFBVSx3QkFBd0I7UUFFbEMsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFFTixNQUFNO1FBRU4sTUFBTTtRQUVOLElBQUksV0FBVyxDQUFDO1FBRWhCLGNBQWMsSUFBSTtRQUlsQixTQUFTO0lBQ2IsQ0FBQztJQU1ELFNBQVM7SUFFVCxJQUFJLFVBQVUsaUJBQWlCLGVBQWUsSUFBSSxJQUFJLGNBQWMsS0FBSyxJQUFJLGVBQWUsS0FBSyxFQUFFO1FBRy9GLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBRU4sTUFBTTtRQUVOLE1BQU07UUFFTixRQUFRO1FBRVIsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztJQUlMLENBQUM7SUFHRCxJQUFJLFVBQVUsaUJBQWlCLGVBQWUsSUFBSSxJQUFJLGNBQWMsSUFBSSxJQUFJLGVBQWUsS0FBSyxFQUFFO1FBRzlGLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBRU4sTUFBTTtRQUVOLE1BQU07UUFFTixRQUFRO1FBRVIsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBRWQsY0FBYyxJQUFJO1lBQ2xCLFNBQVM7UUFDYixDQUFDO0lBR0wsQ0FBQztJQUVELElBQUksVUFBVSxpQkFBaUIsZUFBZSxJQUFJLElBQUksY0FBYyxJQUFJLElBQUksZUFBZSxJQUFJLEVBQUU7UUFHN0YsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBRU4sTUFBTTtRQUVOLE1BQU07UUFFTixRQUFRO1FBRVIsSUFBSSxTQUFTLEtBQUs7WUFFZCxTQUFTO1FBQ2IsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBRWQsU0FBUztRQUNiLENBQUM7SUFFTCxDQUFDO0lBR0QsSUFBSSxVQUFVLGFBQWEsc0JBQXNCLEtBQUssRUFBRTtRQUVwRCxNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBRU4sTUFBTTtRQUNOLElBQUksV0FBVyxDQUFDO1FBRWhCLE1BQU07UUFFTixNQUFNO1FBRU4sUUFBUTtRQUVSLGVBQWU7UUFFZixJQUFJLFdBQVcsQ0FBQztRQUVoQixTQUFTO0lBRWIsQ0FBQztJQUVELElBQUksVUFBVSxhQUFhLHNCQUFzQixJQUFJLEVBQUU7UUFFbkQsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFHTixNQUFNO1FBRU4sTUFBTTtRQUVOLFFBQVE7UUFFUixJQUFJLFNBQVMsS0FBSztZQUVkLFNBQVM7UUFDYixDQUFDO0lBQ0wsQ0FBQztJQUVELElBQUksVUFBVSx3QkFBd0IsZUFBZSxLQUFLLHFCQUFxQixHQUFHO1FBRTlFLDJCQUEyQixLQUFLLE1BQU07UUFFdEMsZUFBZSxXQUFXO1FBQzFCLGVBQWUsV0FBVztRQUMxQixPQUFPLFdBQVc7UUFhbEIsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFLTixJQUFJLDJCQUEyQixRQUFRLFFBQVEsR0FBRztZQUU5QyxNQUFNLDhCQUE4QixJQUFJO1lBRXhDLGVBQWUsZUFBZTtRQUdsQyxPQUFPLElBQUksNEJBQTRCLE1BQU07WUFDekMsTUFBTTtRQUVWLENBQUM7UUFLRCxNQUFNLHdCQUF3QixlQUFlO1FBRzdDLE1BQU0sa0NBQWtDLHFCQUFxQjtRQUU3RCxNQUFNLHlEQUF5RDtRQUMvRCxNQUFNLHdEQUF3RDtRQUM5RCxNQUFNLHFCQUFxQixNQUFNO1FBRWpDLFFBQVEsUUFBUTtRQUVoQixRQUFRO1FBRVIsSUFBSSxTQUFTLEtBQUs7WUFDZCxxQkFBcUIsS0FBSyxNQUFNO1lBQ2hDLElBQUksc0JBQXNCLE1BQU07Z0JBQzVCLE1BQU0scUJBQXFCLGNBQWM7Z0JBQ3pDLHFCQUFxQixxQkFBcUI7Z0JBQzFDLElBQUksV0FBVyxDQUFDO1lBRXBCLE9BQU87Z0JBQ0gsTUFBTTtnQkFDTixJQUFJLFdBQVcsQ0FBQztZQUdwQixDQUFDO1FBRUwsQ0FBQztRQUVELElBQUksU0FBUyxLQUFLO1lBQ2QscUJBQXFCLEtBQUssTUFBTTtZQUNoQyxJQUFJLHNCQUFzQixNQUFNO2dCQUM1QixNQUFNLHFCQUFxQixjQUFjO2dCQUN6QyxxQkFBcUIscUJBQXFCO1lBQzlDLE9BQU87Z0JBQ0gsTUFBTTtZQUNWLENBQUM7WUFDRCxJQUFJLFdBQVcsQ0FBQztRQUNwQixDQUFDO1FBRUQsSUFBSSxTQUFTLEtBQUs7WUFDZCxNQUFNLHNCQUFzQixNQUFNO1lBQ2xDLGVBQWUsZUFBZTtZQUM5QixJQUFJLFdBQVcsQ0FBQztRQUNwQixDQUFDO0lBRUwsQ0FBQztJQUVELElBQUksVUFBVSx3QkFBd0IsZUFBZSxHQUFHO1FBQ3BELE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLFdBQVcsSUFBSTtJQUNuQixDQUFDO0lBRUQsSUFBSSxVQUFVLHdCQUF3QixxQkFBcUIsR0FBRztRQUUxRCxRQUFRLFFBQVE7UUFDaEIsTUFBTSxzQkFBc0IsS0FBSztRQUNqQyxNQUFNLGNBQWMsT0FBTztRQUUzQixxQkFBcUIsSUFBSTtRQUN6QixTQUFTO0lBRWIsQ0FBQztJQVVELElBQUksVUFBVSxJQUFJO1FBRWQsTUFBTTtRQUNOLGtCQUFrQixJQUFJO1FBQ3RCLGNBQWMsS0FBSztRQUNuQixrQkFBa0IsS0FBSztRQUN2QixjQUFjLEtBQUs7UUFDbkIsYUFBYSxLQUFLO1FBQ2xCLHFCQUFxQixLQUFLO0lBRTlCLENBQUM7SUFFRCxJQUFJLFVBQVUsU0FBUztRQUVuQixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixXQUFXLElBQUk7SUFDbkIsQ0FBQztBQXVCTCJ9