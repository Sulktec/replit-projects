/*
 * Copyright 2020 Carson Cheng
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */ //export * from "../../lib-fun-terminal/mod.ts";
//export * from "https://gitcdn.xyz/repo/cheng-code/fun-tsd-lib/master/lib-fun-terminal/mod.ts";
//import * as expressive from "https://raw.githubusercontent.com/cheng-code/fun-tsd-lib/master/lib-fun-terminal/mod.ts";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vaG9tZS9ydW5uZXIvbWlzdHktZm9yZXN0L2NzMTAtdHh0LWxpYi0wLjYudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCAyMDIwIENhcnNvbiBDaGVuZ1xuICogVGhpcyBTb3VyY2UgQ29kZSBGb3JtIGlzIHN1YmplY3QgdG8gdGhlIHRlcm1zIG9mIHRoZSBNb3ppbGxhIFB1YmxpY1xuICogTGljZW5zZSwgdi4gMi4wLiBJZiBhIGNvcHkgb2YgdGhlIE1QTCB3YXMgbm90IGRpc3RyaWJ1dGVkIHdpdGggdGhpc1xuICogZmlsZSwgWW91IGNhbiBvYnRhaW4gb25lIGF0IGh0dHBzOi8vbW96aWxsYS5vcmcvTVBMLzIuMC8uXG4gKi9cblxuLy9leHBvcnQgKiBmcm9tIFwiLi4vLi4vbGliLWZ1bi10ZXJtaW5hbC9tb2QudHNcIjtcbi8vZXhwb3J0ICogZnJvbSBcImh0dHBzOi8vZ2l0Y2RuLnh5ei9yZXBvL2NoZW5nLWNvZGUvZnVuLXRzZC1saWIvbWFzdGVyL2xpYi1mdW4tdGVybWluYWwvbW9kLnRzXCI7XG4vL2ltcG9ydCAqIGFzIGV4cHJlc3NpdmUgZnJvbSBcImh0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbS9jaGVuZy1jb2RlL2Z1bi10c2QtbGliL21hc3Rlci9saWItZnVuLXRlcm1pbmFsL21vZC50c1wiO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztDQUtDLEdBRUQsZ0RBQWdEO0FBQ2hELGdHQUFnRztBQUNoRyx3SEFBd0gifQ==