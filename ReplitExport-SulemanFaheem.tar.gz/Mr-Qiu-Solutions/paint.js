/*
this example will show Mr. Qiu's solution to implementing a cursor in the paint program

note this example can be used to demonstrate linear search, and binary search, 
and inheritance for different brush strokes
*/


/*
my solution:  3 classes

paint.js acts as our world

paintClass.js holds the BrushStroke class
    tracks: x,y,colour,size, brush

paintClass2.js holds the Cursor class
    tracks x,y,size, brush 


*/


/*
    explain how/give the sequence for how I track mouse position with my cursor
        ex: 
        1) at line 5 I did this...
        2) at line 6 a method/constructor/something was called
        3) the method did something to the attribute in file ...

        // at line 18 I use code "paint.setCoord(mouseX, mouseY, paintSize, paintColour);" to go into a function setCoord which sets this.x to mouseX and this.y to mouseY using variables x and y. 
    
    identify how and where a paint stroke is made. 

        1) at line 5 I did this...
        2) at line 6 a method/constructor/something was called
        3) the method did something to the attribute in file ... 

        At line 20 it used the code "paint.placeStroke();" to get into the function placeStroke. In that function I set the strokesWeight to this.size and place a point at (this.x and this.y).

        at line 21 I use code "paint.setPaint(paintSize,paintColour);" to check paintSize which is put into strokesWeight as this.size in function setPaint and paintColour put into this.color which is used in stroke(this.color) in the function setPaint.

    give the sequence for how brush type (Cursor) is changed 

        1) at line 5 I did this...
        2) at line 6 a method/constructor/something was called
        3) the method did something to the attribute in file ... 

        in function keyPressed, theres an if statement at line 28-32 which activates when 1 is pressed and if paintSize is greater than 1 which results in paintSize being decreased by 1. line 34-38 does the exact same thing as line28-32 but instead of pressing 1; pressing to is required and there's no if paintSize is greater than 1 and the paintSize varaibles increases by 1. The brush always remains as a circel shape. pressing e changes the color to white (46-49) and pressing r will change it back to black (51-54).

    does my solution differ from yours?
        a) if so, by a little or a lot? 
        b) what's different? 
    2-4 sentences for the last one

    a) quite a bit
    b) my programs doesn't have its own cursur. My colors are onyl white and black. My background is white. The varaibles I use are different. The way I paint my strokes are different. I only have circles as my paint shape. I do not use an array to store my strokes or even store them. My setter method are different and I do not have a render function in my class file.
*/


let strokes = []; // this array will hold "brush stroke" objects
let brushSize = 10;
let colour = "lime";
let backgroundColour = "lightSkyBlue"
let brushType = "circle";

let myCursor;

function setup() {
    angleMode(DEGREES);
    rectMode(CENTER);
    createCanvas(600, 600);
    background(backgroundColour);



    myCursor = new Cursor(300, 300, brushSize,brushType);

}

function keyPressed() {
    if (keyCode === 79) { //79 is O
        brushSize++;
    }

    if (keyCode === 76) { //76 is L
        brushSize--;
    }

    if (keyCode === 190) { //76 is . (period)
        //this will act as an erase
        colour = backgroundColour;
    }

    if (keyCode === 80) { //76 is p
        //this will erase the picture
        strokes = [];
    }

    if (keyCode === 70) { //70 is f
        colour = "blue";
    }

    if (keyCode === 71) { //71 is g
        colour = "yellow";

    }


    if (keyCode === 83) { //71 is s
        //sets brush to square
        brushType = "square";

    }

    if (keyCode === 67) { //71 is c
        //sets brush to circle
        brushType = "circle";
        // note that you could also call the setter here when the key is pressed
        // instead of always calling it in draw

    }

}




function draw() {

    //step 0 get input 
    if (mouseIsPressed) {
        //note that the brush type is updated when the new stroke object is created
        strokes.push(new BrushStroke(mouseX, mouseY, brushSize, colour,brushType));
    }

    //step 1 of animation clear everything
    clear();
    background(backgroundColour);



    //step 2 of animation, update values 

    myCursor.setCoordinates(mouseX, mouseY);
    /* ^^^^^ ******************
    note any changes to class attribute values are done through the "main" file
    using class methods, such as setters, getters
    **********************************
    */
    myCursor.setBrushSize(brushSize);
    /*
    note that setting brush size and updating x,y coordinates of mouse can be
    combined into 1 class method in Cursor called: update(x,y,brushSize) 
    */
    myCursor.setBrushType(brushType);
    

    //step 3 of animation, draw at new values


    //use a for loop to display all objects in strokes array
    strokeWeight(0); //stroke weight done before to save actions
    for (let i = 0; i < strokes.length; i++) {
        strokes[i].displayStroke();
    }
    strokeWeight(1); //restore stroke weight for next cursor draw

    myCursor.displayStroke(); //draw last so always on top

}