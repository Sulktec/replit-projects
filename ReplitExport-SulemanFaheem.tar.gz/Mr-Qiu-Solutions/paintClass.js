class BrushStroke{

    constructor(x,y,s,c,bt){
        this.size = s;
        this.colour = c;
        this.x = x;
        this.y = y;
        this.brush = bt;
    }

    render(x,y,s,c,b){

        fill(c);
        if(b === "circle"){
            circle(x,y,s);
        }

        if(b === "square"){
            rect(x,y,s,s);
        }

        
    }

    
    displayStroke(){
        this.render(this.x,this.y,this.size,this.colour,this.brush);
    }



    
}