class Cursor {

    constructor(x, y, d, bt) {
        this.x = x;
        this.y = y;
        this.d = d;
        this.brushType = bt;
    }


    setCoordinates(x, y) {

        //a check can be performed to validate inputes before assigning them 
        // ^ a benefit of using setter methods
        this.x = x;
        this.y = y;
    }

    setBrushType(bt) {
        this.brushType = bt;
    }cs

    setBrushSize(s) {
        this.d = s;
    }

    render(x, y, s, bt) {
        noFill();
        if (bt === "circle") {
            circle(x, y, s);
        }

        if (bt === "square") {
            rect(x, y, s, s);
        }

    }


    displayStroke() {
        this.render(this.x, this.y, this.d, this.brushType);
    }

}