class LauncherTurret extends LauncherBase {

    constructor(x,y,w,h,color,an,tw,th,yo) {
        push();

        
        super(x,y,w,h,color);

        this.heading = an;
        this.yOffset = yo;
        this.turrentWidth = tw;
        this.turrentHeight = th;
        
        this.anglePos = [];
        pop();
    }

    setMousePos(x,y) {

        this.mX = x;
        this.mY = y;
        
    }

    getAngle() {
        
        return this.heading*(180/PI);
    }

    getPos() {

        let temp = createVector(this.position.x + this.width/2, this.position.y+this.yOffset)
        return temp;
    }

    setAngle() { // towards mouse
        push()

        this.heading = atan2(this.mY-this.position.y, this.mX-this.position.x);

        let min = -2.5;

        let max = -0.5;

        if (this.heading < min) {

            this.heading = min;
        } 
        
        if (this.heading > max) {

            this.heading = max;
        }

        

        
        pop();
    }





    show() {
        push();
        translate(this.position.x + this.width/2,this.position.y+this.yOffset);
        rotate(this.heading);
   
        fill('green')
        rect(0,0,this.turrentWidth, this.turrentHeight)

        pop();
    }
}