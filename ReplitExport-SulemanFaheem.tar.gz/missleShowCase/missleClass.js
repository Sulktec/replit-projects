class Missle extends Projectile {

    constructor(x,y,wi,hi,an,sp,color,exCol) {

        super(x,y,wi,hi,an,sp,color);

        this.alive = true;

        this.explode = false;
        this.explosionLife = 255;
        this.delete = false;
        this.radius = wi;
        this.exColor = exCol;

        this.explosionHitBox = [];
        
    }

    groundCollision() {

        if (this.position.y + this.width >= 600) {
            this.alive = false;
        }
    }

    getAlive() {

        return this.alive;
    }

    setDead() {

        this.alive = false;
    }

    getDelete() {

        return this.delete;
    }

    expandExplosion() {

        this.explosionLife =  this.explosionLife + -3.5;

        this.radius = this.radius + 0.2;

        if (this.explosionLife <= 0) {

            this.delete = true;
        }
        
    }

    getExplosion() {

        this.explosionHitBox = [this.position.x,this.position.y,this.radius*2];

        return this.explosionHitBox;
    }

    showExplosion() {

        push();
        translate(this.position.x, this.position.y);
        stroke(0,this.explosionLife); 
        fill(this.exColor[0],this.exColor[1],this.exColor[2],this.explosionLife);
        
        
        circle(0,0,this.radius*2)
        
        pop();
        
    }
    
}