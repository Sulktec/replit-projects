let proj;
let missle = [];
let launcherBullet = [];
let sign = [-1,1]
let launcherBulletColor = [245,228,0]
let missleColor = [255,20,0]
let mouseCursor;

let d = new Date();
let launcherBulletTime = d.getTime();

let missleBulletTime = d.getTime();

let projectileLauncher = []
let launcherWidth = 75;
let launcherYOffset = 10

let cloudArray = []




let index = 0;
let levelMax = 25;
let level = 0;
let levelBulletLength = 3;
let levelBulletLengthIncrease = 0.5;
let levelTimeSubtract = 100;

let maxMissleTime = 7000;
let minMissleTime = 3000;

let maxMissleSpeed = 1.5;
let minMissleSpeed = 1;
let missleSpeedInterval = 0.15;

let gameStart = false;
let gameOver = false;
let gameWin = false;

function preload() {

    img = loadImage('images/cursor.png');
    imgCloud = loadImage('images/cloud.png');
    
}


function setup() {
  createCanvas(900, 600);
  background('lightSkyBlue');

    
    
    projectileLauncher[0] = new LauncherTurret(180-(75/2),height-25,launcherWidth,25,'grey',0,55,5,launcherYOffset)

    projectileLauncher[1] = new LauncherTurret(180*2-(75/2),height-25,launcherWidth,25,'grey',0,55,5,launcherYOffset)

    projectileLauncher[2] = new LauncherTurret(180*3-(75/2),height-25,launcherWidth,25,'grey',0,55,5,launcherYOffset)

    projectileLauncher[3] = new LauncherTurret(180*4-(75/2),height-25,launcherWidth,25,'grey',0,55,5,launcherYOffset)

    mouseCursor = new Cursor(mouseX, mouseY, 30,30,img)

    cloudArray[0] = new Clouds(-100,Math.floor((Math.random()*200-100)+100),2,100,62,imgCloud)
    cloudArray[1] = new Clouds(-100,Math.floor((Math.random()*400-300)+300),5,100,62,imgCloud)

}

function keyPressed(){

    
     
}

function dead() {

    if (projectileLauncher.length <= 0) {

        gameOver = true;
    }
}


function draw() {
    if (gameStart === true) {
        if (gameOver === false) {
            dead()
            clear();
            background('lightSkyBlue');
        
            d = new Date();
        
            let missleBulletTimeInterval = Math.floor(Math.random() * (maxMissleTime - minMissleTime) + minMissleTime);
        
            if (d.getTime() - missleBulletTime >= missleBulletTimeInterval) {
        
                missle.push(new Missle(width/2,-20,15,5,90 + (random(sign) * (Math.random()*36)),(3 * (Math.random() * (maxMissleSpeed - minMissleSpeed) ) + minMissleSpeed),'red', missleColor))
    
                levelSystem();
                
                missleBulletTime = d.getTime();
            }
        
             for (let i = 0; i < launcherBullet.length; i++) {
        
        
        
        
        
                 if (launcherBullet[i].getAlive() === true) {
                    
        
                      launcherBullet[i].applyVelocity();
                      launcherBullet[i].explosionPoint();
                      launcherBullet[i].show();
                     launcherBullet[i].hitbox();
                        
                     
                 } else if (launcherBullet[i].getAlive() === false) {
                     launcherBullet[i].expandExplosion();
                     launcherBullet[i].showExplosion();
                     
        
                     if (launcherBullet[i].getDelete() === true) {
                         launcherBullet.splice(i,1);
                     }
                 }
        
             }
        
            for (let i = 0; i < projectileLauncher.length; i++) {
        
        
                if (projectileLauncher[i].getAlive() === true) {
                    projectileLauncher[i].setMousePos(mouseX, mouseY);
                    projectileLauncher[i].setAngle();
                    projectileLauncher[i].show();
                    
                    projectileLauncher[i].hitbox();
                    projectileLauncher[i].showBase();
                } else if (projectileLauncher[i].getAlive() === false) {
        
                    projectileLauncher.splice(i,1)
                }
        
            }
        
        
            
        
            
            for (let i = 0; i < missle.length; i++) {
        
                if (missle[i].getAlive() === true) {
                    
                    missle[i].applyVelocity();
                    missle[i].groundCollision();
                    missle[i].show();
                    missle[i].hitbox();
                } else if (missle[i].getAlive() === false) {
                    missle[i].expandExplosion();
                    missle[i].showExplosion();
        
                    if (missle[i].getDelete() === true) {
                        missle.splice(i,1);
                    }
                }
        
            }

            for (let i = 0; i < missle.length; i++) {
        
                let tempArrayOne = missle[i].getHitBox();
        
                for(let h = 0; h < launcherBullet.length; h++) {
        
                    let tempArrayTwo = launcherBullet[h].getExplosion();
        
                    for(let g = 0; g < tempArrayOne.length;g++) {
        
                          let collided = Collision.collide(tempArrayOne[g][0],tempArrayOne[g][1],tempArrayOne[g][2]/2,tempArrayTwo[0],tempArrayTwo[1],tempArrayTwo[2]/2)
        
                          if (collided === true && missle[i].getAlive() === true && launcherBullet[h].getAlive() === false) {
        
                              print("YAY")
        
                                  missle[i].setDead();
                          }
        
                    }
        
        
                }
        
                let tempArrayThree =  missle[i].getExplosion();
        
                for(let l = 0; l < projectileLauncher.length; l++) {
        
                    let tempArrayFour = projectileLauncher[l].getHitBox()
        
                      let collided = Collision.collide(tempArrayThree[0],tempArrayThree[1],tempArrayThree[2]/2,tempArrayFour[0],tempArrayFour[1],tempArrayFour[2]/2)
        
                      if (collided === true && projectileLauncher[l].getAlive() === true && missle[i].getAlive() === false) {
        
                          print("YAY")
        
                            projectileLauncher[l].setDead();
                      }
                    
                }
            }


            for (let i = 0; i < cloudArray.length; i++) {

                cloudArray[i].move();
                cloudArray[i].reset();
                cloudArray[i].show();
                
            }




        
            levelText()
            
            mouseCursor.setPos(mouseX + launcherWidth/2,mouseY+launcherYOffset);
            mouseCursor.show();

            if (level >= levelMax) {

                gameWin = true
                gameOver = true;
                
            }
    
            
            
        } else if (gameOver === true && gameWin === false) {
                push();
                clear();
                background(255, 157, 160);
    
                fill('black');
                textAlign(CENTER,CENTER);
                textSize(100);
                text('Defeated', width/2, height/2);
                pop();
        } else if (gameOver === true && gameWin === true) {
                push();
                clear();
                background(144, 238, 144);

                fill('black');
                textAlign(CENTER,CENTER);
                textSize(100);
                text('Survived', width/2, height/2);
                textSize(50);
                text( levelMax + ' Days', width/2, height/2+60);
                text( 'Everyone is safely evacuated', width/2, height/2+110);
                pop();
        }

    } else if (gameStart === false) {
            push();
        
            clear();
            background('black');

            let textSizeValue = 40;
            let textOffset = 0;

            fill('white');
            textAlign(CENTER,TOP);
            textSize(40);
            text('Hello soldier,', width/2, textOffset);
            textOffset = textOffset + textSizeValue;
            text('you are the countries last hope.', width/2, textOffset);
            textOffset = textOffset + textSizeValue;
            text('The enemies are too powerful.', width/2, textOffset);
            textOffset = textOffset + textSizeValue;
            text('They can launch missles for the rest of time.', width/2, textOffset);
            textOffset = textOffset + textSizeValue;
            text('the only way we can protect our people is', width/2, textOffset);
            textOffset = textOffset + textSizeValue;
            text('to buy them enough time so they can escape.', width/2, textOffset);
            textOffset = textOffset + textSizeValue;
            text('This evacuation will take ' +  levelMax + ' days', width/2, textOffset);
            textOffset = textOffset + textSizeValue;
            text('Good Luck soldier!', width/2, textOffset);

            text('Press space to start', width/2, height-textSizeValue);
            pop();

        if (keyIsPressed === true) {
            if (keyCode === 32) {

                gameStart = true;
            }
        } 
        
    }
}


function levelText() {
    push();
    fill('black');
    textAlign(LEFT,TOP);
    textSize(25);
    text('Days: ' + level, 0, 0);
    pop();
}


function levelSystem() {

    

    if (index < Math.floor(levelBulletLength)) {

        print("index is " + index)
        index++;
    }

    
    if (index >= Math.floor(levelBulletLength)) {

        level++;
        levelBulletLength = levelBulletLength + levelBulletLengthIncrease;

        maxMissleTime = maxMissleTime - levelTimeSubtract;
        minMissleTime = minMissleTime - levelTimeSubtract;

        maxMissleSpeed = maxMissleSpeed + missleSpeedInterval;
        minMissleSpeed = minMissleSpeed + missleSpeedInterval;
        

        index = 0;
        
        print("nextLevel " + level)
    }

    print("length " +levelBulletLength)
    
}


function mousePressed() {

    let width = 15;
    let height = 5;

    let interval = 1000; // (milliscond)

    if ((d.getTime() - launcherBulletTime ) >= interval) {
    
        for (let i = 0; i < projectileLauncher.length; i++) {
    
    launcherBullet.push(new LauncherBullet(projectileLauncher[i].getPos().x,projectileLauncher[i].getPos().y,width,height,projectileLauncher[i].getAngle(),((Math.random() * (6 - 4) ) + 4),'white',launcherBulletColor,mouseX,mouseY))
    
        }

        launcherBulletTime = d.getTime();
        
    }

    print(d.getTime() - launcherBulletTime)
}