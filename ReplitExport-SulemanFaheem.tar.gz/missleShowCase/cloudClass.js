class Clouds {

    constructor(x,y,s,w,h,img) {

        this.position = createVector(x,y)

        this.velocity = createVector(s,0);

        this.width = w;
        this.height = h;

        this.image = img;
        
    }

    move() {

        this.position.add(this.velocity);
        
    }

    reset() {

        if (this.position.x > 900) {

            this.position.x = -this.width;

            this.position.y = Math.floor((Math.random()*400-100)+100);

            this.velocity.x = (Math.random()*7)+2 

            print("reset")
        }

        if (keyCode === 66) {

            print("\n\nPOS:")
            print(this.position.x, this.position.y)

            print("VEL:")
            print(this.velocity)
        }

        
    
        
    }

    show() {

        image(this.image,this.position.x,this.position.y, this.width,this.height)
    }
    
}