class LauncherBase {

    constructor(x,y,w,h,color) {

        this.position = createVector(x,y);

        this.width = w;
        this.height = h;

        this.color = color;

        this.radius = this.height;

        this.showHitBox = true;
        
        this.hitboxArray = [];

        this.alive = true;
        
    }

    showBase() {
        push();

        translate(this.position.x,this.position.y);
        fill(this.color);
        rect(0,0,this.width,this.height)
        
        pop();
    }

    hitbox() {
        push();

        
        
        

        let multiplyRadius = this.width/this.height

        if (this.showHitBox === true) {
     
            circle(this.position.x + this.width/2, this.position.y +this.radius/2,this.radius*multiplyRadius)

        }

        this.hitboxArray = [this.position.x + this.width/2, this.position.y +this.radius/2,this.radius*multiplyRadius]

        
        // let xOffset = 0;

        // for (let i = 0; i < this.width/this.height;i++) {

            
        //     circle(this.radius/2 + xOffset,this.radius/2,this.radius)

        //     let array = [this.radius/2 + xOffset,this.radius/2,this.radius]

        //     this.hitboxArray[i] = array;

        //     xOffset = xOffset + this.radius;
        // }
        pop();
    }

    getHitBox() {

        return this.hitboxArray;
    }

    setDead() {

        this.alive = false;
    }

    getAlive() {

        return this.alive;
    }

    
}