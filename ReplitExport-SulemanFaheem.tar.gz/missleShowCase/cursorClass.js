class Cursor {

    constructor(x,y,w,h,img) {

        this.position = createVector(x,y);

        this.width = w;

        this.height = h;

        this.img = img;
        
    }

    setPos(x,y) {

        this.position = createVector(x,y)
        
    }

    show() {

        push();

        rectMode(CENTER);

        translate(this.position.x-this.width/2, this.position.y-this.height/2)

        image(this.img,0,0,this.width,this.height)
        fill('black')
        rect(0,0,width*10,2)

        pop();
    }
    
}