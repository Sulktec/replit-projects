class Projectile {

    constructor(x,y,wi,hi,an,sp,color) {

        this.position = createVector(x,y)
        this.acceleration = createVector(0,0);
        this.heading = an * (PI/180);
        this.velocity = p5.Vector.fromAngle(this.heading);
        this.dispay = false;

        this.color = color;

        this.width = wi;
        this.height = hi;

        this.velocity.x = this.velocity.x * sp;
        this.velocity.y = this.velocity.y * sp;

        this.hitBox = []
        this.showHitBox = false;
    }

    applyVelocity() {

        this.position.add(this.velocity);
        
    }

    hitbox() {
        // if value true then show hitboxes or else just be values used to calcualte hitboxes
           // make a loop that creates circles that runs w/h times which will perfectly fil up the circle. d will be h.
            // translate values let circles pos be 0 in the circle creator. 
            // have offset value that will be = i * diameter
            // translate(x + offset, y)
        push();


        
        fill('grey')
        
        translate(this.position.x, this.position.y);
        rotate(this.heading);
        for(let i = 0; i < this.width/this.height; i++) {

            let offSet = i * this.height;

            if (this.showHitBox === true) {
                circle(offSet+(this.height/2),(this.height/2),this.height)
            }

            this.hitBox[i] = [this.position.x+offSet+(this.height/2),this.position.y+(this.height/2),this.height]

        }

        pop();
        // array will equal to the circle hitbox values
        
    }

    getHitBox() {


        return this.hitBox;
    }

    show(){
        push()
        translate(this.position.x, this.position.y);
        rotate(this.heading);
        fill(this.color);
        rect(0, 0, this.width,this.height)
        pop()
    }
    
}