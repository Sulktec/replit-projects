class LauncherBullet extends Missle {

    constructor(x,y,wi,hi,an,sp,color,exColor,mX,mY) {

        super(x,y,wi,hi,an,sp,color,exColor);
        this.mousex = mX;
        this.mousey = mY;
    }

    


    explosionPoint() {

        if (this.position.y <= this.mousey+this.height && this.alive === true) {



            this.alive = false;
        }

    }

    // uses explosion from missle class
    
}