/*
modify the particle class, so it's behaviour is contained in the class 

the particle will move the opposite direction of the position vector is was created.

    for example, if the mouse is at (300,300), I want the particle to travel opposite of 
    the direction of the mouse, with varition in the x direction. 

    to do this, you'll need to multiply the vector by -1, but that results in a very large
    opposite vector 

    so use limit:https://p5js.org/reference/#/p5.Vector/limit

    let speed = vector(300,500)
    speed.limit(5);

    to get  a "exhaust effect" randomly add or subtract random x and y values pulled from an     array, like your random walker example 
    
    


*/
function setup() {
  createCanvas(600, 600);
  background("lightSkyBlue");
}

function draw() {

}