class amateaurAthlete extends Human {

    constructor(age, gender, name, sport, years) {

        super(age, gender, name);

        this.sport = sport;
        this.years = years;
    }

    athleteLevel() {

        print("I am an ameature athelete");
    }

    sportProfession() {

        print("I do " + this.sport);
    }

    yearsOfDoing() {

        print("I've been doing this for " + this.years + " years");
    }
    
}