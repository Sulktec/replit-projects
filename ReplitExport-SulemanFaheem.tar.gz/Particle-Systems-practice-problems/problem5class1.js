class Human {

    constructor(age, gender, name) {

        this.age = age;
        this.gender = gender;
        this.name = name;
        
    }

    displayStatus() {

        print("Hi, I am " + this.name)
        print("I am a " + this.gender);
        print("I am " + this.age + " years old");
    }

    eat() {

        print("I am eating");
        
    }

    sleep() {

        print("YaWn... I am sleeping");
    }
    
}