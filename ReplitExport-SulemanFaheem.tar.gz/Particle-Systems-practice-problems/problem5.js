
/*
using the content covered in example 6, particle systems examples 


try modelling a human. 

create a base human class that tracks something general 

extend it once so it's an athlete 

extend the athelte class:
    1) extend the athlete class to be a amateur athlete
    2) extend the athlete class to be a professional athlete 

to make 3 methods, other than setters and getters, for each of the classes 

*/

let base;
let nick;
let lisa;

function setup() {
    angleMode(DEGREES);
    rectMode(CENTER);
    createCanvas(600, 600);
    background("lightSkyBlue");

    base = new Human(22, "boy", "Brian");

    nick = new amateaurAthlete(21, "boy", "Nick", "soccer", 3)

    lisa = new profAthlete(30, "girl", "Lisa", "tennis", 11, 3)
}

function keyPressed() {

    // base.displayStatus();
    // base.eat();
    // base.sleep();

    nick.displayStatus();
    nick.athleteLevel();
    nick.sportProfession();
    nick.yearsOfDoing();
    nick.eat();
    nick.sleep();
    print("");
    lisa.displayStatus();
    lisa.athleteLevel();
    lisa.sportProfession();
    lisa.yearsOfDoing();
    lisa.awardsWon();
    lisa.eat();
    lisa.sleep();
    
}

function draw() {

    

}