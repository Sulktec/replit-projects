class profAthlete extends Human {

    constructor(age, gender, name, sport, years, awards) {

        super(age, gender, name);

        this.sport = sport;
        this.years = years;
        this.awards = awards;
    }

    athleteLevel() {

        print("I am a professional athelete");
    }

    sportProfession() {

        print("I do " + this.sport);
    }

    yearsOfDoing() {

        print("I've been doing this for " + this.years + " years");
    }

    awardsWon() {

        print("I've won " + this.awards + " awards")
    }

}