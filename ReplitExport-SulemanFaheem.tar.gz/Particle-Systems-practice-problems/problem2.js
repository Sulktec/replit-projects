
/*
problem 2: apply the emitter so that it will emit particles out of the ship

1) modify the particle class so instead of creating the opposite by flipping the vector,
it does it by modidifying an angle that's passed in 
    look to how we created the bullets to do this 

2) you need at add methods to the emitter class that update the xy of the emitter 
so it stays with the space ship 

2a) also track the "heading" of the emitter, create an attribute and a setter 

3) 



*/







// The Nature of Code
// Daniel Shiffman
// http://natureofcode.com






// Mover object
let ship;
let particle = [];
let gravity;

function setup() {
  createCanvas(640, 640);
    rectMode(CENTER);
    gravity = createVector(0,0.1)
    ship = new Spaceship();
}

function draw() {
  background(255);

    let shipPos = ship.getPos();


      if (keyIsDown(LEFT_ARROW)) {
        ship.turn(-0.03);
      } else if (keyIsDown(RIGHT_ARROW)) {
        ship.turn(0.03);
      } else if (keyIsDown(90) && !keyIsDown(RIGHT_ARROW) && !keyIsDown(LEFT_ARROW)) {
        ship.thrust();
          particle.push(new Particle(shipPos.x,shipPos.y));
      }

    for(let i = 0; i < particle.length; i++) {

        particle[i].setAngle(ship.getAngle());
        particle[i].update();

        particle[i].show();

        if (particle[i].isDead() === true) {

            particle.splice(i,1)
            print("ded")
        }

    }
    
  // Update position
  ship.update();
  // Wrape edges
  ship.wrapEdges();
  // Draw ship
  ship.show();

  // fill(0);
  // text("left right arrows to turn, z to thrust",10,height-5);

  // Turn or thrust the ship depending on what key is pressed






    



}